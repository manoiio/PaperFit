# 论文有格检查报告

规则：华工本科工理类2015演示规则（正文及标题题注）（段落及摘要关键词参考文献） v1.0.0+extended-demo-1.0.0+sections-demo-1.0
规则配置SHA256：110fbcbd4583fcb72746fac5a717122909ce4733d0247b7e88b925594be20934
输入：fixed.docx
SHA256：edb00388cf17f98f593323d7fadc5a318d7da787ec10a560f8f496453a034c4b

启用规则 22 条；实际适用 20 条；问题 5 个；待复核 12 个（规则记录 10，覆盖提示 2）。
结论：已覆盖检查发现问题。仅针对已覆盖范围，不表示全文合格。

格式属性结果不包含实际分页和所有可见排版验收；页面预览及Word查看需另行人工复核。

## 覆盖范围

{"body_paragraphs": [10, 12, 14, 15, 16], "total_top_level_paragraphs": 21, "unconfirmed_paragraphs": [17, 18], "ordinary_runs_checked": 5, "special_runs_skipped": 0, "section_count": 1, "excluded": "其他/待确认段落、表格内格式、页眉页脚、脚注/文本框；特殊结构继续保护。不检查题注位置、编号及全文合格。", "paragraph_types": {"1": "other", "2": "other", "3": "abstract_cn_title", "4": "abstract_cn_body", "5": "keywords_cn", "6": "abstract_en_title", "7": "abstract_en_body", "8": "keywords_en", "9": "heading1", "10": "body", "11": "heading2", "12": "body", "13": "heading2", "14": "body", "15": "body", "16": "body", "17": "pending", "18": "pending", "19": "other", "20": "reference_title", "21": "reference_item"}, "classification_confirmation": "网页用户逐项核对或确认整份分类；待确认项不检查、不修正", "confirmed_typed_paragraphs": [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 20, 21], "disabled_academic_properties": {"body": ["before", "after", "alignment", "bold"], "heading1": ["bold"], "heading2": ["bold"], "heading3": ["bold"], "figure_caption": ["before", "after", "alignment", "bold"], "table_caption": ["before", "after", "alignment", "bold"], "abstract_cn_title": ["font_western", "first_line_indent", "bold"], "abstract_en_title": ["font_cn", "first_line_indent", "bold"], "reference_title": ["font_western", "first_line_indent", "bold"], "abstract_cn_body": ["font_western", "before", "after", "alignment", "bold"], "abstract_en_body": ["font_cn", "first_line_indent", "before", "after", "bold"], "keywords_cn": ["before", "after", "line_spacing", "first_line_indent", "label_font_western", "label_bold", "content_font_western", "content_bold"], "keywords_en": ["before", "after", "line_spacing", "first_line_indent", "label_font_cn", "content_font_cn", "content_bold"], "reference_item": ["font_western", "first_line_indent", "before", "after", "alignment", "bold"]}, "academic_unchecked_requirements": ["外文参考文献2篇以上及主要文献身份、指导教师例外未自动判断（学校PDF物理页16）；需人工核对。", "中英文摘要/关键词的语义一致性、关键词层次及著录真实性未检查；不生成或改写内容。"], "academic_property_scope": "本清单列已启用的通用/章节属性（含确认附录致谢时R38–R41）；正文/标题/题注原R01–R12要求仍按其规则独立执行。"}

## 逐项检查

| 规则 | 位置 | 实际值 | 要求值 | 状态 | 可修正 | 依据 |
| --- | --- | --- | --- | --- | --- | --- |
| R01 | {"section": 1} | {"w_mm": 210.009, "h_mm": 297.004} | {"width_mm": 210, "height_mm": 297} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页20：编排并打印在标准A4纸上 |
| R02 | {"section": 1} | {"top_mm": 24.994, "bottom_mm": 24.994, "left_mm": 24.994, "right_mm": 24.994} | {"top_mm": 25, "bottom_mm": 25, "left_mm": 25, "right_mm": 25} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页20：所有页面的上下左右页面边距为25mm |
| R03 | {"paragraph": 10, "run": 1} | {"eastAsia": "宋体"} | "宋体" | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R04 | {"paragraph": 10, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman |
| R05 | {"paragraph": 10, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号 |
| R06 | {"paragraph": 10} | {"line_rule": "auto", "multiple": 1.5, "pt": null} | 1.5 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R07 | {"paragraph": 10} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：段首行缩进2个汉字 |
| R03 | {"paragraph": 12, "run": 1} | {"eastAsia": "宋体"} | "宋体" | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R04 | {"paragraph": 12, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman |
| R05 | {"paragraph": 12, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号 |
| R06 | {"paragraph": 12} | {"line_rule": "auto", "multiple": 1.5, "pt": null} | 1.5 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R07 | {"paragraph": 12} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：段首行缩进2个汉字 |
| R03 | {"paragraph": 14, "run": 1} | {"eastAsia": "宋体"} | "宋体" | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R04 | {"paragraph": 14, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman |
| R05 | {"paragraph": 14, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号 |
| R06 | {"paragraph": 14} | {"line_rule": "auto", "multiple": 1.5, "pt": null} | 1.5 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R07 | {"paragraph": 14} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：段首行缩进2个汉字 |
| R03 | {"paragraph": 15, "run": 1} | {"eastAsia": "宋体"} | "宋体" | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R04 | {"paragraph": 15, "run": 1} | {"ascii": "Times New Roman"} | "Times New Roman" | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman |
| R05 | {"paragraph": 15, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号 |
| R06 | {"paragraph": 15} | {"line_rule": "auto", "multiple": 1.5, "pt": null} | 1.5 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R07 | {"paragraph": 15} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：段首行缩进2个汉字 |
| R03 | {"paragraph": 16, "run": 1} | {"eastAsia": "宋体"} | "宋体" | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R04 | {"paragraph": 16, "run": 1} | {"ascii": "Times New Roman"} | "Times New Roman" | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman |
| R05 | {"paragraph": 16, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号 |
| R06 | {"paragraph": 16} | {"line_rule": "auto", "multiple": 1.5, "pt": null} | 1.5 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R07 | {"paragraph": 16} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：段首行缩进2个汉字 |
| R08 | {"paragraph": 9, "run": 1, "property": "font_ascii"} | {"slot": "ascii", "font": "Times New Roman"} | {"slot": "ascii", "font": "Times New Roman"} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：各章题序的阿拉伯数字用Times New Roman体；英文单词字体为Times New Roman |
| R08 | {"paragraph": 9, "run": 1, "property": "font_eastAsia"} | {"slot": "eastAsia", "font": "黑体"} | {"slot": "eastAsia", "font": "黑体"} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：小二号黑体，居中，单倍行距 |
| R08 | {"paragraph": 9, "run": 1, "property": "size"} | {"pt": 18.0} | {"pt": 18} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：小二号黑体，居中，单倍行距 |
| R08 | {"paragraph": 9, "property": "alignment"} | {"alignment": "center"} | {"alignment": "center"} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：小二号黑体，居中，单倍行距 |
| R08 | {"paragraph": 9, "property": "line"} | {"line_rule": "auto", "multiple": 1.0, "pt": null} | {"multiple": 1} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：小二号黑体，居中，单倍行距 |
| R11 | {"paragraph": 9} | {"style_id": "Heading1", "outline_level": 0} | {"style_id": "Heading1", "outline_level": 0} | 符合 | 否 | 产品结构规则：使用已存在且可验证的内置Heading 1–3及对应大纲级别；保持其他有效格式，不是学校明确规定英文样式名。 |
| R09 | {"paragraph": 11, "run": 1, "property": "font_ascii"} | {"slot": "ascii", "font": "Times New Roman"} | {"slot": "ascii", "font": "Times New Roman"} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：各章题序的阿拉伯数字用Times New Roman体；英文单词字体为Times New Roman |
| R09 | {"paragraph": 11, "run": 1, "property": "font_eastAsia"} | {"slot": "eastAsia", "font": "黑体"} | {"slot": "eastAsia", "font": "黑体"} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：小三号，黑体，居左，单倍行距 |
| R09 | {"paragraph": 11, "run": 1, "property": "size"} | {"pt": 15.0} | {"pt": 15} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：小三号，黑体，居左，单倍行距 |
| R09 | {"paragraph": 11, "property": "alignment"} | {"alignment": "left"} | {"alignment": "left"} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：小三号，黑体，居左，单倍行距 |
| R09 | {"paragraph": 11, "property": "line"} | {"line_rule": "auto", "multiple": 1.0, "pt": null} | {"multiple": 1} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：小三号，黑体，居左，单倍行距 |
| R11 | {"paragraph": 11} | {"style_id": "Heading2", "outline_level": 1} | {"style_id": "Heading2", "outline_level": 1} | 符合 | 否 | 产品结构规则：使用已存在且可验证的内置Heading 1–3及对应大纲级别；保持其他有效格式，不是学校明确规定英文样式名。 |
| R09 | {"paragraph": 13, "run": 1, "property": "font_eastAsia"} | {"slot": "eastAsia", "font": "黑体"} | {"slot": "eastAsia", "font": "黑体"} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：小三号，黑体，居左，单倍行距 |
| R09 | {"paragraph": 13, "run": 1, "property": "size"} | {"pt": 15.0} | {"pt": 15} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：小三号，黑体，居左，单倍行距 |
| R09 | {"paragraph": 13, "property": "alignment"} | {"alignment": "left"} | {"alignment": "left"} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：小三号，黑体，居左，单倍行距 |
| R09 | {"paragraph": 13, "property": "line"} | {"line_rule": "auto", "multiple": 1.0, "pt": null} | {"multiple": 1} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：小三号，黑体，居左，单倍行距 |
| R11 | {"paragraph": 13} | {"style_id": "Heading2", "outline_level": 1} | {"style_id": "Heading2", "outline_level": 1} | 符合 | 否 | 产品结构规则：使用已存在且可验证的内置Heading 1–3及对应大纲级别；保持其他有效格式，不是学校明确规定英文样式名。 |
| R10 | {"document": 1} | null | {"font_cn": "黑体", "font_latin": "Times New Roman", "size_pt": 14, "alignment": "left", "line_multiple": 1} | 不适用：本次确认分类中没有该类对象，不凭空报错 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：四号，黑体，居左，单倍行距 |
| R12 | {"document": 1} | null | {"font_cn": "宋体", "font_latin": "宋体", "size_pt": 10.5} | 不适用：本次确认分类中没有该类对象，不凭空报错 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：插图（表）的标题和文字：五号，宋体 |
| R14 | {"paragraph": 3, "property": "before"} | {"unresolved": "有效继承路径也未设置before间距；未按0处理"} | {"value": 0.5, "unit": "lines"} | 待复核：有效继承路径也未设置before间距；未按0处理 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页22：标题小二号黑体，居中，单倍行距，段前段后各0.5行 |
| R14 | {"paragraph": 3, "property": "after"} | {"value": 0.5, "unit": "lines", "origin": ["docDefaults", "直接段落格式"], "raw": {"after": "0", "line": "240", "lineRule": "auto", "afterAutospacing": "0", "afterLines": "50"}} | {"value": 0.5, "unit": "lines"} | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页22：标题小二号黑体，居中，单倍行距，段前段后各0.5行 |
| R14 | {"paragraph": 3, "property": "alignment"} | {"unresolved": "对齐未设置/未支持或无法可靠继承"} | "center" | 待复核：对齐未设置/未支持或无法可靠继承 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页22：标题小二号黑体，居中，单倍行距，段前段后各0.5行 |
| R14 | {"paragraph": 3, "property": "line_spacing"} | {"multiple": 1.0, "line_rule": "auto", "pt": null} | {"multiple": 1} | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页22：标题小二号黑体，居中，单倍行距，段前段后各0.5行 |
| R14 | {"paragraph": 3, "run": 1, "property": "font_eastAsia"} | "黑体" | "黑体" | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页22：标题小二号黑体，居中，单倍行距，段前段后各0.5行 |
| R14 | {"paragraph": 3, "run": 1, "property": "size"} | 18.0 | 18 | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页22：标题小二号黑体，居中，单倍行距，段前段后各0.5行 |
| R15 | {"paragraph": 4, "property": "line_spacing"} | {"multiple": 1.5, "line_rule": "auto", "pt": null} | {"multiple": 1.5} | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页17：中文摘要内容：小四号宋体，1.5倍行距，段首行空两个汉字 |
| R15 | {"paragraph": 4, "property": "first_line_indent"} | {"unresolved": "首行缩进未明确设置"} | {"chars": 2} | 待复核：首行缩进未明确设置 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页17：中文摘要内容：小四号宋体，1.5倍行距，段首行空两个汉字 |
| R15 | {"paragraph": 4, "run": 1, "property": "font_eastAsia"} | "宋体" | "宋体" | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页17：中文摘要内容：小四号宋体，1.5倍行距，段首行空两个汉字 |
| R15 | {"paragraph": 4, "run": 1, "property": "size"} | 12.0 | 12 | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页17：中文摘要内容：小四号宋体，1.5倍行距，段首行空两个汉字 |
| R18 | {"paragraph": 5, "property": "alignment"} | {"unresolved": "对齐未设置/未支持或无法可靠继承"} | "left" | 待复核：对齐未设置/未支持或无法可靠继承 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页17：关键词标题小四号黑体居左，内容小四号宋体；分号隔开 |
| R18 | {"paragraph": 5, "start": 0, "end": 4, "part": "label", "property": "font_eastAsia"} | "黑体" | "黑体" | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页17：关键词标题小四号黑体居左，内容小四号宋体；分号隔开 |
| R18 | {"paragraph": 5, "start": 0, "end": 4, "part": "label", "property": "size"} | 12.0 | 12 | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页17：关键词标题小四号黑体居左，内容小四号宋体；分号隔开 |
| R18 | {"paragraph": 5, "start": 4, "end": 18, "part": "content", "property": "font_eastAsia"} | "宋体" | "宋体" | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页17：关键词标题小四号黑体居左，内容小四号宋体；分号隔开 |
| R18 | {"paragraph": 5, "start": 4, "end": 18, "part": "content", "property": "size"} | 12.0 | 12 | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页17：关键词标题小四号黑体居左，内容小四号宋体；分号隔开 |
| R16 | {"paragraph": 6, "property": "before"} | {"unresolved": "有效继承路径也未设置before间距；未按0处理"} | {"value": 0.5, "unit": "lines"} | 待复核：有效继承路径也未设置before间距；未按0处理 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页23：标题小二号Times New Roman，居中，单倍行距，段前段后各0.5行 |
| R16 | {"paragraph": 6, "property": "after"} | {"value": 0.5, "unit": "lines", "origin": ["docDefaults", "直接段落格式"], "raw": {"after": "0", "line": "240", "lineRule": "auto", "afterAutospacing": "0", "afterLines": "50"}} | {"value": 0.5, "unit": "lines"} | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页23：标题小二号Times New Roman，居中，单倍行距，段前段后各0.5行 |
| R16 | {"paragraph": 6, "property": "alignment"} | {"unresolved": "对齐未设置/未支持或无法可靠继承"} | "center" | 待复核：对齐未设置/未支持或无法可靠继承 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页23：标题小二号Times New Roman，居中，单倍行距，段前段后各0.5行 |
| R16 | {"paragraph": 6, "property": "line_spacing"} | {"multiple": 1.0, "line_rule": "auto", "pt": null} | {"multiple": 1} | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页23：标题小二号Times New Roman，居中，单倍行距，段前段后各0.5行 |
| R16 | {"paragraph": 6, "run": 1, "property": "font_ascii"} | "Times New Roman" | "Times New Roman" | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页23：标题小二号Times New Roman，居中，单倍行距，段前段后各0.5行 |
| R16 | {"paragraph": 6, "run": 1, "property": "size"} | 18.0 | 18 | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页23：标题小二号Times New Roman，居中，单倍行距，段前段后各0.5行 |
| R17 | {"paragraph": 7, "property": "alignment"} | {"unresolved": "对齐未设置/未支持或无法可靠继承"} | "both" | 待复核：对齐未设置/未支持或无法可靠继承 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页23：正文小四号Times New Roman，1.5倍行距，两端对齐 |
| R17 | {"paragraph": 7, "property": "line_spacing"} | {"multiple": 1.5, "line_rule": "auto", "pt": null} | {"multiple": 1.5} | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页23：正文小四号Times New Roman，1.5倍行距，两端对齐 |
| R17 | {"paragraph": 7, "run": 1, "property": "font_ascii"} | "Times New Roman" | "Times New Roman" | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页23：正文小四号Times New Roman，1.5倍行距，两端对齐 |
| R17 | {"paragraph": 7, "run": 1, "property": "size"} | 12.0 | 12 | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页23：正文小四号Times New Roman，1.5倍行距，两端对齐 |
| R19 | {"paragraph": 8, "property": "alignment"} | {"unresolved": "对齐未设置/未支持或无法可靠继承"} | "left" | 待复核：对齐未设置/未支持或无法可靠继承 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页23：Keywords：Times New Roman，小四号，加粗，居左；关键词Times New Roman，小四号 |
| R19 | {"paragraph": 8, "start": 0, "end": 10, "part": "label", "property": "font_ascii"} | "Times New Roman" | "Times New Roman" | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页23：Keywords：Times New Roman，小四号，加粗，居左；关键词Times New Roman，小四号 |
| R19 | {"paragraph": 8, "start": 0, "end": 10, "part": "label", "property": "size"} | 12.0 | 12 | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页23：Keywords：Times New Roman，小四号，加粗，居左；关键词Times New Roman，小四号 |
| R19 | {"paragraph": 8, "start": 0, "end": 10, "part": "label", "property": "bold"} | true | true | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页23：Keywords：Times New Roman，小四号，加粗，居左；关键词Times New Roman，小四号 |
| R19 | {"paragraph": 8, "start": 10, "end": 51, "part": "content", "property": "font_ascii"} | "Times New Roman" | "Times New Roman" | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页23：Keywords：Times New Roman，小四号，加粗，居左；关键词Times New Roman，小四号 |
| R19 | {"paragraph": 8, "start": 10, "end": 51, "part": "content", "property": "size"} | 12.0 | 12 | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页23：Keywords：Times New Roman，小四号，加粗，居左；关键词Times New Roman，小四号 |
| R13 | {"paragraph": 9, "property": "before"} | {"value": 0.0, "unit": "pt", "origin": ["docDefaults", "paragraph样式:Heading1", "直接段落格式"], "raw": {"after": "0", "line": "240", "lineRule": "auto", "before": "0", "afterAutospacing": "0", "afterLines": "50"}} | {"value": 0.5, "unit": "lines"} | 问题：修正后的同规则读回发现新问题，请核对实际值。 | 是 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页28：各章/各节标题段前、段后各0.5行（范例） |
| R13 | {"paragraph": 9, "property": "after"} | {"value": 0.5, "unit": "lines", "origin": ["docDefaults", "paragraph样式:Heading1", "直接段落格式"], "raw": {"after": "0", "line": "240", "lineRule": "auto", "before": "0", "afterAutospacing": "0", "afterLines": "50"}} | {"value": 0.5, "unit": "lines"} | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页28：各章/各节标题段前、段后各0.5行（范例） |
| R13 | {"paragraph": 11, "property": "before"} | {"value": 0.0, "unit": "pt", "origin": ["docDefaults", "paragraph样式:Heading2", "直接段落格式"], "raw": {"after": "0", "line": "240", "lineRule": "auto", "before": "0", "afterAutospacing": "0", "afterLines": "50"}} | {"value": 0.5, "unit": "lines"} | 问题：修正后的同规则读回发现新问题，请核对实际值。 | 是 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页28：各章/各节标题段前、段后各0.5行（范例） |
| R13 | {"paragraph": 11, "property": "after"} | {"value": 0.5, "unit": "lines", "origin": ["docDefaults", "paragraph样式:Heading2", "直接段落格式"], "raw": {"after": "0", "line": "240", "lineRule": "auto", "before": "0", "afterAutospacing": "0", "afterLines": "50"}} | {"value": 0.5, "unit": "lines"} | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页28：各章/各节标题段前、段后各0.5行（范例） |
| R13 | {"paragraph": 13, "property": "before"} | {"value": 0.0, "unit": "pt", "origin": ["docDefaults", "paragraph样式:Heading2", "直接段落格式"], "raw": {"after": "0", "line": "240", "lineRule": "auto", "before": "0", "afterAutospacing": "0", "afterLines": "50"}} | {"value": 0.5, "unit": "lines"} | 问题：修正后的同规则读回发现新问题，请核对实际值。 | 是 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页28：各章/各节标题段前、段后各0.5行（范例） |
| R13 | {"paragraph": 13, "property": "after"} | {"value": 0.5, "unit": "lines", "origin": ["docDefaults", "paragraph样式:Heading2", "直接段落格式"], "raw": {"after": "0", "line": "240", "lineRule": "auto", "before": "0", "afterAutospacing": "0", "afterLines": "50"}} | {"value": 0.5, "unit": "lines"} | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页28：各章/各节标题段前、段后各0.5行（范例） |
| R20 | {"paragraph": 20, "property": "before"} | {"unresolved": "有效继承路径也未设置before间距；未按0处理"} | {"value": 0.5, "unit": "lines"} | 待复核：有效继承路径也未设置before间距；未按0处理 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页36：参考文献标题黑体小二号居中单倍行距，段前段后各0.5行 |
| R20 | {"paragraph": 20, "property": "after"} | {"value": 0.5, "unit": "lines", "origin": ["docDefaults", "直接段落格式"], "raw": {"after": "0", "line": "240", "lineRule": "auto", "afterAutospacing": "0", "afterLines": "50"}} | {"value": 0.5, "unit": "lines"} | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页36：参考文献标题黑体小二号居中单倍行距，段前段后各0.5行 |
| R20 | {"paragraph": 20, "property": "alignment"} | {"unresolved": "对齐未设置/未支持或无法可靠继承"} | "center" | 待复核：对齐未设置/未支持或无法可靠继承 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页36：参考文献标题黑体小二号居中单倍行距，段前段后各0.5行 |
| R20 | {"paragraph": 20, "property": "line_spacing"} | {"multiple": 1.0, "line_rule": "auto", "pt": null} | {"multiple": 1} | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页36：参考文献标题黑体小二号居中单倍行距，段前段后各0.5行 |
| R20 | {"paragraph": 20, "run": 1, "property": "font_eastAsia"} | "黑体" | "黑体" | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页36：参考文献标题黑体小二号居中单倍行距，段前段后各0.5行 |
| R20 | {"paragraph": 20, "run": 1, "property": "size"} | 18.0 | 18 | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页36：参考文献标题黑体小二号居中单倍行距，段前段后各0.5行 |
| R21 | {"paragraph": 21, "property": "line_spacing"} | {"multiple": 1.5, "line_rule": "auto", "pt": null} | {"multiple": 1.5} | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页18：参考文献和注释正文为小四号，宋体，1.5倍行距 |
| R21 | {"paragraph": 21, "run": 1, "property": "font_eastAsia"} | "宋体" | "宋体" | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页18：参考文献和注释正文为小四号，宋体，1.5倍行距 |
| R21 | {"paragraph": 21, "run": 1, "property": "size"} | 12.0 | 12 | 符合 | 否 | 2015演示规则原文/范例；不宣称现行标准：00-全员必看/本科毕业设计论文.pdf 物理页18：参考文献和注释正文为小四号，宋体，1.5倍行距 |
| R22 | {"document": 1, "property": "存在_abstract_cn_title"} | 1 | ">=1" | 符合：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_abstract_cn_body"} | 1 | ">=1" | 符合：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_abstract_en_title"} | 1 | ">=1" | 符合：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_abstract_en_body"} | 1 | ">=1" | 符合：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_keywords_cn"} | 1 | ">=1" | 符合：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_keywords_en"} | 1 | ">=1" | 符合：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_reference_title"} | 1 | ">=1" | 符合：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_reference_item"} | 1 | ">=1" | 符合：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "中文摘要字数"} | 29 | "400–600" | 问题：复杂结构不能宣称计数完整；正文非空白Unicode字符数，标点/数字计入，不含标题或关键词；不生成/扩写摘要 | 否 | 2015范例只读口径：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"paragraph": 5, "property": "关键词数量"} | 3 | "3–5" | 符合：按中英文分号分隔非空项；不添加关键词 | 否 | 2015范例只读口径：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"paragraph": 5, "property": "关键词分隔符"} | "结构识别；本地校验；合成样本" | "分号分隔，末项无标点" | 符合：只读，不调整词序或改写标点 | 否 | 2015范例只读口径：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"paragraph": 8, "property": "关键词数量"} | 3 | "3–5" | 符合：按中英文分号分隔非空项；不添加关键词 | 否 | 2015范例只读口径：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"paragraph": 8, "property": "关键词分隔符"} | "structure; validation; synthetic document" | "分号分隔，末项无标点" | 符合：只读，不调整词序或改写标点 | 否 | 2015范例只读口径：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "参考文献条目数"} | 1 | "确认条目≥10（主要文献/外文身份另核对）" | 问题：按人工确认条目计数；不足时核对范围或资料，不生成文献；不判断主要文献身份、语种或所有著录格式 | 否 | 2015范例只读口径：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "参考文献手工编号"} | [1] | "从1顺序、无重复/跳号" | 符合：仅明确[整数]的只读检查；不重排或改编号 | 否 | 2015范例只读口径：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |

## 字体及编号只读解析证据

文档指定字体用于属性检查；本机字体安装与替代由独立预览核对。
- R03:paragraph=10:run=1：{"font": {"eastAsia": {"font": "宋体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "宋体；来源 直接run格式"}}, "numbering": null}
- R03:paragraph=12:run=1：{"font": {"eastAsia": {"font": "宋体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "宋体；来源 直接run格式"}}, "numbering": null}
- R03:paragraph=14:run=1：{"font": {"eastAsia": {"font": "宋体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "宋体；来源 直接run格式"}}, "numbering": null}
- R03:paragraph=15:run=1：{"font": {"eastAsia": {"font": "宋体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "宋体；来源 直接run格式"}}, "numbering": null}
- R04:paragraph=15:run=1：{"font": {"ascii": {"font": "Times New Roman", "slot": "ascii", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "Times New Roman；来源 直接run格式"}}, "numbering": null}
- R03:paragraph=16:run=1：{"font": {"eastAsia": {"font": "宋体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "宋体；来源 直接run格式"}}, "numbering": null}
- R04:paragraph=16:run=1：{"font": {"ascii": {"font": "Times New Roman", "slot": "ascii", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "Times New Roman；来源 直接run格式"}}, "numbering": null}
- R08:paragraph=9:run=1:property=font_ascii：{"font": {"ascii": {"font": "Times New Roman", "slot": "ascii", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "Times New Roman；来源 直接run格式"}}, "numbering": null}
- R08:paragraph=9:run=1:property=font_eastAsia：{"font": {"eastAsia": {"font": "黑体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "黑体；来源 直接run格式"}}, "numbering": null}
- R09:paragraph=11:run=1:property=font_ascii：{"font": {"ascii": {"font": "Times New Roman", "slot": "ascii", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "Times New Roman；来源 直接run格式"}}, "numbering": null}
- R09:paragraph=11:run=1:property=font_eastAsia：{"font": {"eastAsia": {"font": "黑体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "黑体；来源 直接run格式"}}, "numbering": null}
- R09:paragraph=13:run=1:property=font_eastAsia：{"font": {"eastAsia": {"font": "黑体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "黑体；来源 直接run格式"}}, "numbering": null}
- R14:paragraph=3:run=1:property=font_eastAsia：{"font": {"eastAsia": {"font": "黑体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "黑体；来源 直接run格式"}}, "numbering": null}
- R15:paragraph=4:run=1:property=font_eastAsia：{"font": {"eastAsia": {"font": "宋体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "宋体；来源 直接run格式"}}, "numbering": null}
- R18:paragraph=5:start=0:end=4:part=label:property=font_eastAsia：{"font": {"eastAsia": {"font": "黑体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "黑体；来源 直接run格式"}}, "numbering": null}
- R18:paragraph=5:start=4:end=18:part=content:property=font_eastAsia：{"font": {"eastAsia": {"font": "宋体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "宋体；来源 直接run格式"}}, "numbering": null}
- R16:paragraph=6:run=1:property=font_ascii：{"font": {"ascii": {"font": "Times New Roman", "slot": "ascii", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "Times New Roman；来源 直接run格式"}}, "numbering": null}
- R17:paragraph=7:run=1:property=font_ascii：{"font": {"ascii": {"font": "Times New Roman", "slot": "ascii", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "Times New Roman；来源 直接run格式"}}, "numbering": null}
- R19:paragraph=8:start=0:end=10:part=label:property=font_ascii：{"font": {"ascii": {"font": "Times New Roman", "slot": "ascii", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "Times New Roman；来源 直接run格式"}}, "numbering": null}
- R19:paragraph=8:start=10:end=51:part=content:property=font_ascii：{"font": {"ascii": {"font": "Times New Roman", "slot": "ascii", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "Times New Roman；来源 直接run格式"}}, "numbering": null}
- R20:paragraph=20:run=1:property=font_eastAsia：{"font": {"eastAsia": {"font": "黑体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "黑体；来源 直接run格式"}}, "numbering": null}
- R21:paragraph=21:run=1:property=font_eastAsia：{"font": {"eastAsia": {"font": "宋体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "宋体；来源 直接run格式"}}, "numbering": null}

## 修改依赖提示

没有已预测的关联影响；不表示不存在其他未支持依赖。

## 覆盖提示

- {"paragraph": 17}：人工分类仍标为待确认，未应用正文/标题/题注规则
- {"paragraph": 18}：人工分类仍标为待确认，未应用正文/标题/题注规则

## 封面、页眉页脚与页码边界

