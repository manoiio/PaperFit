# 论文有格修改记录

输出：fixed.docx
配置：用户确认的组合演示要求（正文及标题题注）（段落及摘要关键词参考文献） vrule-bundle-1+template-demo-6.0.0+extended-demo-1.0.0+sections-demo-1.0
模板结构版本：6
配置SHA256：f899d231fc7797029657b38d8fe997c13b6b86acd0b1418b8c370c6d3d9f02be

| 规则 | 位置 | 修改前 | 修改后 | 落盘复查 | 依据 |
| --- | --- | --- | --- | --- | --- |
| R29 · section_pages | {"section": 1} | null | {"kind": "new_section", "start": 2} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 1} | null | {"kind": "new_section", "start": 5} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 1} | null | {"kind": "new_section", "start": 35} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 1} | null | {"kind": "footer", "section": 1, "variant": "default", "old_part": null, "new_part": "word/footerPF1.xml", "role": "cover", "format": "decimal", "restart": null, "text": "", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 2} | null | {"kind": "footer", "section": 2, "variant": "default", "old_part": null, "new_part": "word/footerPF2.xml", "role": "front", "format": "lowerRoman", "restart": 1, "text": "", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 3} | null | {"kind": "footer", "section": 3, "variant": "default", "old_part": null, "new_part": "word/footerPF3.xml", "role": "body", "format": "decimal", "restart": 1, "text": "研究方法", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 4} | null | {"kind": "footer", "section": 4, "variant": "default", "old_part": null, "new_part": "word/footerPF4.xml", "role": "body", "format": "decimal", "restart": null, "text": "研究方法", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |

## 分节页码结构事务
已生成PAGE并验证受控新增/克隆部件及分节。未计算域缓存、目录或实际页码；真实渲染/Word观察另行记录。
{"input_sha256": "fb33a5b253fde317abcff74d7b49f29494b93c5d4ba2c22430a89ccf5a2a4f96", "output_sha256": "8d241ee2dfa60ce8720c4fcb772cddc4d0fb6ff1c8460acbd095113ca5a269f0", "new_parts": ["word/footerPF1.xml", "word/footerPF2.xml", "word/footerPF3.xml", "word/footerPF4.xml"], "changed_parts": ["[Content_Types].xml", "word/_rels/document.xml.rels", "word/document.xml"], "main_object_order_preserved": true, "physical_pages_not_computed": true}

轮次与输入来源：{"number": 2, "input_round": 1, "input_sha256": "fb33a5b253fde317abcff74d7b49f29494b93c5d4ba2c22430a89ccf5a2a4f96", "original_sha256": "65bfb8b5b3deda256327fdfa08c3d3b073da41a115d71caa9c4d0a115781834e", "rules_version": "rule-bundle-1+template-demo-6.0.0+extended-demo-1.0.0+sections-demo-1.0", "rules_sha256": "f899d231fc7797029657b38d8fe997c13b6b86acd0b1418b8c370c6d3d9f02be", "backmatter_sha256": "73a31b9d434d3a2cce82aba538b3e8cc7f86ea00b6791a08ba7c21f127902864"}

问题变化（已解决/原有剩余/新出现）：{"resolved_keys": [], "unresolved_review_keys": [], "not_applicable_keys": [], "remaining_keys": ["R11:paragraph=15", "R11:paragraph=25", "R11:paragraph=35", "R11:paragraph=5", "R22:document=1:property=中文摘要字数", "R22:document=1:property=参考文献条目数"], "new_keys": [], "new_problem_causes": []}

未强制修正的待复核项：[]

完整性验证：{"input_sha256": "fb33a5b253fde317abcff74d7b49f29494b93c5d4ba2c22430a89ccf5a2a4f96", "output_sha256": "8d241ee2dfa60ce8720c4fcb772cddc4d0fb6ff1c8460acbd095113ca5a269f0", "new_parts": ["word/footerPF1.xml", "word/footerPF2.xml", "word/footerPF3.xml", "word/footerPF4.xml"], "changed_parts": ["[Content_Types].xml", "word/_rels/document.xml.rels", "word/document.xml"], "main_object_order_preserved": true, "physical_pages_not_computed": true}
