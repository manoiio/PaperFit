# 论文有格修改记录

输出：fixed.docx
配置：用户确认的组合演示要求（正文及标题题注）（段落及摘要关键词参考文献） vrule-bundle-1+template-demo-6.0.0+extended-demo-1.0.0+sections-demo-1.0
模板结构版本：6
配置SHA256：f899d231fc7797029657b38d8fe997c13b6b86acd0b1418b8c370c6d3d9f02be

| 规则 | 位置 | 修改前 | 修改后 | 落盘复查 | 依据 |
| --- | --- | --- | --- | --- | --- |
| L03 · keepNext | {"paragraph": 2} | false | true | 符合 | 产品辅助L03（用户确认）：仅所选段落分页属性；表达相邻意图，不保证实际同页。 |
| L03 · keepLines | {"paragraph": 2} | false | true | 符合 | 产品辅助L03（用户确认）：仅所选段落分页属性；表达相邻意图，不保证实际同页。 |

已设置标题与匹配内容相邻属性。未检测实际分页；只表达相邻意图，长表仍可跨页，过长标题或后续内容可能无法同页。请在所用渲染环境人工查看。
这是独立产品排版辅助，不计入R01–R12学校演示格式规则；尚未自动验证分页。

## 本次安全图表与分页辅助
{"summary": {"stage": "pagination", "input_sha256": "8d241ee2dfa60ce8720c4fcb772cddc4d0fb6ff1c8460acbd095113ca5a269f0", "objects": [{"key": "L03:2:3", "status": "selected", "reason": "实际XML顺序紧接，建议尚未应用；须确认所选对象"}, {"key": "L03:5:6", "status": "protected", "reason": "非普通段落，待复核"}, {"key": "L03:15:16", "status": "protected", "reason": "非普通段落，待复核"}, {"key": "L03:25:26", "status": "protected", "reason": "非普通段落，待复核"}, {"key": "L03:35:36", "status": "protected", "reason": "非普通段落，待复核"}], "selected_count": 1, "status": "verified", "seconds": 0.3976, "changes": 2, "output_sha256": "1ad31f3aabf59de7d53838d46a77b79466ee4eadb366675dfcf52da92c9434b4"}, "adoption": {"fix_calls": 0, "input_auto_switched": false}}

轮次与输入来源：{"number": 3, "input_round": 2, "input_sha256": "8d241ee2dfa60ce8720c4fcb772cddc4d0fb6ff1c8460acbd095113ca5a269f0", "original_sha256": "65bfb8b5b3deda256327fdfa08c3d3b073da41a115d71caa9c4d0a115781834e", "rules_version": "rule-bundle-1+template-demo-6.0.0+extended-demo-1.0.0+sections-demo-1.0", "rules_sha256": "f899d231fc7797029657b38d8fe997c13b6b86acd0b1418b8c370c6d3d9f02be", "backmatter_sha256": "73a31b9d434d3a2cce82aba538b3e8cc7f86ea00b6791a08ba7c21f127902864"}

问题变化（已解决/原有剩余/新出现）：{"resolved_keys": [], "unresolved_review_keys": [], "not_applicable_keys": [], "remaining_keys": ["R11:paragraph=15", "R11:paragraph=25", "R11:paragraph=35", "R11:paragraph=5", "R22:document=1:property=中文摘要字数", "R22:document=1:property=参考文献条目数"], "new_keys": [], "new_problem_causes": []}

未强制修正的待复核项：[]

完整性验证：{"original_sha256_unchanged": true, "document_except_selected_format_attributes_equal": true, "other_zip_member_bytes_equal": true, "verified_objects": "完整主文档XML仅掩码所选段落keepNext/keepLines或所选表格行tblHeader；其他ZIP成员字节相同，含图片尺寸、媒体、字段、表格内容尺寸合并、编号和分节。"}
