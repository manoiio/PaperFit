# 论文有格检查报告

规则：用户确认的组合演示要求（正文及标题题注）（段落及摘要关键词参考文献） vrule-bundle-1+template-demo-6.0.0+extended-demo-1.0.0+sections-demo-1.0
规则配置SHA256：f899d231fc7797029657b38d8fe997c13b6b86acd0b1418b8c370c6d3d9f02be
统一规则包结构版本：1；摘录哈希：e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
四模块配置：{"main": {"configured": true, "version": 6, "sha256": "f096f48c1da4f01a1263f94fdbc36c18c8c6636e65f075f6047685cb0b245740"}, "front": {"configured": false, "version": null, "sha256": null}, "toc": {"configured": false, "version": null, "sha256": null}, "notes": {"configured": false, "version": null, "sha256": null}}
明确不检查字段：[]；配置不确认对象，参与范围以本轮coverage为准。
模板结构版本：6；兼容转换：null
输入：fixed.docx
SHA256：fb33a5b253fde317abcff74d7b49f29494b93c5d4ba2c22430a89ccf5a2a4f96

启用规则 26 条；实际适用 14 条；问题 6 个；待复核 85 个（规则记录 75，覆盖提示 10）。
结论：已覆盖检查发现问题。仅针对已覆盖范围，不表示全文合格。

格式属性结果不包含实际分页和所有可见排版验收；页面预览及Word查看需另行人工复核。

## 覆盖范围

{"body_paragraphs": [6, 7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 18, 19, 20, 21, 22, 23, 24, 26, 27, 28, 29, 30, 31, 32, 33, 34, 36, 37, 38, 39, 40, 41, 42, 43, 44], "total_top_level_paragraphs": 44, "unconfirmed_paragraphs": [1], "ordinary_runs_checked": 35, "special_runs_skipped": 5, "section_count": 1, "excluded": "其他/待确认段落、表格内格式、页眉页脚、脚注/文本框；特殊结构继续保护。不检查题注位置、编号及全文合格。", "paragraph_types": {"1": "pending", "2": "abstract_cn_title", "3": "abstract_cn_body", "4": "other", "5": "heading1", "6": "body", "7": "body", "8": "body", "9": "body", "10": "body", "11": "body", "12": "body", "13": "body", "14": "body", "15": "heading2", "16": "body", "17": "body", "18": "body", "19": "body", "20": "body", "21": "body", "22": "body", "23": "body", "24": "body", "25": "heading3", "26": "body", "27": "body", "28": "body", "29": "body", "30": "body", "31": "body", "32": "body", "33": "body", "34": "body", "35": "heading1", "36": "body", "37": "body", "38": "body", "39": "body", "40": "body", "41": "body", "42": "body", "43": "body", "44": "body"}, "classification_confirmation": "一站式开始命令授权（可安全识别对象，非旧勾选）：0b85e562ff9f49acb43f36ccce97e389:b6f32ab4673065ad105df4a276aca131e4a7ab8271597c3090dc8663bbfe787c", "confirmed_typed_paragraphs": [2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44], "disabled_academic_properties": {"body": ["before", "after", "alignment", "bold"], "heading1": ["bold"], "heading2": ["bold"], "heading3": ["bold"], "figure_caption": ["before", "after", "alignment", "bold"], "table_caption": ["before", "after", "alignment", "bold"], "abstract_cn_title": ["font_western", "first_line_indent", "bold"], "abstract_cn_body": ["font_western", "before", "after", "alignment", "bold"], "abstract_en_title": ["font_cn", "first_line_indent", "bold"], "abstract_en_body": ["font_cn", "first_line_indent", "before", "after", "bold"], "keywords_cn": ["before", "after", "line_spacing", "first_line_indent", "label_font_western", "label_bold", "content_font_western", "content_bold"], "keywords_en": ["before", "after", "line_spacing", "first_line_indent", "label_font_cn", "content_font_cn", "content_bold"], "reference_title": ["font_western", "first_line_indent", "bold"], "reference_item": ["font_western", "first_line_indent", "before", "after", "alignment", "bold"], "appendix_title": ["font_western", "before", "after", "first_line_indent", "bold"], "appendix_text": ["font_western", "alignment", "line_spacing", "before", "after", "first_line_indent", "bold"], "ack_title": ["font_cn", "font_western", "font_size", "alignment", "line_spacing", "before", "after", "first_line_indent", "bold"], "ack_text": ["font_cn", "font_western", "font_size", "alignment", "line_spacing", "before", "after", "first_line_indent", "bold"]}, "academic_unchecked_requirements": ["外文参考文献2篇以上及主要文献身份、指导教师例外未自动判断（学校PDF物理页16）；需人工核对。", "中英文摘要/关键词的语义一致性、关键词层次及著录真实性未检查；不生成或改写内容。"], "academic_property_scope": "本清单列已启用的通用/章节属性（含确认附录致谢时R38–R41）；正文/标题/题注原R01–R12要求仍按其规则独立执行。", "backmatter_limits": ["附录和致谢按需存在，没有时不判缺项。", "附录普通文字须明确确认适用文献正文解释；代码、数据、运行输出、图表及其他材料不能整章套用。", "致谢范例物理页38仅显示标题与省略号，未提供可可靠执行的字体字号行距要求；致谢默认属性均未启用。", "内容、代码正确性、致谢是否适当、目录实际页码及所有排版行为未验证。"], "material_exclusions": {}, "backmatter_confirmed_objects": [], "explicitly_not_checked_fields": []}

## 逐项检查

| 规则 | 位置 | 实际值 | 要求值 | 状态 | 可修正 | 依据 |
| --- | --- | --- | --- | --- | --- | --- |
| R01 | {"section": 1} | {"w_mm": 210.009, "h_mm": 297.004} | {"width_mm": 210, "height_mm": 297} | 符合 | 否 | 用户确认的演示模板：纸张=A4 portrait：用户选择沿用默认值（默认PDF物理页20：编排并打印在标准A4纸上） |
| R02 | {"section": 1} | {"top_mm": 24.994, "bottom_mm": 24.994, "left_mm": 24.994, "right_mm": 24.994} | {"top_mm": 25, "bottom_mm": 25, "left_mm": 25, "right_mm": 25} | 符合 | 否 | 用户确认的演示模板：上边距=25：用户选择沿用默认值（默认PDF物理页20：所有页面的上下左右页面边距为25mm）；下边距=25：用户选择沿用默认值（默认PDF物理页20：所有页面的上下左右页面边距为25mm）；左边距=25：用户选择沿用默认值（默认PDF物理页20：所有页面的上下左右页面边距为25mm）；右边距=25：用户选择沿用默认值（默认PDF物理页20：所有页面的上下左右页面边距为25mm） |
| R03 | {"paragraph": 6, "run": 1} | {"eastAsia": "宋体"} | "宋体" | 符合 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 6, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 6, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R03 | {"paragraph": 6, "run": 2} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 6, "run": 2} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 6, "run": 2} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 6} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 6} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 7, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 7, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 7, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 7} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 7} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 8, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 8, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 8, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 8} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 8} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R06 | {"paragraph": 9} | null | 1.5 | 待复核：无可确认的普通正文文字 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 9} | null | 2 | 待复核：无可确认的普通正文文字 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 10, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 10, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 10, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 10} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 10} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 11, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 11, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 11, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 11} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 11} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 12, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 12, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 12, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 12} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 12} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 13, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 13, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 13, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 13} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 13} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 14, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 14, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 14, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 14} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 14} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 16, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 16, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 16, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 16} | 1.15倍 | 1.5 | 待复核：混有特殊run或文档网格，段落行距不自动修正 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 16} | {"first_line_chars": null, "first_line_pt": null, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 待复核：特殊run、编号、异常属性或继承悬挂缩进：不改段落缩进 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 17, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 17, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 17, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 17} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 17} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 18, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 18, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 18, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 18} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 18} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 19, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 19, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 19, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 19} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 19} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 20, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 20, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 20, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 20} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 20} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 21, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 21, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 21, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 21} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 21} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 22, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 22, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 22, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 22} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 22} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 23, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 23, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 23, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 23} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 23} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R06 | {"paragraph": 24} | null | 1.5 | 待复核：无可确认的普通正文文字 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 24} | null | 2 | 待复核：无可确认的普通正文文字 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 26, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 26, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 26, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 26} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 26} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 27, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 27, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 27, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 27} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 27} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 28, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 28, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 28, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 28} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 28} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 29, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 29, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 29, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 29} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 29} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 30, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 30, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 30, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 30} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 30} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 31, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 31, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 31, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 31} | 1.15倍 | 1.5 | 待复核：混有特殊run或文档网格，段落行距不自动修正 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 31} | {"first_line_chars": null, "first_line_pt": null, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 待复核：特殊run、编号、异常属性或继承悬挂缩进：不改段落缩进 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 32, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 32, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 32, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 32} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 32} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 33, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 33, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 33, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 33} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 33} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 34, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 34, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 34, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 34} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 34} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 36, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 36, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 36, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 36} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 36} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 37, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 37, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 37, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 37} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 37} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 38, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 38, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 38, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 38} | 1.15倍 | 1.5 | 待复核：混有特殊run或文档网格，段落行距不自动修正 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 38} | {"first_line_chars": null, "first_line_pt": null, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 待复核：特殊run、编号、异常属性或继承悬挂缩进：不改段落缩进 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 39, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 39, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 39, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 39} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 39} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 40, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 40, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 40, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 40} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 40} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 41, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 41, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 41, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 41} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 41} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 42, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 42, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 42, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 42} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 42} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 43, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 43, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 43, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 43} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 43} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R03 | {"paragraph": 44, "run": 1} | {"eastAsia": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | "宋体" | 待复核：eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：正文中文字体=宋体：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R04 | {"paragraph": 44, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 44, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：用户选择沿用默认值（默认PDF物理页18：正文：小四号） |
| R06 | {"paragraph": 44} | 1.5倍 | 1.5 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=1.5：用户选择沿用默认值（默认PDF物理页18：正文：小四号，宋体，1.5倍行距） |
| R07 | {"paragraph": 44} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：用户选择沿用默认值（默认PDF物理页18：段首行缩进2个汉字） |
| R08 | {"paragraph": 5, "property": "numbering_symbol"} | {"unresolved": "样式中的numPr涉及层级绑定；本阶段不解析样式链接编号"} | {"font": "Times New Roman", "pt": 18} | 待复核：样式中的numPr涉及层级绑定；本阶段不解析样式链接编号；标题普通文字仍独立检查 | 否 | 编号符号只读对照（来源分开）：西文/数字字体沿用固定Times New Roman；字号取确认的本级标题值：一级标题字号=18：用户选择沿用默认值 |
| R08 | {"paragraph": 5, "run": 1, "property": "font_eastAsia"} | {"slot": "eastAsia", "font": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | {"slot": "eastAsia", "font": "黑体"} | 待复核：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：一级标题中文字体=黑体：用户选择沿用默认值 |
| R08 | {"paragraph": 5, "run": 1, "property": "size"} | {"pt": 18.0} | {"pt": 18} | 符合 | 否 | 用户确认的演示模板：一级标题字号=18：用户选择沿用默认值 |
| R08 | {"paragraph": 5, "property": "alignment"} | {"alignment": "left"} | {"alignment": "center"} | 待复核：编号段落对齐属性：样式中的numPr涉及层级绑定；本阶段不解析样式链接编号；文字字体字号仍独立检查 | 否 | 用户确认的演示模板：一级标题对齐=center：用户选择沿用默认值 |
| R08 | {"paragraph": 5, "property": "line"} | 1.15倍 | {"multiple": 1} | 待复核：编号段落行距：样式中的numPr涉及层级绑定；本阶段不解析样式链接编号；文字字体字号仍独立检查 | 否 | 用户确认的演示模板：一级标题倍数行距=1：用户选择沿用默认值 |
| R11 | {"paragraph": 5} | {"style_id": "1", "outline_level": 0} | {"style_id": "Heading1", "outline_level": 0} | 问题：实际Heading样式/大纲与确认类型不符；numPr绑定编号，切换样式可能改变层级、起点或连续性，本阶段不可自动修正。请在Word人工核对样式与编号联动。 | 否 | 产品结构规则：使用已存在且可验证的内置Heading 1–3及对应大纲级别；保持其他有效格式，不是学校明确规定英文样式名。 |
| R09 | {"paragraph": 15, "property": "numbering_symbol"} | {"font": null, "size_pt": null} | {"font": "Times New Roman", "pt": 15} | 待复核：编号层级rPr未明确指定ASCII字体；段落标记/符号继承尚未解析，不借用标题文字或docDefaults作编号字体证明 | 否 | 编号符号只读对照（来源分开）：西文/数字字体沿用固定Times New Roman；字号取确认的本级标题值：二级标题字号=15：用户选择沿用默认值 |
| R09 | {"paragraph": 15, "run": 1, "property": "font_eastAsia"} | {"slot": "eastAsia", "font": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | {"slot": "eastAsia", "font": "黑体"} | 待复核：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：二级标题中文字体=黑体：用户选择沿用默认值 |
| R09 | {"paragraph": 15, "run": 1, "property": "size"} | {"pt": 15.0} | {"pt": 15} | 符合 | 否 | 用户确认的演示模板：二级标题字号=15：用户选择沿用默认值 |
| R09 | {"paragraph": 15, "property": "alignment"} | {"alignment": "left"} | {"alignment": "left"} | 符合 | 否 | 用户确认的演示模板：二级标题对齐=left：用户选择沿用默认值 |
| R09 | {"paragraph": 15, "property": "line"} | 1倍 | {"multiple": 1} | 符合 | 否 | 用户确认的演示模板：二级标题倍数行距=1：用户选择沿用默认值 |
| R11 | {"paragraph": 15} | {"style_id": "2", "outline_level": 1} | {"style_id": "Heading2", "outline_level": 1} | 问题：实际Heading样式/大纲与确认类型不符；numPr绑定编号，切换样式可能改变层级、起点或连续性，本阶段不可自动修正。请在Word人工核对样式与编号联动。 | 否 | 产品结构规则：使用已存在且可验证的内置Heading 1–3及对应大纲级别；保持其他有效格式，不是学校明确规定英文样式名。 |
| R10 | {"paragraph": 25, "property": "numbering_symbol"} | {"font": null, "size_pt": null} | {"font": "Times New Roman", "pt": 14} | 待复核：编号层级rPr未明确指定ASCII字体；段落标记/符号继承尚未解析，不借用标题文字或docDefaults作编号字体证明 | 否 | 编号符号只读对照（来源分开）：西文/数字字体沿用固定Times New Roman；字号取确认的本级标题值：三级标题字号=14：用户选择沿用默认值 |
| R10 | {"paragraph": 25, "run": 1, "property": "font_eastAsia"} | {"slot": "eastAsia", "font": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | {"slot": "eastAsia", "font": "黑体"} | 待复核：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：三级标题中文字体=黑体：用户选择沿用默认值 |
| R10 | {"paragraph": 25, "run": 1, "property": "size"} | {"pt": 14.0} | {"pt": 14} | 符合 | 否 | 用户确认的演示模板：三级标题字号=14：用户选择沿用默认值 |
| R10 | {"paragraph": 25, "property": "alignment"} | {"alignment": "left"} | {"alignment": "left"} | 符合 | 否 | 用户确认的演示模板：三级标题对齐=left：用户选择沿用默认值 |
| R10 | {"paragraph": 25, "property": "line"} | 1倍 | {"multiple": 1} | 符合 | 否 | 用户确认的演示模板：三级标题倍数行距=1：用户选择沿用默认值 |
| R11 | {"paragraph": 25} | {"style_id": "3", "outline_level": 2} | {"style_id": "Heading3", "outline_level": 2} | 问题：实际Heading样式/大纲与确认类型不符；numPr绑定编号，切换样式可能改变层级、起点或连续性，本阶段不可自动修正。请在Word人工核对样式与编号联动。 | 否 | 产品结构规则：使用已存在且可验证的内置Heading 1–3及对应大纲级别；保持其他有效格式，不是学校明确规定英文样式名。 |
| R08 | {"paragraph": 35, "property": "numbering_symbol"} | {"unresolved": "样式中的numPr涉及层级绑定；本阶段不解析样式链接编号"} | {"font": "Times New Roman", "pt": 18} | 待复核：样式中的numPr涉及层级绑定；本阶段不解析样式链接编号；标题普通文字仍独立检查 | 否 | 编号符号只读对照（来源分开）：西文/数字字体沿用固定Times New Roman；字号取确认的本级标题值：一级标题字号=18：用户选择沿用默认值 |
| R08 | {"paragraph": 35, "run": 1, "property": "font_eastAsia"} | {"slot": "eastAsia", "font": {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围", "slot": "eastAsia"}} | {"slot": "eastAsia", "font": "黑体"} | 待复核：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 用户确认的演示模板：一级标题中文字体=黑体：用户选择沿用默认值 |
| R08 | {"paragraph": 35, "run": 1, "property": "size"} | {"pt": 18.0} | {"pt": 18} | 符合 | 否 | 用户确认的演示模板：一级标题字号=18：用户选择沿用默认值 |
| R08 | {"paragraph": 35, "property": "alignment"} | {"alignment": "left"} | {"alignment": "center"} | 待复核：编号段落对齐属性：样式中的numPr涉及层级绑定；本阶段不解析样式链接编号；文字字体字号仍独立检查 | 否 | 用户确认的演示模板：一级标题对齐=center：用户选择沿用默认值 |
| R08 | {"paragraph": 35, "property": "line"} | 1.15倍 | {"multiple": 1} | 待复核：编号段落行距：样式中的numPr涉及层级绑定；本阶段不解析样式链接编号；文字字体字号仍独立检查 | 否 | 用户确认的演示模板：一级标题倍数行距=1：用户选择沿用默认值 |
| R11 | {"paragraph": 35} | {"style_id": "1", "outline_level": 0} | {"style_id": "Heading1", "outline_level": 0} | 问题：实际Heading样式/大纲与确认类型不符；numPr绑定编号，切换样式可能改变层级、起点或连续性，本阶段不可自动修正。请在Word人工核对样式与编号联动。 | 否 | 产品结构规则：使用已存在且可验证的内置Heading 1–3及对应大纲级别；保持其他有效格式，不是学校明确规定英文样式名。 |
| R12 | {"document": 1} | null | {"figure_caption": {"font_cn": "宋体", "font_latin": "宋体", "size_pt": 10.5}, "table_caption": {"font_cn": "宋体", "font_latin": "宋体", "size_pt": 10.5}} | 不适用：本次确认分类中没有该类对象，不凭空报错 | 否 | 用户确认的标题题注配置：图题中文字体=宋体：用户选择沿用默认值；图题字号=10.5：用户选择沿用默认值；表题中文字体=宋体：用户选择沿用默认值；表题字号=10.5：用户选择沿用默认值 |
| R14 | {"paragraph": 2, "property": "before"} | {"unresolved": "有效继承路径也未设置before间距；未按0处理"} | {"value": 0.5, "unit": "lines"} | 待复核：有效继承路径也未设置before间距；未按0处理 | 否 | 用户选择沿用默认值（用户确认v4模板，不冒充学校原文）： |
| R14 | {"paragraph": 2, "property": "after"} | {"value": 0.5, "unit": "lines", "origin": ["docDefaults", "直接段落格式"], "raw": {"after": "0", "line": "240", "lineRule": "auto", "afterAutospacing": "0", "afterLines": "50"}} | {"value": 0.5, "unit": "lines"} | 符合 | 否 | 用户选择沿用默认值（用户确认v4模板，不冒充学校原文）： |
| R14 | {"paragraph": 2, "property": "alignment"} | {"unresolved": "对齐未设置/未支持或无法可靠继承"} | "center" | 待复核：对齐未设置/未支持或无法可靠继承 | 否 | 用户选择沿用默认值（用户确认v4模板，不冒充学校原文）： |
| R14 | {"paragraph": 2, "property": "line_spacing"} | 1倍 | {"multiple": 1} | 符合 | 否 | 用户选择沿用默认值（用户确认v4模板，不冒充学校原文）： |
| R14 | {"paragraph": 2, "run": 1, "property": "font_eastAsia"} | {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围"} | "黑体" | 待复核：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 未配置属性： |
| R14 | {"paragraph": 2, "run": 1, "property": "size"} | 18.0 | 18 | 符合 | 否 | 未配置属性： |
| R15 | {"paragraph": 3, "property": "line_spacing"} | 1.5倍 | {"multiple": 1.5} | 符合 | 否 | 用户选择沿用默认值（用户确认v4模板，不冒充学校原文）： |
| R15 | {"paragraph": 3, "property": "first_line_indent"} | {"unresolved": "首行缩进未明确设置"} | {"chars": 2} | 待复核：首行缩进未明确设置 | 否 | 用户选择沿用默认值（用户确认v4模板，不冒充学校原文）： |
| R15 | {"paragraph": 3, "run": 1, "property": "font_eastAsia"} | {"unresolved": "主题语言 ja-JP 未纳入当前唯一映射范围"} | "宋体" | 待复核：主题语言 ja-JP 未纳入当前唯一映射范围 | 否 | 未配置属性： |
| R15 | {"paragraph": 3, "run": 1, "property": "size"} | 12.0 | 12 | 符合 | 否 | 未配置属性： |
| R13 | {"paragraph": 5, "property": "before"} | {"unresolved": "特殊片段/自动编号段落属性依赖"} | {"value": 0.5, "unit": "lines"} | 待复核：普通文字仍独立检查；不改段落或编号定义 | 否 | 用户选择沿用默认值（用户确认v4模板，不冒充学校原文）： |
| R13 | {"paragraph": 5, "property": "after"} | {"unresolved": "特殊片段/自动编号段落属性依赖"} | {"value": 0.5, "unit": "lines"} | 待复核：普通文字仍独立检查；不改段落或编号定义 | 否 | 用户选择沿用默认值（用户确认v4模板，不冒充学校原文）： |
| R13 | {"paragraph": 15, "property": "before"} | {"unresolved": "特殊片段/自动编号段落属性依赖"} | {"value": 0.5, "unit": "lines"} | 待复核：普通文字仍独立检查；不改段落或编号定义 | 否 | 用户选择沿用默认值（用户确认v4模板，不冒充学校原文）： |
| R13 | {"paragraph": 15, "property": "after"} | {"unresolved": "特殊片段/自动编号段落属性依赖"} | {"value": 0.5, "unit": "lines"} | 待复核：普通文字仍独立检查；不改段落或编号定义 | 否 | 用户选择沿用默认值（用户确认v4模板，不冒充学校原文）： |
| R13 | {"paragraph": 25, "property": "before"} | {"unresolved": "特殊片段/自动编号段落属性依赖"} | {"value": 0.5, "unit": "lines"} | 待复核：普通文字仍独立检查；不改段落或编号定义 | 否 | 用户选择沿用默认值（用户确认v4模板，不冒充学校原文）： |
| R13 | {"paragraph": 25, "property": "after"} | {"unresolved": "特殊片段/自动编号段落属性依赖"} | {"value": 0.5, "unit": "lines"} | 待复核：普通文字仍独立检查；不改段落或编号定义 | 否 | 用户选择沿用默认值（用户确认v4模板，不冒充学校原文）： |
| R13 | {"paragraph": 35, "property": "before"} | {"unresolved": "特殊片段/自动编号段落属性依赖"} | {"value": 0.5, "unit": "lines"} | 待复核：普通文字仍独立检查；不改段落或编号定义 | 否 | 用户选择沿用默认值（用户确认v4模板，不冒充学校原文）： |
| R13 | {"paragraph": 35, "property": "after"} | {"unresolved": "特殊片段/自动编号段落属性依赖"} | {"value": 0.5, "unit": "lines"} | 待复核：普通文字仍独立检查；不改段落或编号定义 | 否 | 用户选择沿用默认值（用户确认v4模板，不冒充学校原文）： |
| R16 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R17 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R18 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R19 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R20 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R21 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R38 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 新对象未配置或当前范围无对象；不推定学校要求/已通过： |
| R39 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 新对象未配置或当前范围无对象；不推定学校要求/已通过： |
| R40 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 新对象未配置或当前范围无对象；不推定学校要求/已通过： |
| R41 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 新对象未配置或当前范围无对象；不推定学校要求/已通过： |
| R22 | {"document": 1, "property": "存在_abstract_cn_title"} | 1 | ">=1" | 符合：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_abstract_cn_body"} | 1 | ">=1" | 符合：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_abstract_en_title"} | 0 | ">=1" | 待复核：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_abstract_en_body"} | 0 | ">=1" | 待复核：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_keywords_cn"} | 0 | ">=1" | 待复核：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_keywords_en"} | 0 | ">=1" | 待复核：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_reference_title"} | 0 | ">=1" | 待复核：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_reference_item"} | 0 | ">=1" | 待复核：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "中文摘要字数"} | 19 | "400–600" | 问题：复杂结构不能宣称计数完整；正文非空白Unicode字符数，标点/数字计入，不含标题或关键词；不生成/扩写摘要 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "参考文献条目数"} | 0 | "确认条目≥10（主要文献/外文身份另核对）" | 问题：按人工确认条目计数；不足时核对范围或资料，不生成文献；不判断主要文献身份、语种或所有著录格式 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |

## 字体及编号只读解析证据

文档指定字体用于属性检查；本机字体安装与替代由独立预览核对。
- R03:paragraph=6:run=1：{"font": {"eastAsia": {"font": "宋体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "eastAsia", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "宋体；来源 直接run格式"}}, "numbering": null}
- R03:paragraph=6:run=2：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=7:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=8:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=10:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=11:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=12:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=13:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=14:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=16:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=17:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=18:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=19:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=20:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=21:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=22:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=23:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=26:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=27:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=28:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=29:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=30:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=31:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=32:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=33:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=34:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=36:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=37:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=38:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=39:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=40:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=41:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=42:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=43:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R03:paragraph=44:run=1：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R08:paragraph=5:property=numbering_symbol：{"font": {}, "numbering": {"present": true, "status": "review", "numbering_xml_modified": false, "reason": "样式中的numPr涉及层级绑定；本阶段不解析样式链接编号", "num_id": "1", "ilvl": 0}}
- R08:paragraph=5:run=1:property=font_eastAsia：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "paragraph样式:1", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "majorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R11:paragraph=5：{"font": null, "numbering": {"present": true, "status": "review", "numbering_xml_modified": false, "reason": "样式中的numPr涉及层级绑定；本阶段不解析样式链接编号", "num_id": "1", "ilvl": 0}}
- R09:paragraph=15:property=numbering_symbol：{"font": {"ascii": {"font": null, "slot": "ascii", "source_type": "missing", "declared_at": null, "hint": "default", "run_language": {}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "reason": "编号层级rPr未明确指定ASCII字体；段落标记/符号继承尚未解析，不借用标题文字或docDefaults作编号字体证明"}}, "numbering": {"present": true, "status": "resolved", "numbering_xml_modified": false, "reason": "numPr→numId→abstractNumId→ilvl已只读核对；不计算编号序列或连续性", "num_id": "1", "ilvl": 1, "abstract_num_id": "9", "symbol_template": "%1.%2"}}
- R09:paragraph=15:run=1:property=font_eastAsia：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "paragraph样式:2", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "majorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R11:paragraph=15：{"font": null, "numbering": {"present": true, "status": "resolved", "numbering_xml_modified": false, "reason": "numPr→numId→abstractNumId→ilvl已只读核对；不计算编号序列或连续性", "num_id": "1", "ilvl": 1, "abstract_num_id": "9", "symbol_template": "%1.%2"}}
- R10:paragraph=25:property=numbering_symbol：{"font": {"ascii": {"font": null, "slot": "ascii", "source_type": "missing", "declared_at": null, "hint": "default", "run_language": {}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "reason": "编号层级rPr未明确指定ASCII字体；段落标记/符号继承尚未解析，不借用标题文字或docDefaults作编号字体证明"}}, "numbering": {"present": true, "status": "resolved", "numbering_xml_modified": false, "reason": "numPr→numId→abstractNumId→ilvl已只读核对；不计算编号序列或连续性", "num_id": "1", "ilvl": 2, "abstract_num_id": "9", "symbol_template": "%1.%2.%3"}}
- R10:paragraph=25:run=1:property=font_eastAsia：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "paragraph样式:3", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "majorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R11:paragraph=25：{"font": null, "numbering": {"present": true, "status": "resolved", "numbering_xml_modified": false, "reason": "numPr→numId→abstractNumId→ilvl已只读核对；不计算编号序列或连续性", "num_id": "1", "ilvl": 2, "abstract_num_id": "9", "symbol_template": "%1.%2.%3"}}
- R08:paragraph=35:property=numbering_symbol：{"font": {}, "numbering": {"present": true, "status": "review", "numbering_xml_modified": false, "reason": "样式中的numPr涉及层级绑定；本阶段不解析样式链接编号", "num_id": "2", "ilvl": 0}}
- R08:paragraph=35:run=1:property=font_eastAsia：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "paragraph样式:1", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "majorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R11:paragraph=35：{"font": null, "numbering": {"present": true, "status": "review", "numbering_xml_modified": false, "reason": "样式中的numPr涉及层级绑定；本阶段不解析样式链接编号", "num_id": "2", "ilvl": 0}}
- R14:paragraph=2:run=1:property=font_eastAsia：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}
- R15:paragraph=3:run=1:property=font_eastAsia：{"font": {"eastAsia": {"font": null, "slot": "eastAsia", "source_type": "missing", "declared_at": "docDefaults", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": false, "theme": "minorEastAsia", "reason": "主题语言 ja-JP 未纳入当前唯一映射范围"}}, "numbering": null}

## 修改依赖提示

没有已预测的关联影响；不表示不存在其他未支持依赖。

## 覆盖提示

- {"paragraph": 9, "run": 1}：图片、域、注释引用或其他非普通run结构：该run未检查、未修正
- {"paragraph": 16, "run": 2}：图片、域、注释引用或其他非普通run结构：该run未检查、未修正
- {"paragraph": 24, "run": 1}：图片、域、注释引用或其他非普通run结构：该run未检查、未修正
- {"paragraph": 31, "run": 2}：图片、域、注释引用或其他非普通run结构：该run未检查、未修正
- {"paragraph": 38, "run": 2}：图片、域、注释引用或其他非普通run结构：该run未检查、未修正
- {"paragraph": 1}：人工分类仍标为待确认，未应用正文/标题/题注规则
- {"paragraph": 5, "property": "numbering_symbol"}：自动编号符号与序列未纳入自动修正；样式中的numPr涉及层级绑定；本阶段不解析样式链接编号；标题普通文字仍独立检查
- {"paragraph": 15, "property": "numbering_symbol"}：自动编号符号与序列未纳入自动修正；编号层级rPr未明确指定ASCII字体；段落标记/符号继承尚未解析，不借用标题文字或docDefaults作编号字体证明
- {"paragraph": 25, "property": "numbering_symbol"}：自动编号符号与序列未纳入自动修正；编号层级rPr未明确指定ASCII字体；段落标记/符号继承尚未解析，不借用标题文字或docDefaults作编号字体证明
- {"paragraph": 35, "property": "numbering_symbol"}：自动编号符号与序列未纳入自动修正；样式中的numPr涉及层级绑定；本阶段不解析样式链接编号；标题普通文字仍独立检查

## 封面、页眉页脚与页码边界

