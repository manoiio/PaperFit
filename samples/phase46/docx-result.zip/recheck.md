# 论文有格检查报告

规则：文件要求覆盖 · 98930eafe95ea55e5c5008abe276cf09d8e468bd31cce6594c8c249f2f00ddae（正文及标题题注）（段落及摘要关键词参考文献） vrule-bundle-1+template-demo-6.0.0+extended-demo-1.0.0+sections-demo-1.0
规则配置SHA256：afffd8daa8ea9a0e60b180e5df877fea5259002de91b1e8630d462f38099200e
统一规则包结构版本：1；摘录哈希：843557b22a2fcc5707b2acd23d4d8a2975e0e1fd83d180205c6e78593cce7d0f
四模块配置：{"main": {"configured": true, "version": 6, "sha256": "745c565bb6d7c152fd52d350339ad105b2e4e6369c9864b406212984e8da1887"}, "front": {"configured": false, "version": null, "sha256": null}, "toc": {"configured": false, "version": null, "sha256": null}, "notes": {"configured": false, "version": null, "sha256": null}}
明确不检查字段：[]；配置不确认对象，参与范围以本轮coverage为准。
模板结构版本：6；兼容转换：null
输入：fixed.docx
SHA256：b978dfe640b08bdc7e37d17c6b37f556d3a04ffeb48ca900c4f3bae1e6bd57a7

启用规则 26 条；实际适用 12 条；问题 1 个；待复核 8 个（规则记录 8，覆盖提示 0）。
结论：已覆盖检查发现问题。仅针对已覆盖范围，不表示全文合格。

格式属性结果不包含实际分页和所有可见排版验收；页面预览及Word查看需另行人工复核。

## 覆盖范围

{"body_paragraphs": [2, 4, 6], "total_top_level_paragraphs": 6, "unconfirmed_paragraphs": [], "ordinary_runs_checked": 3, "special_runs_skipped": 0, "section_count": 1, "excluded": "其他/待确认段落、表格内格式、页眉页脚、脚注/文本框；特殊结构继续保护。不检查题注位置、编号及全文合格。", "paragraph_types": {"1": "heading1", "2": "body", "3": "heading2", "4": "body", "5": "heading3", "6": "body"}, "classification_confirmation": "一站式开始命令授权（可安全识别对象，非旧勾选）：d1f71bfacdc649fda7e9edb9fdc85a1a:d745a743ac544a0ba927019c224a82e0d39ed01bd4353dbff0bfb610ecc5c4ad", "confirmed_typed_paragraphs": [1, 2, 3, 4, 5, 6], "disabled_academic_properties": {"body": ["bold"], "heading1": ["bold"], "heading2": ["bold"], "heading3": ["bold"], "figure_caption": ["before", "after", "alignment", "bold"], "table_caption": ["before", "after", "alignment", "bold"], "abstract_cn_title": ["font_western", "first_line_indent", "bold"], "abstract_cn_body": ["font_western", "before", "after", "alignment", "bold"], "abstract_en_title": ["font_cn", "first_line_indent", "bold"], "abstract_en_body": ["font_cn", "first_line_indent", "before", "after", "bold"], "keywords_cn": ["before", "after", "line_spacing", "first_line_indent", "label_font_western", "label_bold", "content_font_western", "content_bold"], "keywords_en": ["before", "after", "line_spacing", "first_line_indent", "label_font_cn", "content_font_cn", "content_bold"], "reference_title": ["font_western", "first_line_indent", "bold"], "reference_item": ["font_western", "first_line_indent", "before", "after", "alignment", "bold"], "appendix_title": ["font_western", "before", "after", "first_line_indent", "bold"], "appendix_text": ["font_western", "alignment", "line_spacing", "before", "after", "first_line_indent", "bold"], "ack_title": ["font_cn", "font_western", "font_size", "alignment", "line_spacing", "before", "after", "first_line_indent", "bold"], "ack_text": ["font_cn", "font_western", "font_size", "alignment", "line_spacing", "before", "after", "first_line_indent", "bold"]}, "academic_unchecked_requirements": ["外文参考文献2篇以上及主要文献身份、指导教师例外未自动判断（学校PDF物理页16）；需人工核对。", "中英文摘要/关键词的语义一致性、关键词层次及著录真实性未检查；不生成或改写内容。"], "academic_property_scope": "本清单列已启用的通用/章节属性（含确认附录致谢时R38–R41）；正文/标题/题注原R01–R12要求仍按其规则独立执行。", "backmatter_limits": ["附录和致谢按需存在，没有时不判缺项。", "附录普通文字须明确确认适用文献正文解释；代码、数据、运行输出、图表及其他材料不能整章套用。", "致谢范例物理页38仅显示标题与省略号，未提供可可靠执行的字体字号行距要求；致谢默认属性均未启用。", "内容、代码正确性、致谢是否适当、目录实际页码及所有排版行为未验证。"], "material_exclusions": {}, "backmatter_confirmed_objects": [], "explicitly_not_checked_fields": []}

## 逐项检查

| 规则 | 位置 | 实际值 | 要求值 | 状态 | 可修正 | 依据 |
| --- | --- | --- | --- | --- | --- | --- |
| R01 | {"section": 1} | {"w_mm": 210.009, "h_mm": 297.004} | {"width_mm": 210, "height_mm": 297} | 符合 | 否 | 用户确认的演示模板：纸张=A4 portrait：用户选择沿用默认值（默认PDF物理页20：编排并打印在标准A4纸上） |
| R02 | {"section": 1} | {"top_mm": 24.994, "bottom_mm": 24.994, "left_mm": 24.994, "right_mm": 24.994} | {"top_mm": 25, "bottom_mm": 25, "left_mm": 25, "right_mm": 25} | 符合 | 否 | 用户确认的演示模板：上边距=25：用户选择沿用默认值（默认PDF物理页20：所有页面的上下左右页面边距为25mm）；下边距=25：用户选择沿用默认值（默认PDF物理页20：所有页面的上下左右页面边距为25mm）；左边距=25：用户选择沿用默认值（默认PDF物理页20：所有页面的上下左右页面边距为25mm）；右边距=25：用户选择沿用默认值（默认PDF物理页20：所有页面的上下左右页面边距为25mm） |
| R03 | {"paragraph": 2, "run": 1} | {"eastAsia": "宋体"} | "宋体" | 符合 | 否 | 用户确认的演示模板：正文中文字体=宋体：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：正文宋体） |
| R04 | {"paragraph": 2, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 2, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：正文宋体小四） |
| R06 | {"paragraph": 2} | {"line_rule": "auto", "multiple": 2.0, "pt": null} | 2 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=2：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：正文宋体小四，首行缩进两字符，2倍） |
| R07 | {"paragraph": 2} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：正文宋体小四，首行缩进两字） |
| R03 | {"paragraph": 4, "run": 1} | {"eastAsia": "宋体"} | "宋体" | 符合 | 否 | 用户确认的演示模板：正文中文字体=宋体：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：正文宋体） |
| R04 | {"paragraph": 4, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 4, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：正文宋体小四） |
| R06 | {"paragraph": 4} | {"line_rule": "auto", "multiple": 2.0, "pt": null} | 2 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=2：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：正文宋体小四，首行缩进两字符，2倍） |
| R07 | {"paragraph": 4} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：正文宋体小四，首行缩进两字） |
| R03 | {"paragraph": 6, "run": 1} | {"eastAsia": "宋体"} | "宋体" | 符合 | 否 | 用户确认的演示模板：正文中文字体=宋体：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：正文宋体） |
| R04 | {"paragraph": 6, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 用户确认的演示模板：正文西文字体=Times New Roman：用户选择沿用默认值（默认PDF物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman） |
| R05 | {"paragraph": 6, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 用户确认的演示模板：正文普通文字字号=12：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：正文宋体小四） |
| R06 | {"paragraph": 6} | {"line_rule": "auto", "multiple": 2.0, "pt": null} | 2 | 符合 | 否 | 用户确认的演示模板：正文倍数行距=2：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：正文宋体小四，首行缩进两字符，2倍） |
| R07 | {"paragraph": 6} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 用户确认的演示模板：正文首行缩进=2：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：正文宋体小四，首行缩进两字） |
| R08 | {"paragraph": 1, "run": 1, "property": "font_ascii"} | {"slot": "ascii", "font": "Times New Roman"} | {"slot": "ascii", "font": "Times New Roman"} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：各章题序的阿拉伯数字用Times New Roman体；英文单词字体为Times New Roman |
| R08 | {"paragraph": 1, "run": 1, "property": "font_eastAsia"} | {"slot": "eastAsia", "font": "黑体"} | {"slot": "eastAsia", "font": "黑体"} | 符合 | 否 | 用户确认的演示模板：一级标题中文字体=黑体：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：一级标题黑体） |
| R08 | {"paragraph": 1, "run": 1, "property": "size"} | {"pt": 16.0} | {"pt": 16} | 符合 | 否 | 用户确认的演示模板：一级标题字号=16：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：一级标题黑体三号） |
| R08 | {"paragraph": 1, "property": "alignment"} | {"alignment": "center"} | {"alignment": "center"} | 符合 | 否 | 用户确认的演示模板：一级标题对齐=center：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：一级标题黑体三号居中） |
| R08 | {"paragraph": 1, "property": "line"} | {"line_rule": "auto", "multiple": 1.0, "pt": null} | {"multiple": 1} | 符合 | 否 | 用户确认的演示模板：一级标题倍数行距=1：用户选择沿用默认值 |
| R11 | {"paragraph": 1} | {"style_id": "Heading1", "outline_level": 0} | {"style_id": "Heading1", "outline_level": 0} | 符合 | 否 | 产品结构规则：使用已存在且可验证的内置Heading 1–3及对应大纲级别；保持其他有效格式，不是学校明确规定英文样式名。 |
| R09 | {"paragraph": 3, "run": 1, "property": "font_ascii"} | {"slot": "ascii", "font": "Times New Roman"} | {"slot": "ascii", "font": "Times New Roman"} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：各章题序的阿拉伯数字用Times New Roman体；英文单词字体为Times New Roman |
| R09 | {"paragraph": 3, "run": 1, "property": "font_eastAsia"} | {"slot": "eastAsia", "font": "宋体"} | {"slot": "eastAsia", "font": "宋体"} | 符合 | 否 | 用户确认的演示模板：二级标题中文字体=宋体：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：二级标题宋体） |
| R09 | {"paragraph": 3, "run": 1, "property": "size"} | {"pt": 12.0} | {"pt": 12} | 符合 | 否 | 用户确认的演示模板：二级标题字号=12：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：二级标题宋体小四） |
| R09 | {"paragraph": 3, "property": "alignment"} | {"alignment": "left"} | {"alignment": "left"} | 符合 | 否 | 用户确认的演示模板：二级标题对齐=left：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：二级标题宋体小四居左） |
| R09 | {"paragraph": 3, "property": "line"} | {"line_rule": "auto", "multiple": 1.0, "pt": null} | {"multiple": 1} | 符合 | 否 | 用户确认的演示模板：二级标题倍数行距=1：用户选择沿用默认值 |
| R11 | {"paragraph": 3} | {"style_id": "Heading2", "outline_level": 1} | {"style_id": "Heading2", "outline_level": 1} | 符合 | 否 | 产品结构规则：使用已存在且可验证的内置Heading 1–3及对应大纲级别；保持其他有效格式，不是学校明确规定英文样式名。 |
| R10 | {"paragraph": 5, "run": 1, "property": "font_ascii"} | {"slot": "ascii", "font": "Times New Roman"} | {"slot": "ascii", "font": "Times New Roman"} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：各章题序的阿拉伯数字用Times New Roman体；英文单词字体为Times New Roman |
| R10 | {"paragraph": 5, "run": 1, "property": "font_eastAsia"} | {"slot": "eastAsia", "font": "黑体"} | {"slot": "eastAsia", "font": "黑体"} | 符合 | 否 | 用户确认的演示模板：三级标题中文字体=黑体：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：三级标题黑体） |
| R10 | {"paragraph": 5, "run": 1, "property": "size"} | {"pt": 12.0} | {"pt": 12} | 符合 | 否 | 用户确认的演示模板：三级标题字号=12：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：三级标题黑体小四） |
| R10 | {"paragraph": 5, "property": "alignment"} | {"alignment": "left"} | {"alignment": "left"} | 符合 | 否 | 用户确认的演示模板：三级标题对齐=left：AI从原文提取后确认（SRC:e350baa99507f3c5d6fb0c1dd2682281015cda800b2e807e9ae5177c9ac56381:DOCX:P1：三级标题黑体小四居左） |
| R10 | {"paragraph": 5, "property": "line"} | {"line_rule": "auto", "multiple": 1.0, "pt": null} | {"multiple": 1} | 符合 | 否 | 用户确认的演示模板：三级标题倍数行距=1：用户选择沿用默认值 |
| R11 | {"paragraph": 5} | {"style_id": "Heading3", "outline_level": 2} | {"style_id": "Heading3", "outline_level": 2} | 符合 | 否 | 产品结构规则：使用已存在且可验证的内置Heading 1–3及对应大纲级别；保持其他有效格式，不是学校明确规定英文样式名。 |
| R12 | {"document": 1} | null | {"figure_caption": {"font_cn": "宋体", "font_latin": "宋体", "size_pt": 10.5}, "table_caption": {"font_cn": "宋体", "font_latin": "宋体", "size_pt": 10.5}} | 不适用：本次确认分类中没有该类对象，不凭空报错 | 否 | 用户确认的标题题注配置：图题中文字体=宋体：用户选择沿用默认值；图题字号=10.5：用户选择沿用默认值；表题中文字体=宋体：用户选择沿用默认值；表题字号=10.5：用户选择沿用默认值 |
| R13 | {"paragraph": 1, "property": "before"} | {"value": 0.5, "unit": "lines", "origin": ["docDefaults", "paragraph样式:Heading1", "直接段落格式"], "raw": {"after": "0", "line": "240", "lineRule": "auto", "before": "0", "beforeAutospacing": "0", "beforeLines": "50", "afterAutospacing": "0", "afterLines": "50"}} | {"value": 0.5, "unit": "lines"} | 符合 | 否 | 用户选择沿用默认值（用户确认v4模板，不冒充学校原文）： |
| R13 | {"paragraph": 1, "property": "after"} | {"value": 0.5, "unit": "lines", "origin": ["docDefaults", "paragraph样式:Heading1", "直接段落格式"], "raw": {"after": "0", "line": "240", "lineRule": "auto", "before": "0", "beforeAutospacing": "0", "beforeLines": "50", "afterAutospacing": "0", "afterLines": "50"}} | {"value": 0.5, "unit": "lines"} | 符合 | 否 | 用户选择沿用默认值（用户确认v4模板，不冒充学校原文）： |
| R13 | {"paragraph": 2, "property": "before"} | {"value": 0.5, "unit": "lines", "origin": ["docDefaults", "直接段落格式"], "raw": {"after": "120", "line": "480", "lineRule": "auto", "beforeAutospacing": "0", "beforeLines": "50", "before": "0", "afterAutospacing": "0"}} | {"value": 0.5, "unit": "lines"} | 符合 | 否 | AI从原文提取后确认（用户确认v4模板，不冒充学校原文）：正文段前0.5行 |
| R13 | {"paragraph": 2, "property": "after"} | {"value": 6.0, "unit": "pt", "origin": ["docDefaults", "直接段落格式"], "raw": {"after": "120", "line": "480", "lineRule": "auto", "beforeAutospacing": "0", "beforeLines": "50", "before": "0", "afterAutospacing": "0"}} | {"value": 6, "unit": "pt"} | 符合 | 否 | AI从原文提取后确认（用户确认v4模板，不冒充学校原文）：正文段前0.5行，段后6pt |
| R13 | {"paragraph": 2, "property": "alignment"} | "left" | "left" | 符合 | 否 | AI从原文提取后确认（用户确认v4模板，不冒充学校原文）：正文段前0.5行，段后6pt，居左 |
| R13 | {"paragraph": 3, "property": "before"} | {"value": 0.5, "unit": "lines", "origin": ["docDefaults", "paragraph样式:Heading2", "直接段落格式"], "raw": {"after": "0", "line": "240", "lineRule": "auto", "before": "0", "beforeAutospacing": "0", "beforeLines": "50", "afterAutospacing": "0", "afterLines": "50"}} | {"value": 0.5, "unit": "lines"} | 符合 | 否 | 用户选择沿用默认值（用户确认v4模板，不冒充学校原文）： |
| R13 | {"paragraph": 3, "property": "after"} | {"value": 0.5, "unit": "lines", "origin": ["docDefaults", "paragraph样式:Heading2", "直接段落格式"], "raw": {"after": "0", "line": "240", "lineRule": "auto", "before": "0", "beforeAutospacing": "0", "beforeLines": "50", "afterAutospacing": "0", "afterLines": "50"}} | {"value": 0.5, "unit": "lines"} | 符合 | 否 | 用户选择沿用默认值（用户确认v4模板，不冒充学校原文）： |
| R13 | {"paragraph": 4, "property": "before"} | {"value": 0.5, "unit": "lines", "origin": ["docDefaults", "直接段落格式"], "raw": {"after": "120", "line": "480", "lineRule": "auto", "beforeAutospacing": "0", "beforeLines": "50", "before": "0", "afterAutospacing": "0"}} | {"value": 0.5, "unit": "lines"} | 符合 | 否 | AI从原文提取后确认（用户确认v4模板，不冒充学校原文）：正文段前0.5行 |
| R13 | {"paragraph": 4, "property": "after"} | {"value": 6.0, "unit": "pt", "origin": ["docDefaults", "直接段落格式"], "raw": {"after": "120", "line": "480", "lineRule": "auto", "beforeAutospacing": "0", "beforeLines": "50", "before": "0", "afterAutospacing": "0"}} | {"value": 6, "unit": "pt"} | 符合 | 否 | AI从原文提取后确认（用户确认v4模板，不冒充学校原文）：正文段前0.5行，段后6pt |
| R13 | {"paragraph": 4, "property": "alignment"} | "left" | "left" | 符合 | 否 | AI从原文提取后确认（用户确认v4模板，不冒充学校原文）：正文段前0.5行，段后6pt，居左 |
| R13 | {"paragraph": 5, "property": "before"} | {"value": 0.5, "unit": "lines", "origin": ["docDefaults", "paragraph样式:Heading3", "直接段落格式"], "raw": {"after": "0", "line": "240", "lineRule": "auto", "before": "0", "beforeAutospacing": "0", "beforeLines": "50", "afterAutospacing": "0", "afterLines": "50"}} | {"value": 0.5, "unit": "lines"} | 符合 | 否 | 用户选择沿用默认值（用户确认v4模板，不冒充学校原文）： |
| R13 | {"paragraph": 5, "property": "after"} | {"value": 0.5, "unit": "lines", "origin": ["docDefaults", "paragraph样式:Heading3", "直接段落格式"], "raw": {"after": "0", "line": "240", "lineRule": "auto", "before": "0", "beforeAutospacing": "0", "beforeLines": "50", "afterAutospacing": "0", "afterLines": "50"}} | {"value": 0.5, "unit": "lines"} | 符合 | 否 | 用户选择沿用默认值（用户确认v4模板，不冒充学校原文）： |
| R13 | {"paragraph": 6, "property": "before"} | {"value": 0.5, "unit": "lines", "origin": ["docDefaults", "直接段落格式"], "raw": {"after": "120", "line": "480", "lineRule": "auto", "beforeAutospacing": "0", "beforeLines": "50", "before": "0", "afterAutospacing": "0"}} | {"value": 0.5, "unit": "lines"} | 符合 | 否 | AI从原文提取后确认（用户确认v4模板，不冒充学校原文）：正文段前0.5行 |
| R13 | {"paragraph": 6, "property": "after"} | {"value": 6.0, "unit": "pt", "origin": ["docDefaults", "直接段落格式"], "raw": {"after": "120", "line": "480", "lineRule": "auto", "beforeAutospacing": "0", "beforeLines": "50", "before": "0", "afterAutospacing": "0"}} | {"value": 6, "unit": "pt"} | 符合 | 否 | AI从原文提取后确认（用户确认v4模板，不冒充学校原文）：正文段前0.5行，段后6pt |
| R13 | {"paragraph": 6, "property": "alignment"} | "left" | "left" | 符合 | 否 | AI从原文提取后确认（用户确认v4模板，不冒充学校原文）：正文段前0.5行，段后6pt，居左 |
| R14 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R15 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R16 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R17 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R18 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R19 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R20 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R21 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R38 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 新对象未配置或当前范围无对象；不推定学校要求/已通过： |
| R39 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 新对象未配置或当前范围无对象；不推定学校要求/已通过： |
| R40 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 新对象未配置或当前范围无对象；不推定学校要求/已通过： |
| R41 | {"document": 1} | null | null | 不适用：当前模板未配置或确认范围无该对象，不套正文规则 | 否 | 新对象未配置或当前范围无对象；不推定学校要求/已通过： |
| R22 | {"document": 1, "property": "存在_abstract_cn_title"} | 0 | ">=1" | 待复核：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_abstract_cn_body"} | 0 | ">=1" | 待复核：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_abstract_en_title"} | 0 | ">=1" | 待复核：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_abstract_en_body"} | 0 | ">=1" | 待复核：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_keywords_cn"} | 0 | ">=1" | 待复核：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_keywords_en"} | 0 | ">=1" | 待复核：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_reference_title"} | 0 | ">=1" | 待复核：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "存在_reference_item"} | 0 | ">=1" | 待复核：只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |
| R22 | {"document": 1, "property": "参考文献条目数"} | 0 | "确认条目≥10（主要文献/外文身份另核对）" | 问题：按人工确认条目计数；不足时核对范围或资料，不生成文献；不判断主要文献身份、语种或所有著录格式 | 否 | 2015范例只读口径（用户明确启用，不由AI提取）：00-全员必看/本科毕业设计论文.pdf 物理页16：摘要400–600字，关键词3–5个，主要参考文献10篇以上/外文2篇以上；本程序只统计确认条目，外文与主要文献身份未判断。 |

## 字体及编号只读解析证据

文档指定字体用于属性检查；本机字体安装与替代由独立预览核对。
- R03:paragraph=2:run=1：{"font": {"eastAsia": {"font": "宋体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "宋体；来源 直接run格式"}}, "numbering": null}
- R03:paragraph=4:run=1：{"font": {"eastAsia": {"font": "宋体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "宋体；来源 直接run格式"}}, "numbering": null}
- R03:paragraph=6:run=1：{"font": {"eastAsia": {"font": "宋体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "宋体；来源 直接run格式"}}, "numbering": null}
- R08:paragraph=1:run=1:property=font_ascii：{"font": {"ascii": {"font": "Times New Roman", "slot": "ascii", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "Times New Roman；来源 直接run格式"}}, "numbering": null}
- R08:paragraph=1:run=1:property=font_eastAsia：{"font": {"eastAsia": {"font": "黑体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "黑体；来源 直接run格式"}}, "numbering": null}
- R09:paragraph=3:run=1:property=font_ascii：{"font": {"ascii": {"font": "Times New Roman", "slot": "ascii", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "Times New Roman；来源 直接run格式"}}, "numbering": null}
- R09:paragraph=3:run=1:property=font_eastAsia：{"font": {"eastAsia": {"font": "宋体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "宋体；来源 直接run格式"}}, "numbering": null}
- R10:paragraph=5:run=1:property=font_ascii：{"font": {"ascii": {"font": "Times New Roman", "slot": "ascii", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "Times New Roman；来源 直接run格式"}}, "numbering": null}
- R10:paragraph=5:run=1:property=font_eastAsia：{"font": {"eastAsia": {"font": "黑体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "黑体；来源 直接run格式"}}, "numbering": null}

## 修改依赖提示

没有已预测的关联影响；不表示不存在其他未支持依赖。

## 覆盖提示

无额外提示；仍不包括未确认段落及报告所列覆盖外对象。

## 封面、页眉页脚与页码边界

