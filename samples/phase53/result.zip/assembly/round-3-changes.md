# 论文有格修改记录

输出：fixed.docx
配置：本次补充排版要求（正文及标题题注）（段落及摘要关键词参考文献） vrule-bundle-1+template-demo-8.0.0+extended-demo-1.0.0+sections-demo-1.0
模板结构版本：8
配置SHA256：c1ca1f7e27295c73d4ffa779d1e3c70761a58f47cd0b9a74d1678b1edfc020ec

| 规则 | 位置 | 修改前 | 修改后 | 落盘复查 | 依据 |
| --- | --- | --- | --- | --- | --- |
| L03 · keepNext | {"paragraph": 2} | false | true | 符合 | 产品辅助L03（用户确认）：仅所选段落分页属性；表达相邻意图，不保证实际同页。 |
| L03 · keepLines | {"paragraph": 2} | false | true | 符合 | 产品辅助L03（用户确认）：仅所选段落分页属性；表达相邻意图，不保证实际同页。 |

已设置标题与匹配内容相邻属性。未检测实际分页；只表达相邻意图，长表仍可跨页，过长标题或后续内容可能无法同页。请在所用渲染环境人工查看。
这是独立产品排版辅助，不计入R01–R12学校演示格式规则；尚未自动验证分页。

## 本次安全图表与分页辅助
{"summary": {"stage": "pagination", "input_sha256": "fac78d3fd0dd18854778836d66478616860d1a459b3b6bff064c4ddc0d03eb22", "objects": [{"key": "L03:2:3", "status": "selected", "reason": "实际XML顺序紧接，建议尚未应用；须确认所选对象"}, {"key": "L03:5:6", "status": "protected", "reason": "非普通段落，待复核"}, {"key": "L03:15:16", "status": "protected", "reason": "非普通段落，待复核"}, {"key": "L03:25:26", "status": "protected", "reason": "非普通段落，待复核"}, {"key": "L03:35:36", "status": "protected", "reason": "非普通段落，待复核"}], "selected_count": 1, "status": "verified", "seconds": 0.865, "changes": 2, "output_sha256": "2eb45c8280736dd1a66fc4d26d1762292b694e67926d1902b9fb3b7d96c90a00"}, "adoption": {"fix_calls": 0, "input_auto_switched": false}}

轮次与输入来源：{"number": 3, "input_round": 2, "input_sha256": "fac78d3fd0dd18854778836d66478616860d1a459b3b6bff064c4ddc0d03eb22", "original_sha256": "0a19d923a99a0b972001b1550a48a0f3fdabcff20169d74baf3481a7e5c4925e", "rules_version": "rule-bundle-1+template-demo-8.0.0+extended-demo-1.0.0+sections-demo-1.0", "rules_sha256": "c1ca1f7e27295c73d4ffa779d1e3c70761a58f47cd0b9a74d1678b1edfc020ec", "backmatter_sha256": "73a31b9d434d3a2cce82aba538b3e8cc7f86ea00b6791a08ba7c21f127902864"}

问题变化（已解决/原有剩余/新出现）：{"resolved_keys": [], "unresolved_review_keys": [], "not_applicable_keys": [], "remaining_keys": ["R03:paragraph=6:run=1", "R05:paragraph=6:run=1", "R11:paragraph=15", "R11:paragraph=25", "R11:paragraph=35", "R11:paragraph=5", "R22:document=1:property=中文摘要字数", "R22:document=1:property=参考文献条目数"], "new_keys": [], "new_problem_causes": []}

未强制修正的待复核项：[]

完整性验证：{"original_sha256_unchanged": true, "document_except_selected_format_attributes_equal": true, "other_zip_member_bytes_equal": true, "verified_objects": "完整主文档XML仅掩码所选段落keepNext/keepLines或所选表格行tblHeader；其他ZIP成员字节相同，含图片尺寸、媒体、字段、表格内容尺寸合并、编号和分节。"}
