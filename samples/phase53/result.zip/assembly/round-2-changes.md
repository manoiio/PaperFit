# 论文有格修改记录

输出：fixed.docx
配置：本次补充排版要求（正文及标题题注）（段落及摘要关键词参考文献） vrule-bundle-1+template-demo-8.0.0+extended-demo-1.0.0+sections-demo-1.0
模板结构版本：8
配置SHA256：c1ca1f7e27295c73d4ffa779d1e3c70761a58f47cd0b9a74d1678b1edfc020ec

| 规则 | 位置 | 修改前 | 修改后 | 落盘复查 | 依据 |
| --- | --- | --- | --- | --- | --- |
| R29 · section_pages | {"section": 1} | null | {"kind": "new_section", "start": 2} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 1} | null | {"kind": "new_section", "start": 5} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 1} | null | {"kind": "new_section", "start": 35} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 1} | null | {"kind": "footer", "section": 1, "variant": "default", "old_part": null, "new_part": "word/footerPF1.xml", "role": "cover", "format": "decimal", "restart": null, "text": "", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 2} | null | {"kind": "footer", "section": 2, "variant": "default", "old_part": null, "new_part": "word/footerPF2.xml", "role": "front", "format": "lowerRoman", "restart": 1, "text": "", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 3} | null | {"kind": "footer", "section": 3, "variant": "default", "old_part": null, "new_part": "word/footerPF3.xml", "role": "body", "format": "decimal", "restart": 1, "text": "研究方法", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 4} | null | {"kind": "footer", "section": 4, "variant": "default", "old_part": null, "new_part": "word/footerPF4.xml", "role": "body", "format": "decimal", "restart": null, "text": "研究方法", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |

## 分节页码结构事务
已生成PAGE并验证受控新增/克隆部件及分节。未计算域缓存、目录或实际页码；真实渲染/Word观察另行记录。
{"input_sha256": "358b52db76d0ba170bcea140c3f03705ecbff2e2ac10289283111ff5c48fee2e", "output_sha256": "fac78d3fd0dd18854778836d66478616860d1a459b3b6bff064c4ddc0d03eb22", "new_parts": ["word/footerPF1.xml", "word/footerPF2.xml", "word/footerPF3.xml", "word/footerPF4.xml"], "changed_parts": ["[Content_Types].xml", "word/_rels/document.xml.rels", "word/document.xml"], "main_object_order_preserved": true, "physical_pages_not_computed": true}

轮次与输入来源：{"number": 2, "input_round": 1, "input_sha256": "358b52db76d0ba170bcea140c3f03705ecbff2e2ac10289283111ff5c48fee2e", "original_sha256": "0a19d923a99a0b972001b1550a48a0f3fdabcff20169d74baf3481a7e5c4925e", "rules_version": "rule-bundle-1+template-demo-8.0.0+extended-demo-1.0.0+sections-demo-1.0", "rules_sha256": "c1ca1f7e27295c73d4ffa779d1e3c70761a58f47cd0b9a74d1678b1edfc020ec", "backmatter_sha256": "73a31b9d434d3a2cce82aba538b3e8cc7f86ea00b6791a08ba7c21f127902864"}

问题变化（已解决/原有剩余/新出现）：{"resolved_keys": [], "unresolved_review_keys": [], "not_applicable_keys": [], "remaining_keys": ["R03:paragraph=6:run=1", "R05:paragraph=6:run=1", "R11:paragraph=15", "R11:paragraph=25", "R11:paragraph=35", "R11:paragraph=5", "R22:document=1:property=中文摘要字数", "R22:document=1:property=参考文献条目数"], "new_keys": [], "new_problem_causes": []}

未强制修正的待复核项：[]

完整性验证：{"input_sha256": "358b52db76d0ba170bcea140c3f03705ecbff2e2ac10289283111ff5c48fee2e", "output_sha256": "fac78d3fd0dd18854778836d66478616860d1a459b3b6bff064c4ddc0d03eb22", "new_parts": ["word/footerPF1.xml", "word/footerPF2.xml", "word/footerPF3.xml", "word/footerPF4.xml"], "changed_parts": ["[Content_Types].xml", "word/_rels/document.xml.rels", "word/document.xml"], "main_object_order_preserved": true, "physical_pages_not_computed": true}
