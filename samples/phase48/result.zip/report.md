# 论文有格阅读报告

待检查文档.docx · 第3轮
启用规则及确认范围内的结果，不代表全文排版合格。
启用规则26；格式问题1；格式待复核27
宽度：{"risks": 0, "reviews": 0, "passes": 0}
Word：未验收

范围状态摘要：{"file_sha256": "8b8ecf63c59a30a92041c7633044cc65c9071e941dbeb3a6bfc2c3f87567c2fb", "rules_sha256": "fa699517038509e867d0724efec8255c9aa9886bcd590903b9fe01afd16027e7", "scope_sha256": "c1a0bee43439b6a1631f4c78b0e40e871ad8bc9085153e87b2565a14c938aa5e", "areas": [{"area": "paragraph", "name": "段落分类与材料保护", "unit": "顶层段落", "selected": 9, "excluded": 0, "participates": true, "scope": "已确认范围，待确认和其他不套普通段落规则"}, {"area": "table", "name": "表格用途与辅助配置", "unit": "顶层表格", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}, {"area": "front", "name": "封面对象与分节用途", "unit": "封面对象（节另计）", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}, {"area": "toc", "name": "目录范围与层级", "unit": "目录段落对象", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}, {"area": "citation", "name": "正文引文", "unit": "字符范围", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}, {"area": "note", "name": "脚注与尾注", "unit": "独立注释对象", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}, {"area": "caption", "name": "题注、章号与关联", "unit": "题注段落", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}, {"area": "reference", "name": "内部引用结构与链接文字", "unit": "内部引用位置（与书签分开）", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}], "limits": ["数量按各区域的定位单位分别统计；同一段落可被多个模块引用，不能相加为全文覆盖率。", "未发现候选不证明物理上没有对象；文本框、浮动对象、复杂容器和未知结构仍需复核。", "实际页码、实际同页与Word显示未由范围确认验证；预览与人工视觉核对另行进行。"], "coverage_note_count": 3, "citation_paragraph_properties": [], "unconfirmed_top_level_paragraphs": [], "review_record_keys": ["R03:paragraph=6:run=1", "R04:paragraph=6:run=1", "R03:paragraph=8:run=1", "R03:paragraph=10:run=1", "R04:paragraph=10:run=1", "R03:paragraph=12:run=1", "R08:paragraph=5:run=1:property=font_ascii", "R08:paragraph=5:run=1:property=font_eastAsia", "R12:paragraph=7:run=1:property=font_ascii", "R12:paragraph=7:run=1:property=font_eastAsia", "R08:paragraph=9:run=1:property=font_ascii", "R08:paragraph=9:run=1:property=font_eastAsia", "R12:paragraph=11:run=1:property=font_ascii", "R12:paragraph=11:run=1:property=font_eastAsia", "R14:paragraph=3:property=before", "R14:paragraph=3:property=alignment", "R14:paragraph=3:run=1:property=font_eastAsia", "R22:document=1:property=存在_abstract_cn_body", "R22:document=1:property=存在_abstract_en_title", "R22:document=1:property=存在_abstract_en_body", "R22:document=1:property=存在_keywords_cn", "R22:document=1:property=存在_keywords_en", "R22:document=1:property=存在_reference_title", "R22:document=1:property=存在_reference_item"], "review_counts": {"rule_records": 24, "coverage_notes": 3}, "review_explanation": "原始待复核记录全部保留；范围未确认、复杂结构及解析限制仍按原报告分别说明。"}
- 确定的格式问题 · R01:section=1 · 节 1 · 符合：210.01 × 297 mm → 210 × 297 mm；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R02:section=1 · 节 1 · 符合：上24.99 mm；下24.99 mm；左24.99 mm；右24.99 mm → 上25 mm；下25 mm；左25 mm；右25 mm；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R01:section=2 · 节 2 · 符合：210.01 × 297 mm → 210 × 297 mm；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R02:section=2 · 节 2 · 符合：上24.99 mm；下24.99 mm；左24.99 mm；右24.99 mm → 上25 mm；下25 mm；左25 mm；右25 mm；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R01:section=3 · 节 3 · 符合：210.01 × 297 mm → 210 × 297 mm；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R02:section=3 · 节 3 · 符合：上24.99 mm；下24.99 mm；左24.99 mm；右24.99 mm → 上25 mm；下25 mm；左25 mm；右25 mm；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R01:section=4 · 节 4 · 符合：210.01 × 297 mm → 210 × 297 mm；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R02:section=4 · 节 4 · 符合：上24.99 mm；下24.99 mm；左24.99 mm；右24.99 mm → 上25 mm；下25 mm；左25 mm；右25 mm；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 待复核及支持边界 · R03:paragraph=6:run=1 · 段 6 · 片段 1 · 待复核：中文：未确定：主题语言 ja-JP 未纳入当前唯一映射范围 → 宋体；eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R04:paragraph=6:run=1 · 段 6 · 片段 1 · 待复核：西文/数字：未确定：主题枚举与字体槽位不对应，需人工确认 → Times New Roman；ascii：主题枚举与字体槽位不对应，需人工确认；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R05:paragraph=6:run=1 · 段 6 · 片段 1 · 符合：12磅 → 12磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R06:paragraph=6 · 段 6 · 符合：1.5倍 → 1.5倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R07:paragraph=6 · 段 6 · 符合：首行2字符；点值0磅 → 首行2字符（汉字）；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 待复核及支持边界 · R03:paragraph=8:run=1 · 段 8 · 片段 1 · 待复核：中文：未确定：主题语言 ja-JP 未纳入当前唯一映射范围 → 宋体；eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R04:paragraph=8:run=1 · 段 8 · 片段 1 · 不适用：未确定 → Times New Roman；无该类字符
- 确定的格式问题 · R05:paragraph=8:run=1 · 段 8 · 片段 1 · 符合：12磅 → 12磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R06:paragraph=8 · 段 8 · 符合：1.5倍 → 1.5倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R07:paragraph=8 · 段 8 · 符合：首行2字符；点值0磅 → 首行2字符（汉字）；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 待复核及支持边界 · R03:paragraph=10:run=1 · 段 10 · 片段 1 · 待复核：中文：未确定：主题语言 ja-JP 未纳入当前唯一映射范围 → 宋体；eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R04:paragraph=10:run=1 · 段 10 · 片段 1 · 待复核：西文/数字：未确定：主题枚举与字体槽位不对应，需人工确认 → Times New Roman；ascii：主题枚举与字体槽位不对应，需人工确认；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R05:paragraph=10:run=1 · 段 10 · 片段 1 · 符合：12磅 → 12磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R06:paragraph=10 · 段 10 · 符合：1.5倍 → 1.5倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R07:paragraph=10 · 段 10 · 符合：首行2字符；点值0磅 → 首行2字符（汉字）；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 待复核及支持边界 · R03:paragraph=12:run=1 · 段 12 · 片段 1 · 待复核：中文：未确定：主题语言 ja-JP 未纳入当前唯一映射范围 → 宋体；eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R04:paragraph=12:run=1 · 段 12 · 片段 1 · 不适用：未确定 → Times New Roman；无该类字符
- 确定的格式问题 · R05:paragraph=12:run=1 · 段 12 · 片段 1 · 符合：12磅 → 12磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R06:paragraph=12 · 段 12 · 符合：1.5倍 → 1.5倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R07:paragraph=12 · 段 12 · 符合：首行2字符；点值0磅 → 首行2字符（汉字）；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 待复核及支持边界 · R08:paragraph=5:run=1:property=font_ascii · 段 5 · 片段 1 · 西文/数字字体 · 待复核：未确定（主题或字体槽位） → Times New Roman；ascii：主题枚举与字体槽位不对应，需人工确认；主题枚举与字体槽位不对应，需人工确认；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R08:paragraph=5:run=1:property=font_eastAsia · 段 5 · 片段 1 · 中文字体 · 待复核：未确定（主题或字体槽位） → 黑体；eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围；主题语言 ja-JP 未纳入当前唯一映射范围；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R08:paragraph=5:run=1:property=size · 段 5 · 片段 1 · 字号 · 符合：18磅 → 18磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R08:paragraph=5:property=alignment · 段 5 · 对齐 · 符合：居中 → 居中；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R08:paragraph=5:property=line · 段 5 · 行距 · 符合：1倍 → 1倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R11:paragraph=5 · 段 5 · 符合：Heading1 · 大纲 0（从0起） → Heading1 · 大纲 0（从0起）；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 待复核及支持边界 · R12:paragraph=7:run=1:property=font_ascii · 段 7 · 片段 1 · 西文/数字字体 · 待复核：未确定（主题或字体槽位） → 宋体；ascii：主题枚举与字体槽位不对应，需人工确认；主题枚举与字体槽位不对应，需人工确认；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R12:paragraph=7:run=1:property=font_eastAsia · 段 7 · 片段 1 · 中文字体 · 待复核：未确定（主题或字体槽位） → 宋体；eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围；主题语言 ja-JP 未纳入当前唯一映射范围；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R12:paragraph=7:run=1:property=size · 段 7 · 片段 1 · 字号 · 符合：10.5磅 → 10.5磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 待复核及支持边界 · R08:paragraph=9:run=1:property=font_ascii · 段 9 · 片段 1 · 西文/数字字体 · 待复核：未确定（主题或字体槽位） → Times New Roman；ascii：主题枚举与字体槽位不对应，需人工确认；主题枚举与字体槽位不对应，需人工确认；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R08:paragraph=9:run=1:property=font_eastAsia · 段 9 · 片段 1 · 中文字体 · 待复核：未确定（主题或字体槽位） → 黑体；eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围；主题语言 ja-JP 未纳入当前唯一映射范围；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R08:paragraph=9:run=1:property=size · 段 9 · 片段 1 · 字号 · 符合：18磅 → 18磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R08:paragraph=9:property=alignment · 段 9 · 对齐 · 符合：居中 → 居中；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R08:paragraph=9:property=line · 段 9 · 行距 · 符合：1倍 → 1倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R11:paragraph=9 · 段 9 · 符合：Heading1 · 大纲 0（从0起） → Heading1 · 大纲 0（从0起）；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 待复核及支持边界 · R12:paragraph=11:run=1:property=font_ascii · 段 11 · 片段 1 · 西文/数字字体 · 待复核：未确定（主题或字体槽位） → 宋体；ascii：主题枚举与字体槽位不对应，需人工确认；主题枚举与字体槽位不对应，需人工确认；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R12:paragraph=11:run=1:property=font_eastAsia · 段 11 · 片段 1 · 中文字体 · 待复核：未确定（主题或字体槽位） → 宋体；eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围；主题语言 ja-JP 未纳入当前唯一映射范围；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R12:paragraph=11:run=1:property=size · 段 11 · 片段 1 · 字号 · 符合：10.5磅 → 10.5磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R09:document=1 · 主文档 · 不适用：未确定 → 中文黑体；西文/数字Times New Roman；15磅；居左；1倍行距；本次确认分类中没有该类对象，不凭空报错
- 确定的格式问题 · R10:document=1 · 主文档 · 不适用：未确定 → 中文黑体；西文/数字Times New Roman；14磅；居左；1倍行距；本次确认分类中没有该类对象，不凭空报错
- 待复核及支持边界 · R14:paragraph=3:property=before · 段 3 · 段前 · 待复核：未确定：有效继承路径也未设置before间距；未按0处理 → 0.5行；有效继承路径也未设置before间距；未按0处理；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R14:paragraph=3:property=after · 段 3 · 段后 · 符合：0.5行 → 0.5行；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 待复核及支持边界 · R14:paragraph=3:property=alignment · 段 3 · 对齐 · 待复核：未确定：对齐未设置/未支持或无法可靠继承 → 居中；对齐未设置/未支持或无法可靠继承；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R14:paragraph=3:property=line_spacing · 段 3 · 行距 · 符合：1倍 → 1倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 待复核及支持边界 · R14:paragraph=3:run=1:property=font_eastAsia · 段 3 · 片段 1 · 中文字体 · 待复核：未确定：主题语言 ja-JP 未纳入当前唯一映射范围 → 黑体；eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围；主题语言 ja-JP 未纳入当前唯一映射范围；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R14:paragraph=3:run=1:property=size · 段 3 · 片段 1 · 字号 · 符合：18磅 → 18磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R13:paragraph=5:property=before · 段 5 · 段前 · 符合：0.5行 → 0.5行；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R13:paragraph=5:property=after · 段 5 · 段后 · 符合：0.5行 → 0.5行；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R13:paragraph=9:property=before · 段 9 · 段前 · 符合：0.5行 → 0.5行；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R13:paragraph=9:property=after · 段 9 · 段后 · 符合：0.5行 → 0.5行；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R15:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R16:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R17:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R18:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R19:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R20:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R21:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R38:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R39:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R40:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R41:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R22:document=1:property=存在_abstract_cn_title · 主文档 · 符合：1 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容
- 待复核及支持边界 · R22:document=1:property=存在_abstract_cn_body · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R22:document=1:property=存在_abstract_en_title · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R22:document=1:property=存在_abstract_en_body · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R22:document=1:property=存在_keywords_cn · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R22:document=1:property=存在_keywords_en · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R22:document=1:property=存在_reference_title · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R22:document=1:property=存在_reference_item · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R22:document=1:property=参考文献条目数 · 主文档 · 发现问题：0 → 确认条目≥10（主要文献/外文身份另核对）；按人工确认条目计数；不足时核对范围或资料，不生成文献；不判断主要文献身份、语种或所有著录格式；本项为只读内容提示或存在修改依赖；请人工核对，不自动改写内容。
- 待复核及支持边界 · coverage:0 · 段 8 · 片段 1 · 待复核：该对象未完整检查 → 人工核对；含未支持字体槽位的字符（如希腊文、符号、emoji）；其字体未验证
- 待复核及支持边界 · coverage:1 · 段 10 · 片段 1 · 待复核：该对象未完整检查 → 人工核对；含未支持字体槽位的字符（如希腊文、符号、emoji）；其字体未验证
- 待复核及支持边界 · coverage:2 · 段 12 · 片段 1 · 待复核：该对象未完整检查 → 人工核对；含未支持字体槽位的字符（如希腊文、符号、emoji）；其字体未验证
- 待复核及支持边界 · L03:3:4 · 段 3 · 待复核：见对象位置与关联关系（原文已省略） → 只表达相邻意图，不保证实际同页；现有段前分页，待复核；不会删除原属性
- 待复核及支持边界 · L03:5:6 · 段 5 · 待复核：见对象位置与关联关系（原文已省略） → 只表达相邻意图，不保证实际同页；现有段前分页，待复核；不会删除原属性
- 待复核及支持边界 · L03:9:10 · 段 9 · 待复核：见对象位置与关联关系（原文已省略） → 只表达相邻意图，不保证实际同页；现有段前分页，待复核；不会删除原属性
- 待复核及支持边界 · boundary:0 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；外文参考文献2篇以上及主要文献身份、指导教师例外未自动判断（学校PDF物理页16）；需人工核对。
- 待复核及支持边界 · boundary:1 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；中英文摘要/关键词的语义一致性、关键词层次及著录真实性未检查；不生成或改写内容。
- 待复核及支持边界 · boundary:2 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；附录和致谢按需存在，没有时不判缺项。
- 待复核及支持边界 · boundary:3 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；附录普通文字须明确确认适用文献正文解释；代码、数据、运行输出、图表及其他材料不能整章套用。
- 待复核及支持边界 · boundary:4 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；致谢范例物理页38仅显示标题与省略号，未提供可可靠执行的字体字号行距要求；致谢默认属性均未启用。
- 待复核及支持边界 · boundary:5 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；内容、代码正确性、致谢是否适当、目录实际页码及所有排版行为未验证。
- 待复核及支持边界 · boundary:6 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；规则结论只针对已确认范围；未确认段落不自动套正文/标题/题注格式。
- 待复核及支持边界 · boundary:7 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；表格内部文字、页眉页脚及注释仅在明确启用且确认的范围内检查；文本框及实际分页仍需另行复核。宽度只覆盖受支持的顶层对象。
- 待复核及支持边界 · boundary:8 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；预览不是Microsoft Word最终排版，视觉结论必须由人工查看记录。

分节页码：结构读回通过，物理页码/Word观察单独核对，目录未刷新。
{"validation": {"input_sha256": "49da3862c4590399d1825aa7b8ea9d72a394c6b6e365fd13ab31025efcdb2e7e", "output_sha256": "8b8ecf63c59a30a92041c7633044cc65c9071e941dbeb3a6bfc2c3f87567c2fb", "new_parts": ["word/footerPF1.xml", "word/footerPF10.xml", "word/footerPF11.xml", "word/footerPF12.xml", "word/footerPF2.xml", "word/footerPF3.xml", "word/footerPF4.xml", "word/footerPF5.xml", "word/footerPF6.xml", "word/footerPF7.xml", "word/footerPF8.xml", "word/footerPF9.xml"], "changed_parts": ["[Content_Types].xml", "word/_rels/document.xml.rels", "word/document.xml"], "main_object_order_preserved": true, "physical_pages_not_computed": true}, "generated_PAGE": true, "physical_pages": "需实际渲染/Word核对", "directory_fields": "未刷新", "regions": [{"start": 1, "role": "cover", "format": "decimal", "restart": null, "footer": "page", "alignment": "center"}, {"start": 3, "role": "front", "format": "lowerRoman", "restart": 1, "footer": "page", "alignment": "center"}, {"start": 5, "role": "body", "format": "decimal", "restart": 1, "footer": "chapter", "alignment": "center"}, {"start": 9, "role": "body", "format": "decimal", "restart": null, "footer": "chapter", "alignment": "center"}]}

完整整理各阶段：{"policy": {"version": 1, "dynamic": true, "pages": "front-body", "roman": "lowerRoman", "body_start": 1, "front_start": 1, "chapter_restart": false, "footer": "chapter", "text": "", "alignment": "center"}, "steps": [{"kind": "format", "round": 1, "input_sha256": "a9a2ceded1f268a4f63133746334952554e0e1d471a5a5239921fedbab131ffe", "output_sha256": "eeaaf07117dff5eda4e8da9a5c44953228a58cbbeb609324246e411b61b8a9c6", "changes": 35}, {"kind": "dynamic_text", "round": 2, "input_sha256": "eeaaf07117dff5eda4e8da9a5c44953228a58cbbeb609324246e411b61b8a9c6", "output_sha256": "49da3862c4590399d1825aa7b8ea9d72a394c6b6e365fd13ab31025efcdb2e7e", "changes": 4}, {"kind": "section_pages", "round": 3, "input_sha256": "49da3862c4590399d1825aa7b8ea9d72a394c6b6e365fd13ab31025efcdb2e7e", "output_sha256": "8b8ecf63c59a30a92041c7633044cc65c9071e941dbeb3a6bfc2c3f87567c2fb", "changes": 12}], "total_changes": 51, "input_auto_switched": false, "fields_evaluated": false}

本轮修改：[{"rule_id": "R29", "key": "pages:1", "locator": {"section": 1}, "property": "section_pages", "before": "word/footer1.xml", "after": {"kind": "footer", "section": 1, "variant": "default", "old_part": "word/footer1.xml", "new_part": "word/footerPF1.xml", "role": "cover", "format": "decimal", "restart": null, "text": "", "alignment": "center"}, "verification": "pass", "source": {"label": "用户明确选择的页码/章节页脚方案", "quote": "可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。"}}, {"rule_id": "R29", "key": "pages:2", "locator": {"section": 1}, "property": "section_pages", "before": "word/footer2.xml", "after": {"kind": "footer", "section": 1, "variant": "first", "old_part": "word/footer2.xml", "new_part": "word/footerPF2.xml", "role": "cover", "format": "decimal", "restart": null, "text": "", "alignment": "center"}, "verification": "pass", "source": {"label": "用户明确选择的页码/章节页脚方案", "quote": "可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。"}}, {"rule_id": "R29", "key": "pages:3", "locator": {"section": 1}, "property": "section_pages", "before": "word/footer3.xml", "after": {"kind": "footer", "section": 1, "variant": "even", "old_part": "word/footer3.xml", "new_part": "word/footerPF3.xml", "role": "cover", "format": "decimal", "restart": null, "text": "", "alignment": "center"}, "verification": "pass", "source": {"label": "用户明确选择的页码/章节页脚方案", "quote": "可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。"}}, {"rule_id": "R29", "key": "pages:4", "locator": {"section": 2}, "property": "section_pages", "before": "word/footer1.xml", "after": {"kind": "footer", "section": 2, "variant": "default", "old_part": "word/footer1.xml", "new_part": "word/footerPF4.xml", "role": "front", "format": "lowerRoman", "restart": 1, "text": "", "alignment": "center"}, "verification": "pass", "source": {"label": "用户明确选择的页码/章节页脚方案", "quote": "可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。"}}, {"rule_id": "R29", "key": "pages:5", "locator": {"section": 2}, "property": "section_pages", "before": "word/footer2.xml", "after": {"kind": "footer", "section": 2, "variant": "first", "old_part": "word/footer2.xml", "new_part": "word/footerPF5.xml", "role": "front", "format": "lowerRoman", "restart": 1, "text": "", "alignment": "center"}, "verification": "pass", "source": {"label": "用户明确选择的页码/章节页脚方案", "quote": "可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。"}}, {"rule_id": "R29", "key": "pages:6", "locator": {"section": 2}, "property": "section_pages", "before": "word/footer3.xml", "after": {"kind": "footer", "section": 2, "variant": "even", "old_part": "word/footer3.xml", "new_part": "word/footerPF6.xml", "role": "front", "format": "lowerRoman", "restart": 1, "text": "", "alignment": "center"}, "verification": "pass", "source": {"label": "用户明确选择的页码/章节页脚方案", "quote": "可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。"}}, {"rule_id": "R29", "key": "pages:7", "locator": {"section": 3}, "property": "section_pages", "before": "word/footer1.xml", "after": {"kind": "footer", "section": 3, "variant": "default", "old_part": "word/footer1.xml", "new_part": "word/footerPF7.xml", "role": "body", "format": "decimal", "restart": 1, "text": "第1章 合成研究", "alignment": "center"}, "verification": "pass", "source": {"label": "用户明确选择的页码/章节页脚方案", "quote": "可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。"}}, {"rule_id": "R29", "key": "pages:8", "locator": {"section": 3}, "property": "section_pages", "before": "word/footer2.xml", "after": {"kind": "footer", "section": 3, "variant": "first", "old_part": "word/footer2.xml", "new_part": "word/footerPF8.xml", "role": "body", "format": "decimal", "restart": 1, "text": "第1章 合成研究", "alignment": "center"}, "verification": "pass", "source": {"label": "用户明确选择的页码/章节页脚方案", "quote": "可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。"}}, {"rule_id": "R29", "key": "pages:9", "locator": {"section": 3}, "property": "section_pages", "before": "word/footer3.xml", "after": {"kind": "footer", "section": 3, "variant": "even", "old_part": "word/footer3.xml", "new_part": "word/footerPF9.xml", "role": "body", "format": "decimal", "restart": 1, "text": "第1章 合成研究", "alignment": "center"}, "verification": "pass", "source": {"label": "用户明确选择的页码/章节页脚方案", "quote": "可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。"}}, {"rule_id": "R29", "key": "pages:10", "locator": {"section": 4}, "property": "section_pages", "before": "word/footer1.xml", "after": {"kind": "footer", "section": 4, "variant": "default", "old_part": "word/footer1.xml", "new_part": "word/footerPF10.xml", "role": "body", "format": "decimal", "restart": null, "text": "第2章 合成结果", "alignment": "center"}, "verification": "pass", "source": {"label": "用户明确选择的页码/章节页脚方案", "quote": "可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。"}}, {"rule_id": "R29", "key": "pages:11", "locator": {"section": 4}, "property": "section_pages", "before": "word/footer2.xml", "after": {"kind": "footer", "section": 4, "variant": "first", "old_part": "word/footer2.xml", "new_part": "word/footerPF11.xml", "role": "body", "format": "decimal", "restart": null, "text": "第2章 合成结果", "alignment": "center"}, "verification": "pass", "source": {"label": "用户明确选择的页码/章节页脚方案", "quote": "可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。"}}, {"rule_id": "R29", "key": "pages:12", "locator": {"section": 4}, "property": "section_pages", "before": "word/footer3.xml", "after": {"kind": "footer", "section": 4, "variant": "even", "old_part": "word/footer3.xml", "new_part": "word/footerPF12.xml", "role": "body", "format": "decimal", "restart": null, "text": "第2章 合成结果", "alignment": "center"}, "verification": "pass", "source": {"label": "用户明确选择的页码/章节页脚方案", "quote": "可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。"}}]
预览/视觉：{"preview": {"status": "未生成预览"}, "visual": {"status": "未记录人工视觉复核"}}
