# 论文有格修改记录

输出：fixed.docx
配置：用户确认的组合演示要求（正文及标题题注）（段落及摘要关键词参考文献） vrule-bundle-1+template-demo-6.0.0+extended-demo-1.0.0+sections-demo-1.0
模板结构版本：6
配置SHA256：fa699517038509e867d0724efec8255c9aa9886bcd590903b9fe01afd16027e7

| 规则 | 位置 | 修改前 | 修改后 | 落盘复查 | 依据 |
| --- | --- | --- | --- | --- | --- |
| R42 · caption_number | {"paragraph": 7, "start": 3, "end": 4} | "2" | "1" | 符合 | 用户授权的产品动态处理：按已确认章节及完整题注范围连续编号；唯一纯文本引用同步，不是新增学校格式规定。 |
| R42 · plain_caption_reference | {"paragraph": 6, "start": 5, "end": 6} | "2" | "1" | 符合 | 用户授权的产品动态处理：按已确认章节及完整题注范围连续编号；唯一纯文本引用同步，不是新增学校格式规定。 |
| R42 · caption_number | {"paragraph": 11, "start": 3, "end": 4} | "3" | "1" | 符合 | 用户授权的产品动态处理：按已确认章节及完整题注范围连续编号；唯一纯文本引用同步，不是新增学校格式规定。 |
| R42 · plain_caption_reference | {"paragraph": 6, "start": 10, "end": 11} | "3" | "1" | 符合 | 用户授权的产品动态处理：按已确认章节及完整题注范围连续编号；唯一纯文本引用同步，不是新增学校格式规定。 |

## 用户授权动态数字事务（不是普通格式修正）
仅按清单修改题注及唯一纯文本引用数字；所有run格式与未选部件保持。REF/PAGEREF、目录页码及实际分页未更新，须在Word更新并复核。

轮次与输入来源：{"number": 2, "input_round": 1, "input_sha256": "eeaaf07117dff5eda4e8da9a5c44953228a58cbbeb609324246e411b61b8a9c6", "original_sha256": "a9a2ceded1f268a4f63133746334952554e0e1d471a5a5239921fedbab131ffe", "rules_version": "rule-bundle-1+template-demo-6.0.0+extended-demo-1.0.0+sections-demo-1.0", "rules_sha256": "fa699517038509e867d0724efec8255c9aa9886bcd590903b9fe01afd16027e7", "backmatter_sha256": "73a31b9d434d3a2cce82aba538b3e8cc7f86ea00b6791a08ba7c21f127902864"}

问题变化（已解决/原有剩余/新出现）：{"resolved_keys": [], "unresolved_review_keys": [], "not_applicable_keys": [], "remaining_keys": ["R22:document=1:property=参考文献条目数"], "new_keys": [], "new_problem_causes": []}

未强制修正的待复核项：[]

完整性验证：{"original_sha256_unchanged": true, "unselected_zip_member_bytes_equal": true}
