# 论文有格检查报告

规则：华工本科工理类2015演示规则 v1.0.0
规则配置SHA256：1ef3ec0d674ddc3a1e5e5c84510dd7851f9011edf98c7efe92a46161d078ca10
输入：fixed.docx
SHA256：82d0c27e5b3ceb2f5c2fa90d756c19e3f6578dc2b9535b28de0b82e33c02597a

启用规则 7 条；实际适用 7 条；问题 0 个；待复核 0 个（规则记录 0，覆盖提示 0）。
结论：已覆盖检查未发现问题。仅针对已覆盖范围，不表示全文合格。

格式属性结果不包含实际分页和所有可见排版验收；页面预览及Word查看需另行人工复核。

## 覆盖范围

{"body_paragraphs": [4, 5, 6, 11, 14, 15], "total_top_level_paragraphs": 15, "unconfirmed_paragraphs": [1, 2, 3, 7, 8, 9, 10, 12, 13], "ordinary_runs_checked": 8, "special_runs_skipped": 0, "section_count": 2, "excluded": "标题/题注/未确认段落、表格格式、页眉页脚、脚注/文本框等不适用正文规则；不验证全文合格。"}

## 逐项检查

| 规则 | 位置 | 实际值 | 要求值 | 状态 | 可修正 | 依据 |
| --- | --- | --- | --- | --- | --- | --- |
| R01 | {"section": 1} | {"w_mm": 210.009, "h_mm": 297.004} | {"width_mm": 210, "height_mm": 297} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页20：编排并打印在标准A4纸上 |
| R02 | {"section": 1} | {"top_mm": 24.994, "bottom_mm": 24.994, "left_mm": 24.994, "right_mm": 24.994} | {"top_mm": 25, "bottom_mm": 25, "left_mm": 25, "right_mm": 25} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页20：所有页面的上下左右页面边距为25mm |
| R01 | {"section": 2} | {"w_mm": 210.009, "h_mm": 297.004} | {"width_mm": 210, "height_mm": 297} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页20：编排并打印在标准A4纸上 |
| R02 | {"section": 2} | {"top_mm": 24.994, "bottom_mm": 24.994, "left_mm": 24.994, "right_mm": 24.994} | {"top_mm": 25, "bottom_mm": 25, "left_mm": 25, "right_mm": 25} | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页20：所有页面的上下左右页面边距为25mm |
| R03 | {"paragraph": 4, "run": 1} | {"eastAsia": "宋体"} | "宋体" | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R04 | {"paragraph": 4, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman |
| R05 | {"paragraph": 4, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号 |
| R03 | {"paragraph": 4, "run": 2} | {"eastAsia": "宋体"} | "宋体" | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R04 | {"paragraph": 4, "run": 2} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman |
| R05 | {"paragraph": 4, "run": 2} | {"pt": 12.0} | 12 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号 |
| R06 | {"paragraph": 4} | {"line_rule": "auto", "multiple": 1.5, "pt": null} | 1.5 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R07 | {"paragraph": 4} | {"first_line_chars": 2.0, "first_line_pt": null, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：段首行缩进2个汉字 |
| R03 | {"paragraph": 5, "run": 1} | {"eastAsia": "宋体"} | "宋体" | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R04 | {"paragraph": 5, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman |
| R05 | {"paragraph": 5, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号 |
| R06 | {"paragraph": 5} | {"line_rule": "auto", "multiple": 1.5, "pt": null} | 1.5 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R07 | {"paragraph": 5} | {"first_line_chars": 2.0, "first_line_pt": null, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：段首行缩进2个汉字 |
| R03 | {"paragraph": 6, "run": 1} | {"eastAsia": "宋体"} | "宋体" | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R04 | {"paragraph": 6, "run": 1} | {"ascii": "Times New Roman"} | "Times New Roman" | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman |
| R05 | {"paragraph": 6, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号 |
| R06 | {"paragraph": 6} | {"line_rule": "auto", "multiple": 1.5, "pt": null} | 1.5 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R07 | {"paragraph": 6} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：段首行缩进2个汉字 |
| R03 | {"paragraph": 11, "run": 1} | {"eastAsia": "宋体"} | "宋体" | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R04 | {"paragraph": 11, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman |
| R05 | {"paragraph": 11, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号 |
| R06 | {"paragraph": 11} | {"line_rule": "auto", "multiple": 1.5, "pt": null} | 1.5 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R07 | {"paragraph": 11} | {"first_line_chars": 2.0, "first_line_pt": 0.0, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：段首行缩进2个汉字 |
| R03 | {"paragraph": 14, "run": 1} | {"eastAsia": "宋体"} | "宋体" | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R04 | {"paragraph": 14, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman |
| R05 | {"paragraph": 14, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号 |
| R03 | {"paragraph": 14, "run": 2} | null | "宋体" | 不适用：无该类字符 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R04 | {"paragraph": 14, "run": 2} | {"ascii": "Times New Roman"} | "Times New Roman" | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman |
| R05 | {"paragraph": 14, "run": 2} | {"pt": 12.0} | 12 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号 |
| R06 | {"paragraph": 14} | {"line_rule": "auto", "multiple": 1.5, "pt": null} | 1.5 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R07 | {"paragraph": 14} | {"first_line_chars": 2.0, "first_line_pt": null, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：段首行缩进2个汉字 |
| R03 | {"paragraph": 15, "run": 1} | {"eastAsia": "宋体"} | "宋体" | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R04 | {"paragraph": 15, "run": 1} | null | "Times New Roman" | 不适用：无该类字符 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：英文单词：字号、行距与正文相同，字体为Times New Roman |
| R05 | {"paragraph": 15, "run": 1} | {"pt": 12.0} | 12 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号 |
| R06 | {"paragraph": 15} | {"line_rule": "auto", "multiple": 1.5, "pt": null} | 1.5 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：正文：小四号，宋体，1.5倍行距 |
| R07 | {"paragraph": 15} | {"first_line_chars": 2.0, "first_line_pt": null, "hanging": null, "hanging_chars": null, "uniform_size_pt": 12.0} | 2 | 符合 | 否 | 00-全员必看/本科毕业设计论文.pdf 物理页18：段首行缩进2个汉字 |

## 字体及编号只读解析证据

文档指定字体用于属性检查；本机字体安装与替代由独立预览核对。
- R03:paragraph=4:run=1：{"font": {"eastAsia": {"font": "宋体", "slot": "eastAsia", "source_type": "paragraph样式:Normal", "declared_at": "paragraph样式:Normal", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "宋体；来源 paragraph样式:Normal"}}, "numbering": null}
- R03:paragraph=4:run=2：{"font": {"eastAsia": {"font": "宋体", "slot": "eastAsia", "source_type": "paragraph样式:Normal", "declared_at": "paragraph样式:Normal", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "宋体；来源 paragraph样式:Normal"}}, "numbering": null}
- R03:paragraph=5:run=1：{"font": {"eastAsia": {"font": "宋体", "slot": "eastAsia", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "宋体；来源 直接run格式"}}, "numbering": null}
- R03:paragraph=6:run=1：{"font": {"eastAsia": {"font": "宋体", "slot": "eastAsia", "source_type": "paragraph样式:Normal", "declared_at": "paragraph样式:Normal", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "宋体；来源 paragraph样式:Normal"}}, "numbering": null}
- R04:paragraph=6:run=1：{"font": {"ascii": {"font": "Times New Roman", "slot": "ascii", "source_type": "paragraph样式:Normal", "declared_at": "paragraph样式:Normal", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "Times New Roman；来源 paragraph样式:Normal"}}, "numbering": null}
- R03:paragraph=11:run=1：{"font": {"eastAsia": {"font": "宋体", "slot": "eastAsia", "source_type": "paragraph样式:DemoPointBody", "declared_at": "paragraph样式:DemoPointBody", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "宋体；来源 paragraph样式:DemoPointBody"}}, "numbering": null}
- R03:paragraph=14:run=1：{"font": {"eastAsia": {"font": "宋体", "slot": "eastAsia", "source_type": "paragraph样式:Normal", "declared_at": "paragraph样式:Normal", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "宋体；来源 paragraph样式:Normal"}}, "numbering": null}
- R04:paragraph=14:run=2：{"font": {"ascii": {"font": "Times New Roman", "slot": "ascii", "source_type": "直接run格式", "declared_at": "直接run格式", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "Times New Roman；来源 直接run格式"}}, "numbering": null}
- R03:paragraph=15:run=1：{"font": {"eastAsia": {"font": "宋体", "slot": "eastAsia", "source_type": "paragraph样式:Normal", "declared_at": "paragraph样式:Normal", "hint": "default", "run_language": {"val": "en-US", "eastAsia": "en-US", "bidi": "ar-SA"}, "computer_font_installation_checked": false, "safe_to_fix_slot": true, "explanation": "宋体；来源 paragraph样式:Normal"}}, "numbering": null}

## 修改依赖提示

没有已预测的关联影响；不表示不存在其他未支持依赖。

## 覆盖提示

无额外提示；仍不包括未确认段落及报告所列覆盖外对象。

## 封面、页眉页脚与页码边界

