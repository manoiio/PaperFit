# 论文有格修改记录

输出：fixed.docx
配置：华工本科工理类2015演示规则（正文及标题题注）（段落及摘要关键词参考文献） v1.0.0+extended-demo-1.0.0+sections-demo-1.0
配置SHA256：110fbcbd4583fcb72746fac5a717122909ce4733d0247b7e88b925594be20934

| 规则 | 位置 | 修改前 | 修改后 | 落盘复查 | 依据 |
| --- | --- | --- | --- | --- | --- |
| R42 · caption_number | {"paragraph": 5, "start": 3, "end": 4} | "2" | "1" | 符合 | 用户授权的产品动态处理：按已确认章节及完整题注范围连续编号；唯一纯文本引用同步，不是新增学校格式规定。 |
| R42 · plain_caption_reference | {"paragraph": 4, "start": 5, "end": 6} | "2" | "1" | 符合 | 用户授权的产品动态处理：按已确认章节及完整题注范围连续编号；唯一纯文本引用同步，不是新增学校格式规定。 |
| R42 · plain_caption_reference | {"paragraph": 4, "start": 27, "end": 28} | "2" | "1" | 符合 | 用户授权的产品动态处理：按已确认章节及完整题注范围连续编号；唯一纯文本引用同步，不是新增学校格式规定。 |
| R42 · caption_number | {"paragraph": 13, "start": 3, "end": 4} | "3" | "1" | 符合 | 用户授权的产品动态处理：按已确认章节及完整题注范围连续编号；唯一纯文本引用同步，不是新增学校格式规定。 |
| R42 · plain_caption_reference | {"paragraph": 4, "start": 10, "end": 11} | "3" | "1" | 符合 | 用户授权的产品动态处理：按已确认章节及完整题注范围连续编号；唯一纯文本引用同步，不是新增学校格式规定。 |

## 用户授权动态数字事务（不是普通格式修正）
仅按清单修改题注及唯一纯文本引用数字；所有run格式与未选部件保持。REF/PAGEREF、目录页码及实际分页未更新，须在Word更新并复核。

轮次与输入来源：{"number": 1, "input_round": 0, "input_sha256": "702bc5a182205a1ee5d1dccf23d565ea4ea7be785d823b241777f349fba85a79", "original_sha256": "702bc5a182205a1ee5d1dccf23d565ea4ea7be785d823b241777f349fba85a79", "rules_version": "1.0.0+extended-demo-1.0.0+sections-demo-1.0", "rules_sha256": "110fbcbd4583fcb72746fac5a717122909ce4733d0247b7e88b925594be20934"}

问题变化（已解决/原有剩余/新出现）：{"resolved_keys": [], "unresolved_review_keys": [], "not_applicable_keys": [], "remaining_keys": ["R22:document=1:property=参考文献条目数"], "new_keys": [], "new_problem_causes": []}

未强制修正的待复核项：[]

完整性验证：{"original_sha256_unchanged": true, "unselected_zip_member_bytes_equal": true}
