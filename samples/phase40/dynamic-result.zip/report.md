# 论文有格阅读报告

待检查文档.docx · 第1轮
启用规则及确认范围内的结果，不代表全文排版合格。
启用规则22；格式问题1；格式待复核11
宽度：{"risks": 0, "reviews": 0, "passes": 4}
Word：未验收

范围状态摘要：{"file_sha256": "ce5588f3831691d544f5f71dde11af333c96d774893369c34c8d4bdc4131c3f1", "rules_sha256": "110fbcbd4583fcb72746fac5a717122909ce4733d0247b7e88b925594be20934", "scope_sha256": "5620d658e1fd4906bcc37ea683b928df478b688a5be9cff83d1dcdef94c33abc", "areas": [{"area": "paragraph", "name": "段落分类与材料保护", "unit": "顶层段落", "selected": 12, "excluded": 0, "participates": true, "scope": "已确认范围，待确认和其他不套普通段落规则"}, {"area": "table", "name": "表格用途与辅助配置", "unit": "顶层表格", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}, {"area": "front", "name": "封面对象与分节用途", "unit": "封面对象（节另计）", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}, {"area": "toc", "name": "目录范围与层级", "unit": "目录段落对象", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}, {"area": "citation", "name": "正文引文", "unit": "字符范围", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}, {"area": "note", "name": "脚注与尾注", "unit": "独立注释对象", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}, {"area": "caption", "name": "题注、章号与关联", "unit": "题注段落", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}, {"area": "reference", "name": "内部引用结构与链接文字", "unit": "内部引用位置（与书签分开）", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}], "limits": ["数量按各区域的定位单位分别统计；同一段落可被多个模块引用，不能相加为全文覆盖率。", "未发现候选不证明物理上没有对象；文本框、浮动对象、复杂容器和未知结构仍需复核。", "实际页码、实际同页与Word显示未由范围确认验证；预览与人工视觉核对另行进行。"], "coverage_note_count": 1, "citation_paragraph_properties": [], "unconfirmed_top_level_paragraphs": [2], "review_record_keys": ["R13:paragraph=3:property=before", "R13:paragraph=10:property=before", "R22:document=1:property=存在_abstract_cn_title", "R22:document=1:property=存在_abstract_cn_body", "R22:document=1:property=存在_abstract_en_title", "R22:document=1:property=存在_abstract_en_body", "R22:document=1:property=存在_keywords_cn", "R22:document=1:property=存在_keywords_en", "R22:document=1:property=存在_reference_title", "R22:document=1:property=存在_reference_item"], "review_counts": {"rule_records": 10, "coverage_notes": 1}, "review_explanation": "原始待复核记录全部保留；范围未确认、复杂结构及解析限制仍按原报告分别说明。"}
- 确定的格式问题 · R01:section=1 · 节 1 · 符合：210.01 × 297 mm → 210 × 297 mm；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R02:section=1 · 节 1 · 符合：上24.99 mm；下24.99 mm；左24.99 mm；右24.99 mm → 上25 mm；下25 mm；左25 mm；右25 mm；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R03:paragraph=4:run=1 · 段 4 · 片段 1 · 符合：中文：宋体 → 宋体；eastAsia文档指定 宋体；paragraph样式:Normal
- 确定的格式问题 · R04:paragraph=4:run=1 · 段 4 · 片段 1 · 符合：西文/数字：Times New Roman → Times New Roman；ascii文档指定 Times New Roman；paragraph样式:Normal
- 确定的格式问题 · R05:paragraph=4:run=1 · 段 4 · 片段 1 · 符合：12磅 → 12磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R03:paragraph=4:run=2 · 段 4 · 片段 2 · 符合：中文：宋体 → 宋体；eastAsia文档指定 宋体；paragraph样式:Normal
- 确定的格式问题 · R04:paragraph=4:run=2 · 段 4 · 片段 2 · 符合：西文/数字：Times New Roman → Times New Roman；ascii文档指定 Times New Roman；paragraph样式:Normal
- 确定的格式问题 · R05:paragraph=4:run=2 · 段 4 · 片段 2 · 符合：12磅 → 12磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R03:paragraph=4:run=3 · 段 4 · 片段 3 · 符合：中文：宋体 → 宋体；eastAsia文档指定 宋体；paragraph样式:Normal
- 确定的格式问题 · R04:paragraph=4:run=3 · 段 4 · 片段 3 · 符合：西文/数字：Times New Roman → Times New Roman；ascii文档指定 Times New Roman；paragraph样式:Normal
- 确定的格式问题 · R05:paragraph=4:run=3 · 段 4 · 片段 3 · 符合：12磅 → 12磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R06:paragraph=4 · 段 4 · 符合：1.5倍 → 1.5倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R07:paragraph=4 · 段 4 · 符合：点值24磅 → 首行2字符（汉字）；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R03:paragraph=7:run=1 · 段 7 · 片段 1 · 符合：中文：宋体 → 宋体；eastAsia文档指定 宋体；直接run格式
- 确定的格式问题 · R04:paragraph=7:run=1 · 段 7 · 片段 1 · 不适用：未确定 → Times New Roman；无该类字符
- 确定的格式问题 · R05:paragraph=7:run=1 · 段 7 · 片段 1 · 符合：12磅 → 12磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R06:paragraph=7 · 段 7 · 符合：1.5倍 → 1.5倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R07:paragraph=7 · 段 7 · 符合：点值24磅 → 首行2字符（汉字）；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R03:paragraph=9:run=1 · 段 9 · 片段 1 · 符合：中文：宋体 → 宋体；eastAsia文档指定 宋体；直接run格式
- 确定的格式问题 · R04:paragraph=9:run=1 · 段 9 · 片段 1 · 不适用：未确定 → Times New Roman；无该类字符
- 确定的格式问题 · R05:paragraph=9:run=1 · 段 9 · 片段 1 · 符合：12磅 → 12磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R06:paragraph=9 · 段 9 · 符合：1.5倍 → 1.5倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R07:paragraph=9 · 段 9 · 符合：点值24磅 → 首行2字符（汉字）；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R03:paragraph=11:run=1 · 段 11 · 片段 1 · 符合：中文：宋体 → 宋体；eastAsia文档指定 宋体；直接run格式
- 确定的格式问题 · R04:paragraph=11:run=1 · 段 11 · 片段 1 · 不适用：未确定 → Times New Roman；无该类字符
- 确定的格式问题 · R05:paragraph=11:run=1 · 段 11 · 片段 1 · 符合：12磅 → 12磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R06:paragraph=11 · 段 11 · 符合：1.5倍 → 1.5倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R07:paragraph=11 · 段 11 · 符合：点值24磅 → 首行2字符（汉字）；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R03:paragraph=14:run=1 · 段 14 · 片段 1 · 符合：中文：宋体 → 宋体；eastAsia文档指定 宋体；直接run格式
- 确定的格式问题 · R04:paragraph=14:run=1 · 段 14 · 片段 1 · 不适用：未确定 → Times New Roman；无该类字符
- 确定的格式问题 · R05:paragraph=14:run=1 · 段 14 · 片段 1 · 符合：12磅 → 12磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R06:paragraph=14 · 段 14 · 符合：1.5倍 → 1.5倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R07:paragraph=14 · 段 14 · 符合：点值24磅 → 首行2字符（汉字）；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R03:paragraph=16:run=1 · 段 16 · 片段 1 · 符合：中文：宋体 → 宋体；eastAsia文档指定 宋体；直接run格式
- 确定的格式问题 · R04:paragraph=16:run=1 · 段 16 · 片段 1 · 不适用：未确定 → Times New Roman；无该类字符
- 确定的格式问题 · R05:paragraph=16:run=1 · 段 16 · 片段 1 · 符合：12磅 → 12磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R06:paragraph=16 · 段 16 · 符合：1.5倍 → 1.5倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R07:paragraph=16 · 段 16 · 符合：点值24磅 → 首行2字符（汉字）；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R08:paragraph=3:run=1:property=font_ascii · 段 3 · 片段 1 · 西文/数字字体 · 符合：Times New Roman → Times New Roman；ascii文档指定 Times New Roman；直接run格式
- 确定的格式问题 · R08:paragraph=3:run=1:property=font_eastAsia · 段 3 · 片段 1 · 中文字体 · 符合：黑体 → 黑体；eastAsia文档指定 黑体；直接run格式
- 确定的格式问题 · R08:paragraph=3:run=1:property=size · 段 3 · 片段 1 · 字号 · 符合：18磅 → 18磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R08:paragraph=3:property=alignment · 段 3 · 对齐 · 符合：居中 → 居中；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R08:paragraph=3:property=line · 段 3 · 行距 · 符合：1倍 → 1倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R11:paragraph=3 · 段 3 · 符合：Heading1 · 大纲 0（从0起） → Heading1 · 大纲 0（从0起）；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R12:paragraph=5:run=1:property=font_ascii · 段 5 · 片段 1 · 西文/数字字体 · 符合：宋体 → 宋体；ascii文档指定 宋体；直接run格式
- 确定的格式问题 · R12:paragraph=5:run=1:property=font_eastAsia · 段 5 · 片段 1 · 中文字体 · 符合：宋体 → 宋体；eastAsia文档指定 宋体；直接run格式
- 确定的格式问题 · R12:paragraph=5:run=1:property=size · 段 5 · 片段 1 · 字号 · 符合：10.5磅 → 10.5磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R12:paragraph=8:run=1:property=font_ascii · 段 8 · 片段 1 · 西文/数字字体 · 符合：宋体 → 宋体；ascii文档指定 宋体；直接run格式
- 确定的格式问题 · R12:paragraph=8:run=1:property=font_eastAsia · 段 8 · 片段 1 · 中文字体 · 符合：宋体 → 宋体；eastAsia文档指定 宋体；直接run格式
- 确定的格式问题 · R12:paragraph=8:run=1:property=size · 段 8 · 片段 1 · 字号 · 符合：10.5磅 → 10.5磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R08:paragraph=10:run=1:property=font_ascii · 段 10 · 片段 1 · 西文/数字字体 · 符合：Times New Roman → Times New Roman；ascii文档指定 Times New Roman；直接run格式
- 确定的格式问题 · R08:paragraph=10:run=1:property=font_eastAsia · 段 10 · 片段 1 · 中文字体 · 符合：黑体 → 黑体；eastAsia文档指定 黑体；直接run格式
- 确定的格式问题 · R08:paragraph=10:run=1:property=size · 段 10 · 片段 1 · 字号 · 符合：18磅 → 18磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R08:paragraph=10:property=alignment · 段 10 · 对齐 · 符合：居中 → 居中；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R08:paragraph=10:property=line · 段 10 · 行距 · 符合：1倍 → 1倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R11:paragraph=10 · 段 10 · 符合：Heading1 · 大纲 0（从0起） → Heading1 · 大纲 0（从0起）；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R12:paragraph=13:run=1:property=font_ascii · 段 13 · 片段 1 · 西文/数字字体 · 符合：宋体 → 宋体；ascii文档指定 宋体；直接run格式
- 确定的格式问题 · R12:paragraph=13:run=1:property=font_eastAsia · 段 13 · 片段 1 · 中文字体 · 符合：宋体 → 宋体；eastAsia文档指定 宋体；直接run格式
- 确定的格式问题 · R12:paragraph=13:run=1:property=size · 段 13 · 片段 1 · 字号 · 符合：10.5磅 → 10.5磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R12:paragraph=15:run=1:property=font_ascii · 段 15 · 片段 1 · 西文/数字字体 · 符合：宋体 → 宋体；ascii文档指定 宋体；直接run格式
- 确定的格式问题 · R12:paragraph=15:run=1:property=font_eastAsia · 段 15 · 片段 1 · 中文字体 · 符合：宋体 → 宋体；eastAsia文档指定 宋体；直接run格式
- 确定的格式问题 · R12:paragraph=15:run=1:property=size · 段 15 · 片段 1 · 字号 · 符合：10.5磅 → 10.5磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R09:document=1 · 主文档 · 不适用：未确定 → 中文黑体；西文/数字Times New Roman；15磅；居左；1倍行距；本次确认分类中没有该类对象，不凭空报错
- 确定的格式问题 · R10:document=1 · 主文档 · 不适用：未确定 → 中文黑体；西文/数字Times New Roman；14磅；居左；1倍行距；本次确认分类中没有该类对象，不凭空报错
- 待复核及支持边界 · R13:paragraph=3:property=before · 段 3 · 段前 · 待复核：未确定：磅值与行单位间距并存冲突，需人工核对 → 0.5行；磅值与行单位间距并存冲突，需人工核对；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R13:paragraph=3:property=after · 段 3 · 段后 · 符合：0.5行 → 0.5行；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 待复核及支持边界 · R13:paragraph=10:property=before · 段 10 · 段前 · 待复核：未确定：磅值与行单位间距并存冲突，需人工核对 → 0.5行；磅值与行单位间距并存冲突，需人工核对；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R13:paragraph=10:property=after · 段 10 · 段后 · 符合：0.5行 → 0.5行；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R14:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R15:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R16:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R17:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R18:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R19:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R20:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R21:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 待复核及支持边界 · R22:document=1:property=存在_abstract_cn_title · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R22:document=1:property=存在_abstract_cn_body · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R22:document=1:property=存在_abstract_en_title · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R22:document=1:property=存在_abstract_en_body · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R22:document=1:property=存在_keywords_cn · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R22:document=1:property=存在_keywords_en · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R22:document=1:property=存在_reference_title · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R22:document=1:property=存在_reference_item · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R22:document=1:property=参考文献条目数 · 主文档 · 发现问题：0 → 确认条目≥10（主要文献/外文身份另核对）；按人工确认条目计数；不足时核对范围或资料，不生成文献；不判断主要文献身份、语种或所有著录格式；本项为只读内容提示或存在修改依赖；请人工核对，不自动改写内容。
- 待复核及支持边界 · coverage:0 · 段 2 · 待复核：该对象未完整检查 → 人工核对；人工分类仍标为待确认，未应用正文/标题/题注规则
- 宽度风险 · W02:paragraph=6 · 段 6 · 符合：声明110.00mm；超出0.00mm → 可用160.02mm；普通内嵌图片内外尺寸一致；仅等比例缩小，不放大；裁剪与媒体字节保留
- 宽度风险 · W01:table=1 · 表格 1 · 符合：声明160.02mm；超出0.00mm → 可用160.02mm；自动宽度：一致的网格/单元格声明有宽度风险，最终宽度仍由排版器决定；适配须确认改为固定列宽
- 宽度风险 · W02:paragraph=12 · 段 12 · 符合：声明110.00mm；超出0.00mm → 可用160.02mm；普通内嵌图片内外尺寸一致；仅等比例缩小，不放大；裁剪与媒体字节保留
- 宽度风险 · W01:table=2 · 表格 2 · 符合：声明160.02mm；超出0.00mm → 可用160.02mm；自动宽度：一致的网格/单元格声明有宽度风险，最终宽度仍由排版器决定；适配须确认改为固定列宽
- 待复核及支持边界 · L01:6:7 · 段 6 · 待复核：见对象位置与关联关系（原文已省略） → 只表达相邻意图，不保证实际同页；后一个主文档对象不是已确认图题，不关联远处题注
- 可确认的分页辅助建议 · L01:12:13 · 段 12 · 建议待确认：见对象位置与关联关系（原文已省略） → 只表达相邻意图，不保证实际同页；单一内嵌图片与紧接其后的已确认图题；建议尚未应用
- 可确认的分页辅助建议 · L03:3:4 · 段 3 · 建议待确认：见对象位置与关联关系（原文已省略） → 只表达相邻意图，不保证实际同页；实际XML顺序紧接，建议尚未应用；须确认所选对象
- 待复核及支持边界 · L02:8:0 · 段 8 · 待复核：见对象位置与关联关系（原文已省略） → 只表达相邻意图，不保证实际同页；紧接对象不是普通顶层表格，不关联远处表格
- 可确认的分页辅助建议 · L03:10:11 · 段 10 · 建议待确认：见对象位置与关联关系（原文已省略） → 只表达相邻意图，不保证实际同页；实际XML顺序紧接，建议尚未应用；须确认所选对象
- 可确认的分页辅助建议 · L02:15:2 · 段 15 · 建议待确认：见对象位置与关联关系（原文已省略） → 只表达相邻意图，不保证实际同页；实际XML顺序紧接，建议尚未应用；须确认所选对象
- 待复核及支持边界 · boundary:0 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；外文参考文献2篇以上及主要文献身份、指导教师例外未自动判断（学校PDF物理页16）；需人工核对。
- 待复核及支持边界 · boundary:1 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；中英文摘要/关键词的语义一致性、关键词层次及著录真实性未检查；不生成或改写内容。
- 待复核及支持边界 · boundary:2 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；规则结论只针对已确认范围；未确认段落不自动套正文/标题/题注格式。
- 待复核及支持边界 · boundary:3 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；表格内部文字、页眉页脚及注释仅在明确启用且确认的范围内检查；文本框及实际分页仍需另行复核。宽度只覆盖受支持的顶层对象。
- 待复核及支持边界 · boundary:4 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；预览不是Microsoft Word最终排版，视觉结论必须由人工查看记录。

动态数字事务：仅授权数字变化，域缓存/分页/目录页码未更新。
{"plan": {"version": "dynamic-text-v1", "input_sha256": "702bc5a182205a1ee5d1dccf23d565ea4ea7be785d823b241777f349fba85a79", "scope_sha256": "4e60204d9804c7545b1ea08f9db9a2c433f6bd18f98c8fae2390de88576bddfa", "chapter_evidence": [{"paragraph": 3, "number": 1, "reason": "标题中的明确阿拉伯章号"}, {"paragraph": 10, "number": 2, "reason": "标题中的明确阿拉伯章号"}], "edits": [{"paragraph": 5, "start": 3, "end": 4, "before": "2", "after": "1", "kind": "caption", "target_paragraph": 5, "spans": [{"text_node": 0, "start": 3, "end": 4, "before": "2", "after": "1"}]}, {"paragraph": 4, "start": 5, "end": 6, "before": "2", "after": "1", "kind": "reference", "target_paragraph": 5, "spans": [{"text_node": 1, "start": 0, "end": 1, "before": "2", "after": "1"}]}, {"paragraph": 4, "start": 27, "end": 28, "before": "2", "after": "1", "kind": "reference", "target_paragraph": 5, "spans": [{"text_node": 2, "start": 17, "end": 18, "before": "2", "after": "1"}]}, {"paragraph": 13, "start": 3, "end": 4, "before": "3", "after": "1", "kind": "caption", "target_paragraph": 13, "spans": [{"text_node": 0, "start": 3, "end": 4, "before": "3", "after": "1"}]}, {"paragraph": 4, "start": 10, "end": 11, "before": "3", "after": "1", "kind": "reference", "target_paragraph": 13, "spans": [{"text_node": 2, "start": 0, "end": 1, "before": "3", "after": "1"}]}], "accepted_captions": [5, 8, 13, 15], "blocked_groups": [], "word": {"available": false, "platform": "darwin", "status": "not_run", "reason": "当前非Windows，无Word COM；未更新域、重新分页或核验目录页码。"}, "limits": ["只在本次明确完整的已确认题注范围内按章分别编图、表；不更新SEQ或其他域。", "纯文本引用仅限已确认正文；代码/数据、链接/域、注释和其他容器不自动改写。", "REF/PAGEREF、分页及目录页码尚未完成；必须在Word中更新并复核。", "不新建目录，不写updateFields，不以保存缓存或F9提示冒充实际页码。"], "seal": "fb8eba694a206499261b73c09d0ac48e2d7f6a0290629705abf53ad6bc1609cd"}, "validation": {"input_sha256": "702bc5a182205a1ee5d1dccf23d565ea4ea7be785d823b241777f349fba85a79", "output_sha256": "ce5588f3831691d544f5f71dde11af333c96d774893369c34c8d4bdc4131c3f1", "all_run_properties_preserved": true, "unselected_parts_byte_equal": true, "field_instructions_and_cache_preserved": true, "word_pages_verified": false}, "word": {"available": false, "platform": "darwin", "status": "not_run", "reason": "当前非Windows，无Word COM；未更新域、重新分页或核验目录页码。"}, "adoption": {"fix_calls": 0, "validation": {"input_sha256": "702bc5a182205a1ee5d1dccf23d565ea4ea7be785d823b241777f349fba85a79", "output_sha256": "ce5588f3831691d544f5f71dde11af333c96d774893369c34c8d4bdc4131c3f1", "all_run_properties_preserved": true, "unselected_parts_byte_equal": true, "field_instructions_and_cache_preserved": true, "word_pages_verified": false}, "current_input_auto_switched": false}}

本轮修改：[{"key": "dynamic:1", "rule_id": "R42", "locator": {"paragraph": 5, "start": 3, "end": 4}, "property": "caption_number", "before": "2", "after": "1", "verification": "pass", "source": {"label": "用户授权的产品动态处理", "quote": "按已确认章节及完整题注范围连续编号；唯一纯文本引用同步，不是新增学校格式规定。"}}, {"key": "dynamic:2", "rule_id": "R42", "locator": {"paragraph": 4, "start": 5, "end": 6}, "property": "plain_caption_reference", "before": "2", "after": "1", "verification": "pass", "source": {"label": "用户授权的产品动态处理", "quote": "按已确认章节及完整题注范围连续编号；唯一纯文本引用同步，不是新增学校格式规定。"}}, {"key": "dynamic:3", "rule_id": "R42", "locator": {"paragraph": 4, "start": 27, "end": 28}, "property": "plain_caption_reference", "before": "2", "after": "1", "verification": "pass", "source": {"label": "用户授权的产品动态处理", "quote": "按已确认章节及完整题注范围连续编号；唯一纯文本引用同步，不是新增学校格式规定。"}}, {"key": "dynamic:4", "rule_id": "R42", "locator": {"paragraph": 13, "start": 3, "end": 4}, "property": "caption_number", "before": "3", "after": "1", "verification": "pass", "source": {"label": "用户授权的产品动态处理", "quote": "按已确认章节及完整题注范围连续编号；唯一纯文本引用同步，不是新增学校格式规定。"}}, {"key": "dynamic:5", "rule_id": "R42", "locator": {"paragraph": 4, "start": 10, "end": 11}, "property": "plain_caption_reference", "before": "3", "after": "1", "verification": "pass", "source": {"label": "用户授权的产品动态处理", "quote": "按已确认章节及完整题注范围连续编号；唯一纯文本引用同步，不是新增学校格式规定。"}}]
预览/视觉：{"preview": {"status": "未生成预览"}, "visual": {"status": "未记录人工视觉复核"}}
