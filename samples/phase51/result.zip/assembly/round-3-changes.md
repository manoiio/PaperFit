# 论文有格修改记录

输出：fixed.docx
配置：用户确认的组合演示要求（正文及标题题注）（段落及摘要关键词参考文献） vrule-bundle-1+template-demo-6.0.0+extended-demo-1.0.0+sections-demo-1.0
模板结构版本：6
配置SHA256：307e3bfeed866ecdf6bd1e884492671b10a4da3cd736235308312ad6b182b99f

| 规则 | 位置 | 修改前 | 修改后 | 落盘复查 | 依据 |
| --- | --- | --- | --- | --- | --- |
| R29 · section_pages | {"section": 1} | null | {"kind": "new_section", "start": 3} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 1} | null | {"kind": "new_section", "start": 8} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 1} | null | {"kind": "new_section", "start": 17} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 1} | null | {"kind": "footer", "section": 1, "variant": "default", "old_part": null, "new_part": "word/footerPF1.xml", "role": "cover", "format": "decimal", "restart": null, "text": "", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 2} | null | {"kind": "footer", "section": 2, "variant": "default", "old_part": null, "new_part": "word/footerPF2.xml", "role": "front", "format": "lowerRoman", "restart": 1, "text": "", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 3} | null | {"kind": "footer", "section": 3, "variant": "default", "old_part": null, "new_part": "word/footerPF3.xml", "role": "body", "format": "decimal", "restart": 1, "text": "第1章 合成方法", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 4} | null | {"kind": "footer", "section": 4, "variant": "default", "old_part": null, "new_part": "word/footerPF4.xml", "role": "body", "format": "decimal", "restart": null, "text": "第2章 合成结果", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |

## 分节页码结构事务
已生成PAGE并验证受控新增/克隆部件及分节。未计算域缓存、目录或实际页码；真实渲染/Word观察另行记录。
{"input_sha256": "a8719772a83d9340da48a8f7d096ba98b8951e07799ea9d5566bfec81c6261ee", "output_sha256": "f8a6813d7d7ef0bf3600bdf427aae3337ec2df0bdd299da0209e39b6dcc67ffa", "new_parts": ["word/footerPF1.xml", "word/footerPF2.xml", "word/footerPF3.xml", "word/footerPF4.xml"], "changed_parts": ["[Content_Types].xml", "word/_rels/document.xml.rels", "word/document.xml"], "main_object_order_preserved": true, "physical_pages_not_computed": true}

轮次与输入来源：{"number": 3, "input_round": 2, "input_sha256": "a8719772a83d9340da48a8f7d096ba98b8951e07799ea9d5566bfec81c6261ee", "original_sha256": "b389d1d815ae994974b8f7cd22880620ed34e8fd39786c334e9400e2c6100e02", "rules_version": "rule-bundle-1+template-demo-6.0.0+extended-demo-1.0.0+sections-demo-1.0", "rules_sha256": "307e3bfeed866ecdf6bd1e884492671b10a4da3cd736235308312ad6b182b99f", "backmatter_sha256": "73a31b9d434d3a2cce82aba538b3e8cc7f86ea00b6791a08ba7c21f127902864"}

问题变化（已解决/原有剩余/新出现）：{"resolved_keys": [], "unresolved_review_keys": [], "not_applicable_keys": [], "remaining_keys": ["R22:document=1:property=中文摘要字数", "R22:document=1:property=参考文献条目数"], "new_keys": [], "new_problem_causes": []}

未强制修正的待复核项：[]

完整性验证：{"input_sha256": "a8719772a83d9340da48a8f7d096ba98b8951e07799ea9d5566bfec81c6261ee", "output_sha256": "f8a6813d7d7ef0bf3600bdf427aae3337ec2df0bdd299da0209e39b6dcc67ffa", "new_parts": ["word/footerPF1.xml", "word/footerPF2.xml", "word/footerPF3.xml", "word/footerPF4.xml"], "changed_parts": ["[Content_Types].xml", "word/_rels/document.xml.rels", "word/document.xml"], "main_object_order_preserved": true, "physical_pages_not_computed": true}
