# 论文有格修改记录

输出：fixed.docx
配置：用户确认的组合演示要求（正文及标题题注）（段落及摘要关键词参考文献） vrule-bundle-1+template-demo-6.0.0+extended-demo-1.0.0+sections-demo-1.0
模板结构版本：6
配置SHA256：307e3bfeed866ecdf6bd1e884492671b10a4da3cd736235308312ad6b182b99f

| 规则 | 位置 | 修改前 | 修改后 | 落盘复查 | 依据 |
| --- | --- | --- | --- | --- | --- |
| W02 | {"paragraph": 10} | {"size_emu": [6480000, 1620000]} | {"size_emu": [5760720, 1440180]} | 符合 | 用户确认的宽度辅助（非学校格式规则）：按所在节及对象缩进后可用宽度，等比例缩小所选对象；不改内容 |
| W01 | {"table": 2} | {"width_mm": 176.00083333333333, "columns_twips": [4989, 4989], "layout": "fixed"} | {"width_mm": 160.01999999999998, "columns_twips": [4536, 4536], "layout": "fixed"} | 符合 | 用户确认的宽度辅助（非学校格式规则）：按所在节及对象缩进后可用宽度，等比例缩小所选对象；不改内容 |

## 本次安全图表与分页辅助
{"summary": {"stage": "width", "input_sha256": "f8a6813d7d7ef0bf3600bdf427aae3337ec2df0bdd299da0209e39b6dcc67ffa", "objects": [{"key": "W01:table=1", "status": "protected", "reason": "不属于已确认内容表格或安全关联图片；封面、未知用途、材料保护保持", "section": 1}, {"key": "W02:paragraph=10", "status": "selected", "reason": "普通内嵌图片内外尺寸一致；仅等比例缩小，不放大；裁剪与媒体字节保留", "section": 3}, {"key": "W01:table=2", "status": "selected", "reason": "表格、网格与单元格声明一致；仍是首选几何宽度，不代表实际可见宽度", "section": 3}, {"key": "W01:table=3", "status": "protected", "reason": "不属于已确认内容表格或安全关联图片；封面、未知用途、材料保护保持", "section": 3}], "selected_count": 2, "status": "verified", "seconds": 0.4307, "changes": 2, "output_sha256": "164b1ab11e7d0b1d4a22f3523d4af397430e08b4fdad188fa22314845bd32523"}, "adoption": {"fix_calls": 0, "input_auto_switched": false}}

已设置所选对象适配宽度并读回尺寸
仅比较DOCX声明的几何尺寸，不证明渲染位置、分页或全文排版合格。缩小后可能增加换行和页数；图片高度及题注同页另行预览。

# 页面可用宽度检查（独立布局）

输入哈希：164b1ab11e7d0b1d4a22f3523d4af397430e08b4fdad188fa22314845bd32523
规则哈希：307e3bfeed866ecdf6bd1e884492671b10a4da3cd736235308312ad6b182b99f
几何算法：width-1.0

仅比较DOCX声明的几何尺寸，不证明渲染位置、分页或全文排版合格。缩小后可能增加换行和页数；图片高度及题注同页另行预览。

| 对象 | 节 | 可用mm | 声明mm | 超出mm | 状态/依据 |
| --- | --- | --- | --- | --- | --- |
| W01:table=1 | 1 | 160.020 | 195.897 | 35.877 | risk · 自动宽度：一致的网格/单元格声明有宽度风险，最终宽度仍由排版器决定；适配须确认改为固定列宽 |

计算依据：{"section": 1, "page_width_twips": 11906, "left_margin_twips": 1417, "right_margin_twips": 1417, "gutter_twips": 0, "body_width_twips": 9072, "page_width_mm": 210.0086111111111, "left_margin_mm": 24.994305555555552, "right_margin_mm": 24.994305555555552, "gutter_mm": 0.0, "body_width_mm": 160.01999999999998}
| W02:paragraph=10 | 3 | 160.020 | 160.020 | 0.000 | pass · 普通内嵌图片内外尺寸一致；仅等比例缩小，不放大；裁剪与媒体字节保留 |

计算依据：{"section": 3, "page_width_twips": 11906, "left_margin_twips": 1417, "right_margin_twips": 1417, "gutter_twips": 0, "body_width_twips": 9072, "page_width_mm": 210.0086111111111, "left_margin_mm": 24.994305555555552, "right_margin_mm": 24.994305555555552, "gutter_mm": 0.0, "body_width_mm": 160.01999999999998}
| W01:table=2 | 3 | 160.020 | 160.020 | 0.000 | pass · 表格、网格与单元格声明一致；仍是首选几何宽度，不代表实际可见宽度 |

计算依据：{"section": 3, "page_width_twips": 11906, "left_margin_twips": 1417, "right_margin_twips": 1417, "gutter_twips": 0, "body_width_twips": 9072, "page_width_mm": 210.0086111111111, "left_margin_mm": 24.994305555555552, "right_margin_mm": 24.994305555555552, "gutter_mm": 0.0, "body_width_mm": 160.01999999999998}
| W01:table=3 | 3 | 未确定 | 未确定 | 未确定 | review · 合并或不完整网格，待复核 |

计算依据：{"section": 3, "page_width_twips": 11906, "left_margin_twips": 1417, "right_margin_twips": 1417, "gutter_twips": 0, "body_width_twips": 9072, "page_width_mm": 210.0086111111111, "left_margin_mm": 24.994305555555552, "right_margin_mm": 24.994305555555552, "gutter_mm": 0.0, "body_width_mm": 160.01999999999998}


轮次与输入来源：{"number": 4, "input_round": 3, "input_sha256": "f8a6813d7d7ef0bf3600bdf427aae3337ec2df0bdd299da0209e39b6dcc67ffa", "original_sha256": "b389d1d815ae994974b8f7cd22880620ed34e8fd39786c334e9400e2c6100e02", "rules_version": "rule-bundle-1+template-demo-6.0.0+extended-demo-1.0.0+sections-demo-1.0", "rules_sha256": "307e3bfeed866ecdf6bd1e884492671b10a4da3cd736235308312ad6b182b99f", "backmatter_sha256": "73a31b9d434d3a2cce82aba538b3e8cc7f86ea00b6791a08ba7c21f127902864"}

问题变化（已解决/原有剩余/新出现）：{"resolved_keys": [], "unresolved_review_keys": [], "not_applicable_keys": [], "remaining_keys": ["R22:document=1:property=中文摘要字数", "R22:document=1:property=参考文献条目数"], "new_keys": [], "new_problem_causes": []}

未强制修正的待复核项：[]

完整性验证：{"original_sha256_unchanged": true, "document_except_selected_format_attributes_equal": true, "other_zip_member_bytes_equal": true, "verified_objects": "完整主文档仅掩码所选tblW/tblLayout/gridCol宽度/tcW或图片内外extent尺寸；其他ZIP字节、媒体、裁剪、编号、分页属性、分节、表格文字及合并/边框保留。"}
