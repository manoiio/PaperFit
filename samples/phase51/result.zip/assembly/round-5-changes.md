# 论文有格修改记录

输出：fixed.docx
配置：用户确认的组合演示要求（正文及标题题注）（段落及摘要关键词参考文献） vrule-bundle-1+template-demo-6.0.0+extended-demo-1.0.0+sections-demo-1.0
模板结构版本：6
配置SHA256：307e3bfeed866ecdf6bd1e884492671b10a4da3cd736235308312ad6b182b99f

| 规则 | 位置 | 修改前 | 修改后 | 落盘复查 | 依据 |
| --- | --- | --- | --- | --- | --- |
| L01 · keepNext | {"paragraph": 10} | false | true | 符合 | 产品辅助L01（用户确认）：图片段keep-with-next；紧邻已确认图题keep-lines。表达相邻意图，不保证实际同页。 |
| L01 · keepLines | {"paragraph": 11} | false | true | 符合 | 产品辅助L01（用户确认）：图片段keep-with-next；紧邻已确认图题keep-lines。表达相邻意图，不保证实际同页。 |
| L03 · keepNext | {"paragraph": 3} | false | true | 符合 | 产品辅助L03（用户确认）：仅所选段落分页属性；表达相邻意图，不保证实际同页。 |
| L03 · keepLines | {"paragraph": 3} | false | true | 符合 | 产品辅助L03（用户确认）：仅所选段落分页属性；表达相邻意图，不保证实际同页。 |
| L02 · keepNext | {"paragraph": 13} | false | true | 符合 | 产品辅助L02（用户确认）：仅所选段落分页属性；表达相邻意图，不保证实际同页。 |

已设置图片与图题相邻属性；已设置表题相邻属性；已设置标题与匹配内容相邻属性。未检测实际分页；只表达相邻意图，长表仍可跨页，过长标题或后续内容可能无法同页。请在所用渲染环境人工查看。
这是独立产品排版辅助，不计入R01–R12学校演示格式规则；尚未自动验证分页。

## 本次安全图表与分页辅助
{"summary": {"stage": "pagination", "input_sha256": "164b1ab11e7d0b1d4a22f3523d4af397430e08b4fdad188fa22314845bd32523", "objects": [{"key": "L01:10:11", "status": "selected", "reason": "单一内嵌图片与紧接其后的已确认图题；建议尚未应用"}, {"key": "L03:3:4", "status": "selected", "reason": "实际XML顺序紧接，建议尚未应用；须确认所选对象"}, {"key": "L03:8:9", "status": "satisfied", "reason": "实际XML顺序紧接，建议尚未应用；须确认所选对象"}, {"key": "L02:13:2", "status": "selected", "reason": "实际XML顺序紧接，建议尚未应用；须确认所选对象"}, {"key": "L02:15:3", "status": "protected", "reason": "关联或内容表格用途未确认；不借相似文字扩大范围"}, {"key": "L03:17:18", "status": "protected", "reason": "非普通段落，待复核"}, {"key": "L04:2:1", "status": "satisfied", "reason": "用户已确认连续表头行；只修改所选行tblHeader，不改变长表跨页能力"}], "selected_count": 3, "status": "verified", "seconds": 0.8049, "changes": 5, "output_sha256": "088d37ff7e7302375567c361700941bc963b6a6cc95b822f0f4e748f44b7b0d0"}, "adoption": {"fix_calls": 0, "input_auto_switched": false}}

轮次与输入来源：{"number": 5, "input_round": 4, "input_sha256": "164b1ab11e7d0b1d4a22f3523d4af397430e08b4fdad188fa22314845bd32523", "original_sha256": "b389d1d815ae994974b8f7cd22880620ed34e8fd39786c334e9400e2c6100e02", "rules_version": "rule-bundle-1+template-demo-6.0.0+extended-demo-1.0.0+sections-demo-1.0", "rules_sha256": "307e3bfeed866ecdf6bd1e884492671b10a4da3cd736235308312ad6b182b99f", "backmatter_sha256": "73a31b9d434d3a2cce82aba538b3e8cc7f86ea00b6791a08ba7c21f127902864"}

问题变化（已解决/原有剩余/新出现）：{"resolved_keys": [], "unresolved_review_keys": [], "not_applicable_keys": [], "remaining_keys": ["R22:document=1:property=中文摘要字数", "R22:document=1:property=参考文献条目数"], "new_keys": [], "new_problem_causes": []}

未强制修正的待复核项：[]

完整性验证：{"original_sha256_unchanged": true, "document_except_selected_format_attributes_equal": true, "other_zip_member_bytes_equal": true, "verified_objects": "完整主文档XML仅掩码所选段落keepNext/keepLines或所选表格行tblHeader；其他ZIP成员字节相同，含图片尺寸、媒体、字段、表格内容尺寸合并、编号和分节。"}
