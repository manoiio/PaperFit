# 论文有格修改记录

输出：fixed.docx
配置：用户确认的组合演示要求（正文及标题题注）（段落及摘要关键词参考文献） vrule-bundle-1+template-demo-6.0.0+extended-demo-1.0.0+sections-demo-1.0
模板结构版本：6
配置SHA256：307e3bfeed866ecdf6bd1e884492671b10a4da3cd736235308312ad6b182b99f

| 规则 | 位置 | 修改前 | 修改后 | 落盘复查 | 依据 |
| --- | --- | --- | --- | --- | --- |
| L05 · caption_position | {"paragraph": 10} | {"order": ["caption", "figure"], "caption_paragraph": 10, "body_object": 11} | {"order": ["figure", "caption"], "caption_paragraph": 11, "body_object": 12} | 符合 | 2015学校材料；章内连续序列为产品核对解释：00-全员必看/本科毕业设计论文.pdf 物理页18：插图（表）应有图（表）题（由序号和标题组成），图（表）号按章编序，如第一章第一图的号为“图1-1”。图题置于图下方，表题置于表上方。 |

已纠正所选题注的XML结构位置
位置修正独立一轮；不自动附加L01/L02，不保证移动后同页。
授权的对象顺序变化及范围映射：{"paragraphs": {"1": "1", "2": "2", "3": "3", "4": "4", "5": "5", "6": "6", "7": "7", "8": "8", "9": "9", "10": "11", "11": "10", "12": "12", "13": "13", "14": "14", "15": "15", "16": "16", "17": "17", "18": "18", "19": "19", "20": "20"}, "toc_objects": {"d:1": "d:1", "d:2": "d:2", "d:3": "d:3", "d:4": "d:4", "d:5": "d:5", "d:6": "d:6", "d:7": "d:7", "d:8": "d:8", "d:9": "d:9", "d:10": "d:11", "d:11": "d:10", "d:12": "d:12", "d:13": "d:13", "d:14": "d:14", "d:15": "d:15", "d:16": "d:16", "d:17": "d:17", "d:18": "d:18", "d:19": "d:19", "d:20": "d:20"}, "table_ids": "unchanged", "citation_offsets": "文字子树保持，段号按对象重绑；字符范围不变", "material_exclusions": "按原始XML对象身份重绑，含重复文本也不合并", "invalidated": ["旧修正选择", "旧布局/宽度计划", "不匹配的预览和缓存"], "method": "执行前内存XML对象身份映射；无新增文档标记、无文字匹配"}

## 本次安全图表与分页辅助
{"summary": {"stage": "position", "input_sha256": "6c909118c83c97128ef6994eede877be46ef30d8c57ddfa6b7d1f1dfc6a613fa", "objects": [{"key": "L05:10:image:p:11", "status": "selected", "reason": "反向紧邻，可核对独立L05位置纠正"}, {"key": "L05:13:table:2", "status": "satisfied", "reason": "已确认关联且结构位置正确；实际同页尚未核对"}], "selected_count": 1, "status": "verified", "seconds": 0.4298, "changes": 1, "output_sha256": "a8719772a83d9340da48a8f7d096ba98b8951e07799ea9d5566bfec81c6261ee"}, "adoption": {"fix_calls": 0, "input_auto_switched": false}}

轮次与输入来源：{"number": 2, "input_round": 1, "input_sha256": "6c909118c83c97128ef6994eede877be46ef30d8c57ddfa6b7d1f1dfc6a613fa", "original_sha256": "b389d1d815ae994974b8f7cd22880620ed34e8fd39786c334e9400e2c6100e02", "rules_version": "rule-bundle-1+template-demo-6.0.0+extended-demo-1.0.0+sections-demo-1.0", "rules_sha256": "307e3bfeed866ecdf6bd1e884492671b10a4da3cd736235308312ad6b182b99f", "backmatter_sha256": "73a31b9d434d3a2cce82aba538b3e8cc7f86ea00b6791a08ba7c21f127902864"}

问题变化（已解决/原有剩余/新出现）：{"resolved_keys": ["R43:paragraph=11:property=caption_position"], "unresolved_review_keys": [], "not_applicable_keys": [], "remaining_keys": ["R22:document=1:property=中文摘要字数", "R22:document=1:property=参考文献条目数"], "new_keys": [], "new_problem_causes": [], "identity_basis": "已按XML对象映射比较；不把段号移动误计为新增/解决格式问题"}

未强制修正的待复核项：[]

完整性验证：{"original_sha256_unchanged": true, "all_object_subtrees_equal": true, "remaining_objects_relative_order_equal": true, "other_zip_member_bytes_equal": true, "text_order": "仅授权题注位置变化；未声称全文文字顺序不变", "verified_objects": ["所有主文档XML子树", "图片/表格/段落属性", "关系/媒体/编号/样式/分节", "未选部件逐字节"]}
