# 论文有格修改记录

输出：fixed.docx
配置：本次补充排版要求（正文及标题题注）（段落及摘要关键词参考文献） vrule-bundle-1+template-demo-6.0.0+extended-demo-1.0.0+sections-demo-1.0
模板结构版本：6
配置SHA256：25fecde159555d573a347d4a2c9cdcd0c0bb87b14de67c599c0f4f76c4672570

| 规则 | 位置 | 修改前 | 修改后 | 落盘复查 | 依据 |
| --- | --- | --- | --- | --- | --- |
| R29 · section_pages | {"section": 1} | "word/footer1.xml" | {"kind": "footer", "section": 1, "variant": "default", "old_part": "word/footer1.xml", "new_part": "word/footerPF1.xml", "role": "cover", "format": "decimal", "restart": null, "text": "", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 1} | "word/footer2.xml" | {"kind": "footer", "section": 1, "variant": "first", "old_part": "word/footer2.xml", "new_part": "word/footerPF2.xml", "role": "cover", "format": "decimal", "restart": null, "text": "", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 1} | "word/footer3.xml" | {"kind": "footer", "section": 1, "variant": "even", "old_part": "word/footer3.xml", "new_part": "word/footerPF3.xml", "role": "cover", "format": "decimal", "restart": null, "text": "", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 2} | "word/footer1.xml" | {"kind": "footer", "section": 2, "variant": "default", "old_part": "word/footer1.xml", "new_part": "word/footerPF4.xml", "role": "front", "format": "lowerRoman", "restart": 1, "text": "", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 2} | "word/footer2.xml" | {"kind": "footer", "section": 2, "variant": "first", "old_part": "word/footer2.xml", "new_part": "word/footerPF5.xml", "role": "front", "format": "lowerRoman", "restart": 1, "text": "", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 2} | "word/footer3.xml" | {"kind": "footer", "section": 2, "variant": "even", "old_part": "word/footer3.xml", "new_part": "word/footerPF6.xml", "role": "front", "format": "lowerRoman", "restart": 1, "text": "", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 3} | "word/footer1.xml" | {"kind": "footer", "section": 3, "variant": "default", "old_part": "word/footer1.xml", "new_part": "word/footerPF7.xml", "role": "body", "format": "decimal", "restart": 5, "text": "第1章 合成研究", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 3} | "word/footer2.xml" | {"kind": "footer", "section": 3, "variant": "first", "old_part": "word/footer2.xml", "new_part": "word/footerPF8.xml", "role": "body", "format": "decimal", "restart": 5, "text": "第1章 合成研究", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 3} | "word/footer3.xml" | {"kind": "footer", "section": 3, "variant": "even", "old_part": "word/footer3.xml", "new_part": "word/footerPF9.xml", "role": "body", "format": "decimal", "restart": 5, "text": "第1章 合成研究", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 4} | "word/footer1.xml" | {"kind": "footer", "section": 4, "variant": "default", "old_part": "word/footer1.xml", "new_part": "word/footerPF10.xml", "role": "body", "format": "decimal", "restart": null, "text": "第2章 合成结果", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 4} | "word/footer2.xml" | {"kind": "footer", "section": 4, "variant": "first", "old_part": "word/footer2.xml", "new_part": "word/footerPF11.xml", "role": "body", "format": "decimal", "restart": null, "text": "第2章 合成结果", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |
| R29 · section_pages | {"section": 4} | "word/footer3.xml" | {"kind": "footer", "section": 4, "variant": "even", "old_part": "word/footer3.xml", "new_part": "word/footerPF12.xml", "role": "body", "format": "decimal", "restart": null, "text": "第2章 合成结果", "alignment": "center"} | 符合 | 用户明确选择的页码/章节页脚方案：可选产品结构处理，不是学校默认要求；PAGE域存在不代表目录或引用页码已刷新。 |

## 分节页码结构事务
已生成PAGE并验证受控新增/克隆部件及分节。未计算域缓存、目录或实际页码；真实渲染/Word观察另行记录。
{"input_sha256": "2396364ee86dddaa0af181823e4dea9fb8ad9f94d4e48862283fa78d3eef5923", "output_sha256": "1587cea383860312b47fdd2f91414982bee0cda8233a9a18eb248691140f0aea", "new_parts": ["word/footerPF1.xml", "word/footerPF10.xml", "word/footerPF11.xml", "word/footerPF12.xml", "word/footerPF2.xml", "word/footerPF3.xml", "word/footerPF4.xml", "word/footerPF5.xml", "word/footerPF6.xml", "word/footerPF7.xml", "word/footerPF8.xml", "word/footerPF9.xml"], "changed_parts": ["[Content_Types].xml", "word/_rels/document.xml.rels", "word/document.xml"], "main_object_order_preserved": true, "physical_pages_not_computed": true}

轮次与输入来源：{"number": 2, "input_round": 1, "input_sha256": "2396364ee86dddaa0af181823e4dea9fb8ad9f94d4e48862283fa78d3eef5923", "original_sha256": "a9a2ceded1f268a4f63133746334952554e0e1d471a5a5239921fedbab131ffe", "rules_version": "rule-bundle-1+template-demo-6.0.0+extended-demo-1.0.0+sections-demo-1.0", "rules_sha256": "25fecde159555d573a347d4a2c9cdcd0c0bb87b14de67c599c0f4f76c4672570", "backmatter_sha256": "73a31b9d434d3a2cce82aba538b3e8cc7f86ea00b6791a08ba7c21f127902864"}

问题变化（已解决/原有剩余/新出现）：{"resolved_keys": [], "unresolved_review_keys": [], "not_applicable_keys": [], "remaining_keys": ["R22:document=1:property=中文摘要字数", "R22:document=1:property=参考文献条目数"], "new_keys": [], "new_problem_causes": []}

未强制修正的待复核项：[]

完整性验证：{"input_sha256": "2396364ee86dddaa0af181823e4dea9fb8ad9f94d4e48862283fa78d3eef5923", "output_sha256": "1587cea383860312b47fdd2f91414982bee0cda8233a9a18eb248691140f0aea", "new_parts": ["word/footerPF1.xml", "word/footerPF10.xml", "word/footerPF11.xml", "word/footerPF12.xml", "word/footerPF2.xml", "word/footerPF3.xml", "word/footerPF4.xml", "word/footerPF5.xml", "word/footerPF6.xml", "word/footerPF7.xml", "word/footerPF8.xml", "word/footerPF9.xml"], "changed_parts": ["[Content_Types].xml", "word/_rels/document.xml.rels", "word/document.xml"], "main_object_order_preserved": true, "physical_pages_not_computed": true}
