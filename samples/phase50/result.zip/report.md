# 论文有格阅读报告

待检查文档.docx · 第3轮
启用规则及确认范围内的结果，不代表全文排版合格。
启用规则26；格式问题1；格式待复核28
宽度：{"risks": 0, "reviews": 0, "passes": 0}
Word：未验收

范围状态摘要：{"file_sha256": "90f463005fa50bbc003659c5122285ebfd4e1c1089ba37f13c7bc32447c8dce0", "rules_sha256": "ad7aa43c0f54c93980c881d8aa5c5842230d471d94fae1946c4675f1b201a711", "scope_sha256": "ce5b9d7e11b3efdd3f199f68d2dced04456685278a30748d7dcac4d5e70f35e9", "areas": [{"area": "paragraph", "name": "段落分类与材料保护", "unit": "顶层段落", "selected": 7, "excluded": 0, "participates": true, "scope": "已确认范围，待确认和其他不套普通段落规则"}, {"area": "table", "name": "表格用途与辅助配置", "unit": "顶层表格", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}, {"area": "front", "name": "封面对象与分节用途", "unit": "封面对象（节另计）", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}, {"area": "toc", "name": "目录范围与层级", "unit": "目录段落对象", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}, {"area": "citation", "name": "正文引文", "unit": "字符范围", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}, {"area": "note", "name": "脚注与尾注", "unit": "独立注释对象", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}, {"area": "caption", "name": "题注、章号与关联", "unit": "题注段落", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}, {"area": "reference", "name": "内部引用结构与链接文字", "unit": "内部引用位置（与书签分开）", "selected": 0, "participates": false, "scope": "未启用或不在本轮确认范围", "declarations": {}}], "limits": ["数量按各区域的定位单位分别统计；同一段落可被多个模块引用，不能相加为全文覆盖率。", "未发现候选不证明物理上没有对象；文本框、浮动对象、复杂容器和未知结构仍需复核。", "实际页码、实际同页与Word显示未由范围确认验证；预览与人工视觉核对另行进行。"], "coverage_note_count": 8, "citation_paragraph_properties": [], "unconfirmed_top_level_paragraphs": [1, 2, 10, 14, 15], "review_record_keys": ["R03:paragraph=9:run=1", "R04:paragraph=9:run=1", "R03:paragraph=11:run=1", "R03:paragraph=13:run=1", "R04:paragraph=13:run=1", "R03:paragraph=16:run=1", "R08:paragraph=8:run=1:property=font_ascii", "R08:paragraph=8:run=1:property=font_eastAsia", "R08:paragraph=12:run=1:property=font_ascii", "R08:paragraph=12:run=1:property=font_eastAsia", "R14:paragraph=3:property=before", "R14:paragraph=3:property=alignment", "R14:paragraph=3:run=1:property=font_eastAsia", "R22:document=1:property=存在_abstract_cn_body", "R22:document=1:property=存在_abstract_en_title", "R22:document=1:property=存在_abstract_en_body", "R22:document=1:property=存在_keywords_cn", "R22:document=1:property=存在_keywords_en", "R22:document=1:property=存在_reference_title", "R22:document=1:property=存在_reference_item"], "review_counts": {"rule_records": 20, "coverage_notes": 8}, "review_explanation": "原始待复核记录全部保留；范围未确认、复杂结构及解析限制仍按原报告分别说明。"}
- 确定的格式问题 · R01:section=1 · 节 1 · 符合：210.01 × 297 mm → 210 × 297 mm；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R02:section=1 · 节 1 · 符合：上24.99 mm；下24.99 mm；左24.99 mm；右24.99 mm → 上25 mm；下25 mm；左25 mm；右25 mm；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R01:section=2 · 节 2 · 符合：210.01 × 297 mm → 210 × 297 mm；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R02:section=2 · 节 2 · 符合：上24.99 mm；下24.99 mm；左24.99 mm；右24.99 mm → 上25 mm；下25 mm；左25 mm；右25 mm；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R01:section=3 · 节 3 · 符合：210.01 × 297 mm → 210 × 297 mm；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R02:section=3 · 节 3 · 符合：上24.99 mm；下24.99 mm；左24.99 mm；右24.99 mm → 上25 mm；下25 mm；左25 mm；右25 mm；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R01:section=4 · 节 4 · 符合：210.01 × 297 mm → 210 × 297 mm；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R02:section=4 · 节 4 · 符合：上24.99 mm；下24.99 mm；左24.99 mm；右24.99 mm → 上25 mm；下25 mm；左25 mm；右25 mm；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 待复核及支持边界 · R03:paragraph=9:run=1 · 段 9 · 片段 1 · 待复核：中文：未确定：主题语言 ja-JP 未纳入当前唯一映射范围 → 宋体；eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R04:paragraph=9:run=1 · 段 9 · 片段 1 · 待复核：西文/数字：未确定：主题枚举与字体槽位不对应，需人工确认 → Times New Roman；ascii：主题枚举与字体槽位不对应，需人工确认；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R05:paragraph=9:run=1 · 段 9 · 片段 1 · 符合：12磅 → 12磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R06:paragraph=9 · 段 9 · 符合：1.5倍 → 1.5倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R07:paragraph=9 · 段 9 · 符合：首行2字符；点值0磅 → 首行2字符（汉字）；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 待复核及支持边界 · R03:paragraph=11:run=1 · 段 11 · 片段 1 · 待复核：中文：未确定：主题语言 ja-JP 未纳入当前唯一映射范围 → 宋体；eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R04:paragraph=11:run=1 · 段 11 · 片段 1 · 不适用：未确定 → Times New Roman；无该类字符
- 确定的格式问题 · R05:paragraph=11:run=1 · 段 11 · 片段 1 · 符合：12磅 → 12磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R06:paragraph=11 · 段 11 · 符合：1.5倍 → 1.5倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R07:paragraph=11 · 段 11 · 符合：首行2字符；点值0磅 → 首行2字符（汉字）；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 待复核及支持边界 · R03:paragraph=13:run=1 · 段 13 · 片段 1 · 待复核：中文：未确定：主题语言 ja-JP 未纳入当前唯一映射范围 → 宋体；eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R04:paragraph=13:run=1 · 段 13 · 片段 1 · 待复核：西文/数字：未确定：主题枚举与字体槽位不对应，需人工确认 → Times New Roman；ascii：主题枚举与字体槽位不对应，需人工确认；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R05:paragraph=13:run=1 · 段 13 · 片段 1 · 符合：12磅 → 12磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R06:paragraph=13 · 段 13 · 符合：1.5倍 → 1.5倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R07:paragraph=13 · 段 13 · 符合：首行2字符；点值0磅 → 首行2字符（汉字）；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 待复核及支持边界 · R03:paragraph=16:run=1 · 段 16 · 片段 1 · 待复核：中文：未确定：主题语言 ja-JP 未纳入当前唯一映射范围 → 宋体；eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R04:paragraph=16:run=1 · 段 16 · 片段 1 · 不适用：未确定 → Times New Roman；无该类字符
- 确定的格式问题 · R05:paragraph=16:run=1 · 段 16 · 片段 1 · 符合：12磅 → 12磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R06:paragraph=16 · 段 16 · 符合：1.5倍 → 1.5倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R07:paragraph=16 · 段 16 · 符合：首行2字符；点值0磅 → 首行2字符（汉字）；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 待复核及支持边界 · R08:paragraph=8:run=1:property=font_ascii · 段 8 · 片段 1 · 西文/数字字体 · 待复核：未确定（主题或字体槽位） → Times New Roman；ascii：主题枚举与字体槽位不对应，需人工确认；主题枚举与字体槽位不对应，需人工确认；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R08:paragraph=8:run=1:property=font_eastAsia · 段 8 · 片段 1 · 中文字体 · 待复核：未确定（主题或字体槽位） → 黑体；eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围；主题语言 ja-JP 未纳入当前唯一映射范围；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R08:paragraph=8:run=1:property=size · 段 8 · 片段 1 · 字号 · 符合：18磅 → 18磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R08:paragraph=8:property=alignment · 段 8 · 对齐 · 符合：居中 → 居中；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R08:paragraph=8:property=line · 段 8 · 行距 · 符合：1倍 → 1倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R11:paragraph=8 · 段 8 · 符合：Heading1 · 大纲 0（从0起） → Heading1 · 大纲 0（从0起）；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 待复核及支持边界 · R08:paragraph=12:run=1:property=font_ascii · 段 12 · 片段 1 · 西文/数字字体 · 待复核：未确定（主题或字体槽位） → Times New Roman；ascii：主题枚举与字体槽位不对应，需人工确认；主题枚举与字体槽位不对应，需人工确认；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R08:paragraph=12:run=1:property=font_eastAsia · 段 12 · 片段 1 · 中文字体 · 待复核：未确定（主题或字体槽位） → 黑体；eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围；主题语言 ja-JP 未纳入当前唯一映射范围；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R08:paragraph=12:run=1:property=size · 段 12 · 片段 1 · 字号 · 符合：18磅 → 18磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R08:paragraph=12:property=alignment · 段 12 · 对齐 · 符合：居中 → 居中；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R08:paragraph=12:property=line · 段 12 · 行距 · 符合：1倍 → 1倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R11:paragraph=12 · 段 12 · 符合：Heading1 · 大纲 0（从0起） → Heading1 · 大纲 0（从0起）；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R09:document=1 · 主文档 · 不适用：未确定 → 中文黑体；西文/数字Times New Roman；15磅；居左；1倍行距；本次确认分类中没有该类对象，不凭空报错
- 确定的格式问题 · R10:document=1 · 主文档 · 不适用：未确定 → 中文黑体；西文/数字Times New Roman；14磅；居左；1倍行距；本次确认分类中没有该类对象，不凭空报错
- 确定的格式问题 · R12:document=1 · 主文档 · 不适用：未确定 → 图题：中文宋体；西文/数字宋体；10.5磅；表题：中文宋体；西文/数字宋体；10.5磅；本次确认分类中没有该类对象，不凭空报错
- 待复核及支持边界 · R14:paragraph=3:property=before · 段 3 · 段前 · 待复核：未确定：有效继承路径也未设置before间距；未按0处理 → 0.5行；有效继承路径也未设置before间距；未按0处理；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R14:paragraph=3:property=after · 段 3 · 段后 · 符合：0.5行 → 0.5行；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 待复核及支持边界 · R14:paragraph=3:property=alignment · 段 3 · 对齐 · 待复核：未确定：对齐未设置/未支持或无法可靠继承 → 居中；对齐未设置/未支持或无法可靠继承；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R14:paragraph=3:property=line_spacing · 段 3 · 行距 · 符合：1倍 → 1倍；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 待复核及支持边界 · R14:paragraph=3:run=1:property=font_eastAsia · 段 3 · 片段 1 · 中文字体 · 待复核：未确定：主题语言 ja-JP 未纳入当前唯一映射范围 → 黑体；eastAsia：主题语言 ja-JP 未纳入当前唯一映射范围；主题语言 ja-JP 未纳入当前唯一映射范围；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R14:paragraph=3:run=1:property=size · 段 3 · 片段 1 · 字号 · 符合：18磅 → 18磅；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R13:paragraph=8:property=before · 段 8 · 段前 · 符合：0.5行 → 0.5行；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R13:paragraph=8:property=after · 段 8 · 段后 · 符合：0.5行 → 0.5行；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R13:paragraph=12:property=before · 段 12 · 段前 · 符合：0.5行 → 0.5行；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R13:paragraph=12:property=after · 段 12 · 段后 · 符合：0.5行 → 0.5行；本属性已检查；不代表电脑已安装字体或可见排版通过。
- 确定的格式问题 · R15:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R16:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R17:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R18:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R19:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R20:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R21:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R38:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R39:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R40:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R41:document=1 · 主文档 · 不适用：未确定 → —；当前模板未配置或确认范围无该对象，不套正文规则
- 确定的格式问题 · R22:document=1:property=存在_abstract_cn_title · 主文档 · 符合：1 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容
- 待复核及支持边界 · R22:document=1:property=存在_abstract_cn_body · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R22:document=1:property=存在_abstract_en_title · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R22:document=1:property=存在_abstract_en_body · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R22:document=1:property=存在_keywords_cn · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R22:document=1:property=存在_keywords_en · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R22:document=1:property=存在_reference_title · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 待复核及支持边界 · R22:document=1:property=存在_reference_item · 主文档 · 待复核：0 → >=1；只统计确认类型；未发现时须核对分类，不能直接断言文档物理缺少或补写内容；请在Word核对该对象的槽位/样式/编号；本项不自动修正，其余可判定属性按各自记录检查。
- 确定的格式问题 · R22:document=1:property=参考文献条目数 · 主文档 · 发现问题：0 → 确认条目≥10（主要文献/外文身份另核对）；按人工确认条目计数；不足时核对范围或资料，不生成文献；不判断主要文献身份、语种或所有著录格式；本项为只读内容提示或存在修改依赖；请人工核对，不自动改写内容。
- 待复核及支持边界 · coverage:0 · 段 11 · 片段 1 · 待复核：该对象未完整检查 → 人工核对；含未支持字体槽位的字符（如希腊文、符号、emoji）；其字体未验证
- 待复核及支持边界 · coverage:1 · 段 13 · 片段 1 · 待复核：该对象未完整检查 → 人工核对；含未支持字体槽位的字符（如希腊文、符号、emoji）；其字体未验证
- 待复核及支持边界 · coverage:2 · 段 16 · 片段 1 · 待复核：该对象未完整检查 → 人工核对；含未支持字体槽位的字符（如希腊文、符号、emoji）；其字体未验证
- 待复核及支持边界 · coverage:3 · 段 1 · 待复核：该对象未完整检查 → 人工核对；人工分类仍标为待确认，未应用正文/标题/题注规则
- 待复核及支持边界 · coverage:4 · 段 2 · 待复核：该对象未完整检查 → 人工核对；人工分类仍标为待确认，未应用正文/标题/题注规则
- 待复核及支持边界 · coverage:5 · 段 10 · 待复核：该对象未完整检查 → 人工核对；人工分类仍标为待确认，未应用正文/标题/题注规则
- 待复核及支持边界 · coverage:6 · 段 14 · 待复核：该对象未完整检查 → 人工核对；人工分类仍标为待确认，未应用正文/标题/题注规则
- 待复核及支持边界 · coverage:7 · 段 15 · 待复核：该对象未完整检查 → 人工核对；人工分类仍标为待确认，未应用正文/标题/题注规则
- 待复核及支持边界 · L03:3:4 · 段 3 · 待复核：见对象位置与关联关系（原文已省略） → 只表达相邻意图，不保证实际同页；现有段前分页，待复核；不会删除原属性
- 待复核及支持边界 · L03:8:9 · 段 8 · 待复核：见对象位置与关联关系（原文已省略） → 只表达相邻意图，不保证实际同页；非普通段落，待复核
- 待复核及支持边界 · L03:12:13 · 段 12 · 待复核：见对象位置与关联关系（原文已省略） → 只表达相邻意图，不保证实际同页；非普通段落，待复核
- 待复核及支持边界 · boundary:0 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；外文参考文献2篇以上及主要文献身份、指导教师例外未自动判断（学校PDF物理页16）；需人工核对。
- 待复核及支持边界 · boundary:1 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；中英文摘要/关键词的语义一致性、关键词层次及著录真实性未检查；不生成或改写内容。
- 待复核及支持边界 · boundary:2 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；附录和致谢按需存在，没有时不判缺项。
- 待复核及支持边界 · boundary:3 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；附录普通文字须明确确认适用文献正文解释；代码、数据、运行输出、图表及其他材料不能整章套用。
- 待复核及支持边界 · boundary:4 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；致谢范例物理页38仅显示标题与省略号，未提供可可靠执行的字体字号行距要求；致谢默认属性均未启用。
- 待复核及支持边界 · boundary:5 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；内容、代码正确性、致谢是否适当、目录实际页码及所有排版行为未验证。
- 待复核及支持边界 · boundary:6 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；规则结论只针对已确认范围；未确认段落不自动套正文/标题/题注格式。
- 待复核及支持边界 · boundary:7 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；表格内部文字、页眉页脚及注释仅在明确启用且确认的范围内检查；文本框及实际分页仍需另行复核。宽度只覆盖受支持的顶层对象。
- 待复核及支持边界 · boundary:8 · 主文档 · 支持边界：未覆盖或限定范围 → 保留人工复核；预览不是Microsoft Word最终排版，视觉结论必须由人工查看记录。

完整整理各阶段：{"policy": {"version": 2, "dynamic": true, "pages": "front-body", "roman": "lowerRoman", "body_start": 5, "front_start": 1, "chapter_restart": false, "footer": "chapter", "text": "", "alignment": "center", "targets": ["cover", "front", "body"]}, "steps": [{"kind": "format", "round": 1, "input_sha256": "bd42a60f80b37de4d054abf5d5dd053840fdd07b4f954ed08194fafbdcc523a9", "output_sha256": "01698615ce54b821a7d5c4ae331e6b5073c54297ba758b7ace1894d115f499aa", "changes": 33}, {"kind": "section_pages", "round": 2, "input_sha256": "01698615ce54b821a7d5c4ae331e6b5073c54297ba758b7ace1894d115f499aa", "output_sha256": "7513472979359ba8ad8fc943c0018b93204faeabbc5a8bc1a436b8d5bad54667", "changes": 12}, {"kind": "field_update", "round": 3, "input_sha256": "7513472979359ba8ad8fc943c0018b93204faeabbc5a8bc1a436b8d5bad54667", "output_sha256": "90f463005fa50bbc003659c5122285ebfd4e1c1089ba37f13c7bc32447c8dce0", "changes": 3}], "total_changes": 48, "input_auto_switched": false, "fields_evaluated": true, "structure_evidence": {"version": "structure-evidence-1", "body_start": 7, "chapters": [{"paragraph": 7, "role": "heading1", "level": 1, "source": "style_outline_number"}, {"paragraph": 11, "role": "heading1", "level": 1, "source": "style_outline_number"}], "markers": [{"paragraph": 3, "role": "abstract_cn_title", "source": "independent_marker"}, {"paragraph": 4, "role": "toc", "source": "independent_marker"}], "regions": [{"start": 1, "end": 2, "purpose": "other", "role": "pending"}, {"start": 3, "end": 3, "purpose": "front", "role": "abstract_cn_title"}, {"start": 4, "end": 6, "purpose": "front", "role": "other"}, {"start": 7, "end": 10, "purpose": "body", "role": "heading1"}, {"start": 11, "end": 15, "purpose": "body", "role": "heading1"}], "conflicts": [], "physical_pages_computed": false, "body_start_source": "shared_structure_evidence"}}

本轮修改：[{"rule_id": "R30", "locator": {"paragraph": 5}, "property": "field_cache", "before": "旧保存结果", "after": "TOC已更新", "verification": "pass", "source": {"label": "本机Word显式目录/引用更新（非学校新规则）", "quote": "仅更新已授权的安全目录和目标唯一的REF/PAGEREF保存结果"}}, {"rule_id": "R44", "locator": {"paragraph": 14}, "property": "field_cache", "before": "旧保存结果", "after": "REF已更新", "verification": "pass", "source": {"label": "本机Word显式目录/引用更新（非学校新规则）", "quote": "仅更新已授权的安全目录和目标唯一的REF/PAGEREF保存结果"}}, {"rule_id": "R44", "locator": {"paragraph": 14}, "property": "field_cache", "before": "旧保存结果", "after": "PAGEREF已更新", "verification": "pass", "source": {"label": "本机Word显式目录/引用更新（非学校新规则）", "quote": "仅更新已授权的安全目录和目标唯一的REF/PAGEREF保存结果"}}]
预览/视觉：{"preview": {"status": "未生成预览"}, "visual": {"status": "未记录人工视觉复核"}}
